# Static and dynamic configuration

![ALKS model](../../../architecture/png/simulation_task_tsc2carla.png)

![ALKS model](../../../architecture/png/tsc_config_tsc2carla.png)