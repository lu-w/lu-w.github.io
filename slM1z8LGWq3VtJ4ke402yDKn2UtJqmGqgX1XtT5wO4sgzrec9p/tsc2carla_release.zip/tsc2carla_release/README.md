# TSC2CARLA

This project aims to solve the problem of automatically deriving CARLA simulations from abstract scenarios specified as TSCs by deriving concrete scenarios using the TSC2OpenX tool and running those scenarios in the CARLA ScenarioRunner.

# Installation Steps

Navigate into the `implementation` folder.

## Requirements

- z3 installed and z3.exe in your computers path variables
- JRE 17+

## Installation

- Install the python dependencies using ```pip install -r requirements.txt```
- Run ```git submodule update --remote --init```
- Install the ADS via ```cd models/tsc2carla-models``` and ```pip install .```
- Install the metrics module via ```cd metrics``` and ```pip install .```

## Configure the simulation setup and analysis task

Before running the toolchain, you should check and be aware of the following configurations.

- ```config/static_config.yaml```: Copy the template from ```config/static_config_template.yaml```, configure your tooling paths (e.g. carla/esmini executable and logging paths) and rename it to ```config/static_config.yaml```
- ```config/analysis_task.yaml```: Copy the template from ```config/analysis_task_template.yaml```, configure you toolchain run (e.g. generating 10 scenarios and run esmini afterwards) and rename it to ```config/analysis_task.yaml```
- ```tools/tsc2openx/config/```: Here folders with configuration for tsc2openx are located. If you want to use tsc2openx then exactly one of the folders must be specified with the in the variable ```tsc2openx_config_dirs``` in the ```config/analysis_task.yaml``` configuration file. 
  WARNING: Do not modify the standard folders (```standard```, ```standard_esmini```, ...). Please make an individual copy for yourself. 

# Run the toolchain

- To run the toolchain you simply execute ```python execute.py``` in your python environment. The scenario will wait for the ADS to connect
- To start the ADS, execute ```python models/runner.py```

