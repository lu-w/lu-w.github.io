# Models

## Name

## Description
Let people know what your project can do specifically. Provide context and add a link to any reference visitors might be unfamiliar with. A list of Features or a Background subsection can also be added here. If there are alternatives to your project, this is a good place to list differentiating factors.

## Interface
Describe the interface to other modules here.

## Installation
Within a particular ecosystem, there may be a common way of installing things, such as using Yarn, NuGet, or Homebrew. However, consider the possibility that whoever is reading your README is a novice and would like more guidance. Listing specific steps helps remove ambiguity and gets people to using your project as quickly as possible. If it only runs in a specific context like a particular programming language version or operating system or has dependencies that have to be installed manually, also add a Requirements subsection.

# Ego Detailed explenation

The ego vehicle is the core actor and for now the only one responding to other actors.

## Responding of the ego vehicle

### Getting the data to respond to

To keep the ego on the wanted path we use the local planner module from the carla Python API.
It has, like the ego vehicle a run step method which returns a control to follow the waypoints.

This control then gets adjusted in the ego event class together with the sensor input. For this we do not change the steer, instead we only calculate a driver input variable which indicates if the ego should throttle or break.


```mermaid
graph LR;

run(run step start)
path(get control from local planner)
data(get sensor data)
response(adjust control to other actors)
sensors(restart collection sensor data)
return(return control)

run ---> path
path --- data
data --there is other actor--> response
data --there in no actor--> sensors
response ---> sensors
sensors ---> return
return ---> run
```

### Calculating the Response

#### Classification

To calculate the responses we first check in which category the interaction falls. The possible categories are:
1. intersec: actor moves so that in a plausible time the paths of both will intersect
2. follow: the actor is in front of the ego and drives in the same direction
3. no risk: the actor is detected but there is no risk that the 2 are going to collide

#### Response Class structure

Inside of the egos Constructor, we define a list in which all classes of responses are contained which should be used in the simulation.
```
from ea_models.ego_event import EgoEvent
from ea_models.ego_responses import IntersectionResponse, FollowingResponse

used_responses = [IntersectionResponse(0), FollowingResponse(0)]
self.event_handler = EgoEvent(used_responses, target_speed=target_speed)

```

Those response classes all inherit from a ResponseSuper which can be found in the ego_response.py. This super implements an abstract method to calculate the response.

In the ego event handler all those abstract methods then get called for each actor which is registered by the ego.

```mermaid
graph TB

act(actor registered) ---> handler(event handler)

subgraph Event Handler Class
    handler --actor params--> resp1(First Response)
    resp1 --driver input--> resp2(Second Response)
    resp2 -..-> respN(N'th Response)
    respN --driver input--> control(control adjustment)

    respSup(Response Super) --inherits--> resp1
    respSup --inherits--> resp2
    respSup --inherits--> respN
end

control --control--> ego(automated vehicles run step method)
```





