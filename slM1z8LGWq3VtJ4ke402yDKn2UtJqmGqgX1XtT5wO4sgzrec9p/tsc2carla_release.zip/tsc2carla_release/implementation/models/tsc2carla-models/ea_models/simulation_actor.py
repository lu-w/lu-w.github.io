from abc import abstractmethod
from typing import List
import pkg_resources
import yaml

import carla
from agents.navigation.behavior_agent import BehaviorAgent
import math


class SimulationActor(BehaviorAgent):
    """
    Super class for all actors used in our scenarios.
    Implements methods for getting of the parameters.

    Must implement following methods to work properly:
        - run_step() -> carla.VehicleControl: method called in each simulation step
        - stop() -> None: stops the actor and deletes all enteties related to the actor
    """

    def __init__(self,
                 world,
                 spawn_transform: carla.Transform,
                 name: str,
                 initialize_behavior_agent: bool = True) -> None:
        """
        Constructor for the more generalized Simulation Actor class from which the
        actors in the criticality analysis simulation can inherit.
        :param world: carla World object
        :param blueprint: string which defines a carla blueprint (example: vehicle.nissan.micra)
        :param spawn_transform: carla.Transform which defines the spawn location and rotation of the actor
        :param initialize_behavior_agent: set this to true if the correspounding actor is a pedestrian.
        """
        self.world = world
        self.name = name

        # get config
        config_path = pkg_resources.resource_filename('ea_models', 'config/config.yml')
        self.config_file = yaml.safe_load(open(config_path))

        self.event_handler = None

        blueprint_library = self.world.get_blueprint_library()
        self.blueprint = blueprint_library.find(self.get_blueprint())
        self.blueprint.set_attribute('role_name', name)

        # get basic variables
        self.spawn_transform = spawn_transform
        self.actor = world.spawn_actor(self.blueprint, self.spawn_transform)
        self.bounding_box = self.actor.bounding_box
        self.is_finished = False

        # it is important that for pedestrian agents the BehaviorAgent does not get initializes due to the
        # parameters related to the controlling of a vehicle
        if initialize_behavior_agent:
            super(SimulationActor, self).__init__(vehicle=self.actor, behavior='aggressive')

    @staticmethod
    def preload_config() -> dict:
        """ Do only call this method if you need values from the config before initializing the super. """
        config_path = pkg_resources.resource_filename('ea_models', 'config/config.yml')
        return yaml.safe_load(open(config_path))

    @abstractmethod
    def get_blueprint(self) -> str:
        """
        :return: string which defines a blueprint out of the carla blueprint library
        """
        pass

    @abstractmethod
    def run_step(self, debug: bool = False) -> carla.VehicleControl:
        """
        runs one simulation step
        :return: Carla vehicle control object
        """
        pass

    @abstractmethod
    def stop(self) -> None:
        """
        Stops the actor and destroys all related entities in the world
        """
        pass

    def done(self):
        return self.is_finished

    def get_name(self):
        return self.name

    def get_mass(self) -> float:
        return self.actor.get_physics_control().mass

    def get_world(self) -> carla.World:
        return self.world

    def get_speed(self) -> float:
        velocity = self.get_velocity()
        return math.sqrt(velocity.x ** 2 + velocity.y ** 2)

    def get_vehicle(self) -> carla.Actor:
        return self.actor

    def get_control(self):
        return self.actor.get_control()

    def get_waypoint(self, location) -> carla.Waypoint:
        return self._map.get_waypoint(location)

    def get_velocity(self) -> carla.Vector3D:
        return self.actor.get_velocity()

    def get_location(self) -> carla.Location:
        return self.actor.get_location()

    def get_transform(self) -> carla.Transform:
        return self.actor.get_transform()

    # remember that in the bicycle agent get_id was used if causing error change the method name
    def get_vehicle_id(self) -> int:
        return self.actor.id

    def get_bounding_box(self) -> carla.BoundingBox:
        return self.bounding_box

    def get_forward_vector(self) -> carla.Vector3D:
        return self.get_transform().get_forward_vector()

    def get_angular_velocity(self) -> carla.Vector3D:
        return self.actor.get_angular_velocity()

    def apply_control_wrapper(self, control) -> None:
        self.actor.apply_control(control)
