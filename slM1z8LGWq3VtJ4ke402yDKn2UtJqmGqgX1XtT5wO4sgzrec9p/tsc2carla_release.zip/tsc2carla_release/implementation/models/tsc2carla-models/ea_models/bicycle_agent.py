from abc import abstractmethod

from ea_models.model_debugging import BicDebugger
from .events import EventHandler, get_bic_responses
import carla

from ea_models.simulation_actor import SimulationActor


class BicycleAgent(SimulationActor):
    """
    Agent that controls a bicyclist in the Carla simulator. Extended version of the Basic Agent.
    Ensures that the agents of AVS, bicycles and pedestrians have similar methods.
    """

    def __init__(self, world, start_transform: carla.Transform, target_speed=40, name: str = 'bic') -> None:
        """
        Creates an Agent that inherits from the Basic Agent

        :param world:               carla.World
        :param start_transform:     carla.Transform for the spawn location and rotation of the bicycle
        :param target_speed:        the target speed of the agent
        :param name:                name of the actor
        """
        super().__init__(world, start_transform, name)
        self.config = self.config_file['bic parameters']
        self.id = self.actor.id

        self.is_finished = False
        self.spawn_point = start_transform.location
        self.set_target_speed(target_speed)

        debug_config = self.config_file['bicycle debugging options']
        self._debug = debug_config['debug']
        if self._debug:
            self.debug_handler = BicDebugger(world, debug_config, self.config)

        responses = get_bic_responses(0.5)
        self.event_handler = EventHandler(responses, self.config['event handler config'])
        self._sensores = []
        self._add_sensores(self.config['sensors'])

    def _add_sensores(self, sensor_config: dict):
        start_angle = sensor_config['start angle']
        sensor_angles = sensor_config['angle between']
        length = sensor_config['length']

        os_blueprint = self.actor.get_world().get_blueprint_library().find('sensor.other.obstacle')
        os_blueprint.set_attribute('distance', str(length))
        os_blueprint.set_attribute('hit_radius', str(3))
        os_blueprint.set_attribute('only_dynamics', 'true')
        os_blueprint.set_attribute('sensor_tick', '0.003')

        for a in range(-start_angle, start_angle, sensor_angles):
            transform = carla.Transform(carla.Location(0, 0, 1), carla.Rotation(yaw=a))
            sensor = self.actor.get_world().spawn_actor(os_blueprint, transform, attach_to=self.actor)
            sensor.listen(self.event_handler.add_event)
            self._sensores.append(sensor)

    def set_dest(self, end_location: carla.Location):
        """
        Sets the destination, and creates the waypoints which the bicycle will follow.
        """
        self._destination = end_location

        start_waypoint = self._map.get_waypoint(self.spawn_point)
        end_waypoint = self._map.get_waypoint(end_location)
        route_trace = self.trace_route(start_waypoint, end_waypoint)
        self._local_planner.set_global_plan(route_trace, clean_queue=True)

    @abstractmethod
    def run_step(self, debug: bool = False) -> carla.VehicleControl:
        """
        Runs a simulation step for the bicyclist agent.
        :return: control of the agent
        """
        # call debugging methods
        if self._debug:
            self.debug_handler.debug_frame(self)

        control = self._local_planner.run_step()

        if self.actor.get_location().distance(self._destination) < 2:
            self.is_finished = True

        if self._local_planner.done():
            self.is_finished = True

        control = self.event_handler.get_response(self, control)

        if self.is_finished:
            control.throttle = 1
            control.brake = 0

        self.event_handler.start_event_collection()
        return control

    @abstractmethod
    def get_blueprint(self):
        return 'vehicle.diamondback.century'

    @abstractmethod
    def stop(self):
        self.actor.destroy()
