import carla
from abc import abstractmethod

from ea_models.simulation_actor import SimulationActor


class Debugger:

    def __init__(self, config, world):
        self.config = config
        self.world = world
        self.colors = {
            'red': carla.Color(200, 0, 0),
            'green': carla.Color(0, 200, 0),
            'blue': carla.Color(0, 0, 200),
        }
        self._past_steer = []

    def _draw_velocity(self, actor: SimulationActor):
        loc = actor.get_location()
        vec = actor.get_velocity()
        vec.z, loc.z = 0, 1
        self.world.debug.draw_arrow(loc, loc + vec, life_time=0.1, thickness=0.1, color=self.colors['short sensor'])

    def _draw_wanted_direction(self, actor: SimulationActor):
        loc = actor.get_location()
        vec = actor.get_forward_vector()

        num_steer_history = 30
        self._past_steer.append(actor.get_control().steer)
        if len(self._past_steer) > num_steer_history:
            self._past_steer = self._past_steer[1:]

        rotation = sum(self._past_steer) / len(self._past_steer) * 45
        vec.z, loc.z = 0, 1
        direction_vec = carla.Transform(loc, carla.Rotation(yaw=rotation)).transform_vector(vec) * 5
        self.world.debug.draw_arrow(loc, loc + direction_vec, life_time=0.1, thickness=0.1, color=self.colors['short sensor'])

    def check_if_debug(self, option: str) -> bool:
        return option in self.config and self.config[option]

    @abstractmethod
    def debug_frame(self, actor: SimulationActor) -> None:
        if self.check_if_debug('draw velocity'):
            self._draw_velocity(actor)


class EgoDebugger(Debugger):

    def __init__(self, world, debug_config: dict = {}, ego_config: dict = {}):
        super().__init__(debug_config, world)

        short_angle_difference = ego_config['difference angle short']
        start_angle_short = ego_config['start angle short']
        mid_angle_difference = ego_config['difference angle mid']
        start_angle_mid = ego_config['start angle mid']
        self.short_sensor_angles = list(range(- start_angle_short, start_angle_short, short_angle_difference))
        self.middle_sensor_angles = list(range(-start_angle_mid, start_angle_mid, mid_angle_difference))

        self.short_sensor_length = ego_config['short sensor length']
        self.mid_sensor_length = ego_config['mid sensor length']

        self.colors = {
            'short sensor': carla.Color(100, 0, 0, 100),
            'mid sensor': carla.Color(0, 0, 100, 100)
        }

    def _draw_ego_sensors(self, ego: SimulationActor, short: bool = False, mid: bool = False):
        loc = ego.get_location()
        vec = ego.get_forward_vector()
        vec.z = 0
        loc.z = 1

        if short:
            for a in self.short_sensor_angles:
                vector = vec * self.short_sensor_length
                vector = carla.Transform(loc, carla.Rotation(yaw=a)).transform_vector(vector)
                self.world.debug.draw_line(loc, loc + vec, life_time=0.1, thickness=0.04, color=self.colors['short sensor'])

        if mid:
            for a in self.middle_sensor_angles:
                vector = vec * self.mid_sensor_length
                vector = carla.Transform(loc, carla.Rotation(yaw=a)).transform_vector(vector)
                self.world.debug.draw_line(loc, loc + vector, life_time=0.1, thickness=0.04, color=self.colors['mid sensor'])

    def debug_frame(self, actor: SimulationActor):
        super().debug_frame(actor)
        if self.check_if_debug('draw short sensor'):
            self._draw_ego_sensors(actor, short=True)
        if self.check_if_debug('draw mid sensor'):
            self._draw_ego_sensors(actor, mid=True)
        if self.check_if_debug('draw steer direction'):
            self._draw_wanted_direction(actor)


class BicDebugger(Debugger):

    def __init__(self, world, debug_config: dict = {}, act_config: dict = {}):
        super().__init__(debug_config, world)

    def debug_frame(self, actor: SimulationActor) -> None:
        super().debug_frame(actor)
        if self.check_if_debug('draw steer direction'):
            self._draw_wanted_direction(actor)
