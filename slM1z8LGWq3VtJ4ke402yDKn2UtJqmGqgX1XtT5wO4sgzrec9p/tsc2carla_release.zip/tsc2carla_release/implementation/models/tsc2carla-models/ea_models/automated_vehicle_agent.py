from abc import abstractmethod
import math

from ea_models.simulation_actor import SimulationActor
import carla
from .events import EventHandler, get_ego_responses

from ea_models.model_debugging import EgoDebugger
from ea_models.utils import display_params


class AutomatedVehicleAgent(SimulationActor):
    """
    Agent that controls an AV in the Carla simulator. Extended version of the Behavior Agent.
    Ensures that the agents of AVS, bicycles and pedestrians have similar methods.
    """

    def __init__(self, world, mass, start_transform, target_location, target_speed=50,
                 name: str = 'ego'):
        """
        Creates an Agent that inherits from the Behavior Agent

        :param world:           carla.world in which the vehicle should be spawned
        :param mass:            mass of the automated vehicle
        :param start_transform: carla.Transform for the starting point of the actor and the rotation at the start
        :param target_location: carla.Location where the vehicle should finish
        :param target_speed:    the target speed of the agent
        :param name:            name of the actor is in all scenarios at the moment 'ego'
        """
        # get configuration file
        self.mass = mass
        super(AutomatedVehicleAgent, self).__init__(world, start_transform, name)
        self.ego_config = self.config_file['ego parameters']

        # testing if classes are working
        debug_config = self.config_file['ego debugging options']
        self._debug = debug_config['debug']
        if self._debug:
            self.debug_handler = EgoDebugger(world, debug_config, self.ego_config)

        used_responses = get_ego_responses(0.5)
        self.event_handler = EventHandler(used_responses, self.ego_config['event handler config'])

        self.last_location = None
        self.set_target_speed(target_speed)
        self.param_target_speed = target_speed
        self.obstacle_sensor_angles = list(range(-90, 90, 5))
        self.obstacles_sensors = []
        self.front_sensors = []
        self._add_obstacle_sensors()
        self._add_front_sensors()

        self.destination = target_location.location

        self.is_finished = False
        self.debug = False

        self.last_points = []
        self.intersection_situation = False
        self.intersection_resulting_speed = target_speed
        self.spotted_actors = {}
        self.check_again = 0.25
        self.multiple_actors = False

    @display_params
    def run_step(self, debug: bool = False) -> carla.VehicleControl:
        """
        Method that executes a simulation step

        Usage
        -----
        this is a modified version of the behavior agent run step method but is implemented equal
            - this method returns a carla.VehicleControl
            - to move the vehicle you need to call .apply_control(control) /n

        :return: control of the actor
        """
        # call debugging methods
        if self._debug:
            self.debug_handler.debug_frame(self)

        control = self._local_planner.run_step()

        if self.actor.get_location().distance(self.destination) < 2:
            self.is_finished = True

        if self._local_planner.done():
            self.is_finished = True

        control = self.event_handler.get_response(self, control)
        return control

    def set_dest(self, end_location):
        """
        Method to set the destination of the actor.

        :param end_location: carla location of the destination
        """
        self.destination = end_location
        start_location = self.spawn_transform.location
        clean_queue = True
        start_waypoint = self._map.get_waypoint(start_location)
        end_waypoint = self._map.get_waypoint(end_location)
        route_trace = self.trace_route(start_waypoint, end_waypoint)

        self._local_planner.set_global_plan(route_trace, clean_queue=clean_queue)

    def stop(self):
        """
        Stops the agent, i.e. stops all its sensors.
        """
        for os in self.obstacles_sensors:
            os.destroy()

        for fs in self.front_sensors:
            fs.destroy()

    def _add_obstacle_sensors(self):
        """
        Method that adds obstacle sensors for the detection of parking vehicles to the AV.
        """
        os_blueprint = self.actor.get_world().get_blueprint_library().find('sensor.other.obstacle')
        os_blueprint.set_attribute('distance', str(self.ego_config))
        os_blueprint.set_attribute('hit_radius', '1')
        os_blueprint.set_attribute('only_dynamics', 'true')
        os_blueprint.set_attribute('sensor_tick', '0.003')
        for a in self.obstacle_sensor_angles:
            transform = carla.Transform(carla.Location(0, 0, 1), carla.Rotation(yaw=a))
            os = self.actor.get_world().spawn_actor(os_blueprint, transform, attach_to=self.actor)
            os.listen(self.event_handler.add_event)
            self.obstacles_sensors.append(os)

    def _add_front_sensors(self):
        """
        Method to add front sensors with small and large range
        """
        short_sensor_length = self.ego_config['short sensor length']
        short_angle_difference = self.ego_config['difference angle short']
        start_angle_short = self.ego_config['start angle short']
        mid_sensor_length = self.ego_config['mid sensor length']
        mid_angle_difference = self.ego_config['difference angle mid']
        start_angle_mid = self.ego_config['start angle mid']

        short_sensor_angles = list(range(- start_angle_short, start_angle_short, short_angle_difference))
        short_sensor_distance = short_sensor_length

        middle_sensor_angles = list(range(-start_angle_mid, start_angle_mid, mid_angle_difference))
        middle_sensor_distance = mid_sensor_length

        os_blueprint = self.actor.get_world().get_blueprint_library().find('sensor.other.obstacle')
        os_blueprint.set_attribute('distance', str(short_sensor_distance))
        os_blueprint.set_attribute('hit_radius', '{}'.format(self.ego_config['radius obstacle sensor']))
        os_blueprint.set_attribute('only_dynamics', 'true')
        os_blueprint.set_attribute('sensor_tick', '0.003')

        # add short range sensors
        for a in short_sensor_angles:
            transform = carla.Transform(carla.Location(0, 0, 1), carla.Rotation(yaw=a))
            os = self.actor.get_world().spawn_actor(os_blueprint, transform, attach_to=self.actor)
            os.listen(self.event_handler.add_event)
            self.front_sensors.append(os)

        # add middle range sensors
        os_blueprint.set_attribute('distance', str(middle_sensor_distance))
        for a in middle_sensor_angles:
            transform = carla.Transform(carla.Location(0, 0, 1), carla.Rotation(yaw=a))
            os = self.actor.get_world().spawn_actor(os_blueprint, transform, attach_to=self.actor)
            os.listen(self.event_handler.add_event)
            self.front_sensors.append(os)

    @abstractmethod
    def get_blueprint(self) -> str:
        # blueprint_options = {
        #     1: 'vehicle.nissan.micra',           # 960
        #     2: 'vehicle.ford.mustang',           # 1400
        #     3: 'vehicle.jeep.wrangler_rubicon',  # 1900
        #     4: 'vehicle.nissan.patrol'           # 2355
        # }
        # blueprint_number = math.floor(self.mass / 600)
        # return blueprint_options[blueprint_number]
        return "vehicle.tesla.model3"
