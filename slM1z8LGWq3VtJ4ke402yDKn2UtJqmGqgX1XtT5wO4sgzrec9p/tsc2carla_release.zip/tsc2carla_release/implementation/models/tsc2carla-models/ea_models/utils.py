import carlametrics.metrics.utils as metric_utils
from functools import wraps
from typing import Callable
import colorsys
import numpy as np
import math
import carla
from ea_models.simulation_actor import SimulationActor


class ColorUtils:

    @staticmethod
    def rgb_to_hex(r, g, b):
        return "#{:02x}{:02x}{:02x}".format(r, g, b)

    @staticmethod
    def hex_to_carla(hex_color: str):
        rgb = ColorUtils.hex_to_rgb(hex_color)
        return carla.Color(rgb[0], rgb[1], rgb[2])

    @staticmethod
    def hex_to_rgb(hex_color):
        if type(hex_color) is tuple:
            return hex_color
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))

    @staticmethod
    def rgb_to_hsl(r, g, b):
        r /= 255.0
        g /= 255.0
        b /= 255.0
        cmax = max(r, g, b)
        cmin = min(r, g, b)
        delta = cmax - cmin
        lightnis = (cmax + cmin) / 2

        if delta == 0:
            hue = saturation = 0
        else:
            saturation = delta / (2 - cmax - cmin) if lightnis > 0.5 else delta / (cmax + cmin)
            if cmax == r:
                hue = ((g - b) / delta) % 6
            elif cmax == g:
                hue = (b - r) / delta + 2
            else:
                hue = (r - g) / delta + 4
            hue /= 6

        return (hue * 360, saturation * 100, lightnis * 100)

    @staticmethod
    def hsl_to_rgb(hue, saturation, lightnis):
        saturation /= 100
        lightnis /= 100
        c = (1 - abs(2 * lightnis - 1)) * saturation
        x = c * (1 - abs((hue / 60) % 2 - 1))
        m = lightnis - c / 2
        if hue < 60:
            r, g, b = c, x, 0
        elif hue < 120:
            r, g, b = x, c, 0
        elif hue < 180:
            r, g, b = 0, c, x
        elif hue < 240:
            r, g, b = 0, x, c
        elif hue < 300:
            r, g, b = x, 0, c
        else:
            r, g, b = c, 0, x
        return (int((r + m) * 255), int((g + m) * 255), int((b + m) * 255))

    @staticmethod
    def hex_to_hsl(hex_color):
        return ColorUtils.rgb_to_hsl(*ColorUtils.hex_to_rgb(hex_color))

    @staticmethod
    def hsl_to_hex(hue, saturation, lightnis):
        return ColorUtils.rgb_to_hex(*ColorUtils.hsl_to_rgb(hue, saturation, lightnis))

    @staticmethod
    def blend_colors(hex_color1, hex_color2, ratio):
        """Blends two hexadecimal colors based on the specified ratio."""

        # Convert hex colors to RGB
        rgb1 = ColorUtils.hex_to_rgb(hex_color1)
        rgb2 = ColorUtils.hex_to_rgb(hex_color2)

        # Convert RGB to HSL
        hsl1 = colorsys.rgb_to_hls(*[x / 255 for x in rgb1])
        hsl2 = colorsys.rgb_to_hls(*[x / 255 for x in rgb2])

        # Blend hues
        h1, h2 = hsl1[0], hsl2[0]
        hue_between = max(h1, h2) - min(h1, h2)
        blended_hue = min(h1, h2) + ratio * hue_between

        # Construct the new HSL color and convert it back to RGB, then to Hex
        blended_hsl = (blended_hue, hsl1[1], hsl1[2])
        blended_rgb = colorsys.hls_to_rgb(*blended_hsl)
        rgb = [int(x * 255) for x in blended_rgb]
        blended_hex = ColorUtils.rgb_to_hex(rgb[0], rgb[1], rgb[2])

        return blended_hex


def get_time_to_intersection(ego_location, ego_velocity, act_location, act_velocity):
    """
    Method returning the time until the actors get to the intersection.
    :return: if there is an intersection -> ego_time, act_time
             else -> math.inf, math.inf
    """

    # initialize variables
    act_speed = act_velocity.length()
    ego_speed = ego_velocity.length()

    if act_speed * ego_speed == 0:
        return math.inf, math.inf

    # Use the get intersection of paths method from metric class (is static)
    intersection_point = metric_utils.get_intersection_point_of_paths(
        actor_location=act_location,
        actor_velocity=act_velocity,
        ego_location=ego_location,
        ego_velocity=ego_velocity,
        allow_locations_behind=False
    )

    # catching the case when the 2 actors will not intersect in the future
    if intersection_point == carla.Location(x=math.inf, y=math.inf, z=math.inf):
        return math.inf, math.inf

    # if the actors do not have a speed of 0 we calculate the time
    ego_time = intersection_point.distance(ego_location) / ego_speed
    act_time = intersection_point.distance(act_location) / act_speed

    return ego_time, act_time


def get_diff_angle(vector_1: carla.Vector3D, vector_2: carla.Vector3D):
    """
    calculates the difference between 2 vectors in relation to the first input \n

    Return
    ------
    - if one input is None or has length 0 --> None
    - else                                 --> Angle between

    Parameter
    ---------
    :param vector_1: vector for which the angle difference should be calculated
    :param vector_2: vector to which the angle should be

    :return: angle or None
    """
    if vector_1.length() == 0 or vector_2.length() == 0 or vector_1 is None or vector_2 is None:
        return None

    vector_1 = vector_1.make_unit_vector()
    vector_2 = vector_2.make_unit_vector()

    cross_product = vector_1.cross(vector_2)
    combined_vector = vector_1 + vector_2

    # done to check if the 2 vectors point in different or in the same direction
    # in both cases the cross product would be 0
    same_direction = combined_vector.length() < 1

    angle_between = np.rad2deg(cross_product.length())
    angle_between = 180 - angle_between if same_direction else angle_between

    return angle_between


def sigmoid(center_x: float, y_min: float, y_max: float, streach_x: float) -> Callable:
    y_diff = y_max - y_min

    def function(x: float) -> float:
        return y_diff / (1 + np.exp(- 1 / streach_x * (x - center_x))) + y_min

    return function


def display_params(func):

    @wraps(func)
    def decorated(*args, **kwargs):

        # check if the decorater can be applied
        if not isinstance(args[0], SimulationActor):
            print("Use the display params decorator only \
                  in the run_step method of class extending SimulationActor")
            return func(*args, **kwargs)

        new_control = func(*args, **kwargs)

        self = args[0]
        location = self.get_location()
        print_loc = location + carla.Vector3D(z=2)

        # get relevant values
        speed = "{:3.1f}".format(self.get_speed())
        steer = "{:1.2f}".format(new_control.steer)
        brake = new_control.brake
        throttle = new_control.throttle
        driver_input = "{:1.2f}".format(throttle - brake)

        # create string to display from values
        disp_string = "{:^40s}\n".format(self.name)
        disp_string += "Speed:{:>33s}\n".format(speed)
        disp_string += "Steer:{:>33s}\n".format(steer)
        disp_string += "Input:{:>33s}".format(driver_input)

        # print string
        self.world.debug.draw_string(print_loc, disp_string, color=ColorUtils.hex_to_carla("#000000"))
        return new_control

    return decorated
