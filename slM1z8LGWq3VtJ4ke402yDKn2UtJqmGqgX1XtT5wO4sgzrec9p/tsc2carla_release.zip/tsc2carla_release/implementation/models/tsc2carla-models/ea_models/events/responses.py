from abc import abstractmethod
from typing_extensions import Deque
from typing import List
import numpy as np
import carla

from ea_models.simulation_actor import SimulationActor
from ea_models.utils import get_time_to_intersection, sigmoid
from ea_models.events.debug_decorator import debug


class ResponseSuper:
    """
    Super method for all responses.
    To implement a new response the get response method must be implemented and it must return a new driving input within -1 to 1.
    """
    ego: SimulationActor
    ego_location = carla.Location()
    ego_velocity = carla.Vector3D()
    act_location = carla.Location()
    act_velocity = carla.Vector3D()
    event_type = "no risk"

    def __init__(self, aggression: float, scale: float = 1):
        self.aggression = aggression
        self.scale = scale

    def update(self, ego: SimulationActor, act, event_type: str):
        ResponseSuper.ego = ego
        ResponseSuper.event_type = event_type
        ResponseSuper.ego_location = ego.get_location()
        ResponseSuper.ego_velocity = ego.get_velocity()
        ResponseSuper.act_location = act.get_location()
        ResponseSuper.act_velocity = act.get_velocity()
        # print(f'updated: {self}')

    @staticmethod
    def excluded_events() -> List[str]:
        return []

    @abstractmethod
    def __str__(self) -> str:
        pass

    @abstractmethod
    def calculate_response(self, driver_input: float) -> float:
        pass

    def __call__(self, driver_input: float) -> float:
        if ResponseSuper.event_type in self.excluded_events():
            response = driver_input
        else:
            response = self.calculate_response(driver_input)
        # print(f'{self}: {driver_input} -> {response}')
        return response


class IntersectionResponse(ResponseSuper):
    """
    This response applies to intersection events.

    Effects
    -------
    Acceleration:
        - increases: if ego needs less time to intersection and both would collide if no one acts
        - decreases: if ego needs more time to intersection and both would collide if no one acts
    Break:
        - if ego needs more time to intersection and both would collide if no one acts
    """

    def __init__(self, aggression: float, scale: float = 0.25):
        super().__init__(aggression, scale)

    def __str__(self) -> str:
        return "Intersection Response"

    @staticmethod
    def excluded_events() -> List[str]:
        return ['no risk', 'following']

    def calculate_response(self, driver_input: float) -> float:
        ego_time, act_time = get_time_to_intersection(
            ego_location=self.ego.get_location(),
            ego_velocity=self.ego.get_velocity(),
            act_location=self.act_location,
            act_velocity=self.act_velocity
        )

        difference = abs(ego_time - act_time) * self.scale
        average_time = (ego_time + act_time) / 2

        # the response should be more radical if this differece and the time until they intersect is small
        # a high agrission level makes the driver more resistent to a possible collision
        response = (1 - self.aggression - self.scale) / (difference * average_time)

        # adjust to previous driving input
        new_input = driver_input - response if act_time < ego_time else driver_input + response
        new_input = min(max(new_input, -1), 1)
        # print(f'react to intersection conflict {ego_time=} {act_time=} {new_input=}')

        return new_input


class FollowingResponse(ResponseSuper):
    """
    Response for following scenarios

    Effects
    -------
    Acceleration:
        - increases: ego far behind or actor before ego accelerates
        - decreases: actor brakes or distance is small
    Break:
        - small distance to actor in front of ego
    """

    def __init__(self, aggression: float, scale: float = 0):
        super().__init__(aggression, scale)
        self._distance_increase = 1 + aggression + scale

    def __str__(self) -> str:
        return "Following Response"

    @staticmethod
    def excluded_events() -> List[str]:
        return ['no risk', 'intersect']

    @debug
    def calculate_response(self, driver_input: float) -> float:
        distance = self.ego_location.distance(self.act_location)
        ego_speed = self.ego.get_speed()
        act_speed = self.act_velocity.length()

        wanted_distance = 5 + self._distance_increase * ego_speed
        driver_input += (distance - wanted_distance) / 40
        driver_input += act_speed / ego_speed - 1 if ego_speed != 0 else 0

        return min(max(driver_input, -1), 1)


class DeadlockResponse(ResponseSuper):
    """
    Response for deadlock situations. Does full exceleration if both actors have a small enough speed

    Effects
    -------
    Acceleration:
        - increases: if the ego and the actor have small enough speeds
        - decreases: never
    Break:
        - never
    """

    def __init__(self, aggression: float, scale: float = 0.5):
        super().__init__(aggression, scale)
        self.frame_deadlock = 0
        self.threshold = aggression * scale * 10

    def __str__(self) -> str:
        return "Deadlock Response"

    @staticmethod
    def excluded_events() -> List[str]:
        return ['no risk']

    def calculate_response(self, driver_input: float) -> float:
        # get parameters
        ego_speed = self.ego.get_speed()
        act_speed = self.act_velocity.length()

        # count down so that a duration of acceleration is defined.
        self.frame_deadlock -= 1

        # if both actors are slower then the speed threshold, the actor implementing this response will accelerate
        # for the next 30 frames minimum
        if ego_speed < self.threshold and act_speed < self.threshold:
            self.frame_deadlock = (self.aggression + self.scale) * 30

        # returns driving input if the acceleration has not started yet
        return driver_input if self.frame_deadlock <= 0 else 1


class ParallelCombResponse(ResponseSuper):
    def __init__(self, aggression: float, *responses):
        scale = sum([response.scale for response in responses]) / len(responses)
        super().__init__(aggression, scale)
        self.sub_responses = responses

    def __str__(self) -> str:
        return "Parallel Responses"

    @staticmethod
    def excluded_events() -> List[str]:
        return []

    def calculate_response(self, driver_input: float) -> float:
        value_vector = np.array([response(driver_input) for response in self.sub_responses])
        value_vector = (value_vector + 1) * 0.5
        theta = - (1 - self.aggression) * (1 - self.scale)
        soft_min = np.exp(theta * value_vector) / sum(np.exp(theta * value_vector))
        soft_min = np.min(soft_min)
        return float(soft_min * 2 - 1)


class TrajectoryDistance(ResponseSuper):
    """
    Response for trajectory distance adjustments

    Effects
    -------
    Acceleration:
        - increases: if the other actors minimal distance to the planned trajectory of the ego is large
        - decreases: never
    Break:
        - if breaking the input is passt
    """

    def __init__(self, aggression: float, scale: float = 0):
        super().__init__(aggression, scale)
        self.sig_func = sigmoid(center_x=5 - scale, y_min=1, y_max=1 + (scale + aggression) * 0.5, streach_x=2 - aggression - 0.5 * scale)

    def __str__(self) -> str:
        return "Trajectory Distance"

    @staticmethod
    def excluded_events() -> List[str]:
        return ['intersection']

    def calculate_response(self, driver_input: float) -> float:
        if driver_input < 0:
            return driver_input

        waypoint = self.ego.get_waypoint(self.ego_location)
        waypoints = waypoint.next_until_lane_end(1)

        distance = self.act_location.distance(waypoint.transform.location)
        new_distance = 0
        waypoints = waypoints[1:]

        while len(waypoints) > 0:
            new_distance = self.act_location.distance(waypoints[0].transform.location)
            if distance < new_distance:
                break
            else:
                distance = new_distance
                waypoints = waypoints[1:]

        driver_input = driver_input * self.sig_func(distance)

        return min(max(driver_input, -1), 1)


class OtherActorDetected(ResponseSuper):

    def __init__(self, aggression: float, scale: float = 0.4):
        super().__init__(aggression, scale)
        self.threshold = (1 - aggression) * (1 - scale) * 20
        self.min_speed = 10 * aggression + 10 * scale

    def __str__(self) -> str:
        return "Other Actor Detected"

    @staticmethod
    def excluded_events() -> List[str]:
        return ['following', 'intersection']

    def calculate_response(self, driver_input: float) -> float:
        distance = self.ego_location.distance(self.act_location)
        # print(f'{distance=} {(self.act_location.x, self.act_location.y, self.act_location.z)}')

        if distance < self.threshold and self.ego.get_speed() > self.min_speed:
            driver_input = min(driver_input, -0.1 - 0.2 * self.aggression - 0.2 * self.scale)

        return driver_input


class TimeSeriesEval(ResponseSuper):

    def __init__(self, aggression: float, scale: float = 0):
        super().__init__(aggression, scale)
        # we determin the weight of an value, by deviding the couple position.
        # where the couple_size determins how many values after each other have the same weight.
        # For example: we have 3 couples with a size 2 items, then the result should be: [1, 1, 0.5, 0.5, 0.25, 0.25]
        couple_size = 10
        number_couples = 6
        self._eval_array = np.array([1 / (2 ** i) for i in range(number_couples) for _ in range(couple_size)])
        self._history = Deque(np.zeros((1, couple_size * number_couples)).tolist()[0])

        self._history_weight = 1 - 0.5 * (self.aggression + self.scale)
        self._hard_brake_threshold = -0.3

    def __str__(self) -> str:
        return "Time Series Eval"

    @staticmethod
    def excluded_events() -> List[str]:
        return ['no risk']

    @debug
    def calculate_response(self, driver_input: float) -> float:
        # add the import obtained as the newest, and remove the oldest.
        self._history.appendleft(driver_input)
        self._history.pop()

        summed_eval = np.sum(self._eval_array)
        addon_history = np.sum(self._eval_array * np.array(self._history)) / summed_eval

        valued_as = self._history_weight if driver_input > self._hard_brake_threshold else 0
        return (driver_input + addon_history * valued_as) / (1 + valued_as)
