from ea_models.simulation_actor import SimulationActor
from ea_models.utils import ColorUtils
from functools import wraps
import carla

# this is a directory containing all classnames
# at which te decorator is placed as keys and
# and the text/arrow offset as values
decorator_locations = {}
responses_reseived = {}


def debug(func):
    """
    This function should be used as decorator for the calculate_response method in an responses.
    The function wont change the behavior but it will plot response in the carla world so that the actor, to which the
    response is calculated and the response strength can be seen clearly.
    """
    global decorator_locations, responses_reseived

    @wraps(func)
    def decorated(*args, **kwargs):
        # get arguments from the
        # response which is decorated with this function
        self = args[0]
        in_driver_input = args[1]
        out_driver_input = func(*args, **kwargs)

        # get basic params to print
        name_of_class = str(args[0])
        div_input = out_driver_input - in_driver_input
        disp_values = [("Output:", out_driver_input), ("Input:", in_driver_input), ("Difference:", div_input)]

        # Initialize the string which should be printed
        printed_string = '{:5s} - {:^17s}\n'.format(self.ego.name[0].upper() + self.ego.name[1:], name_of_class)

        # iterate over all values which should be
        # printed and add them to the printed stirng
        for text, value in disp_values:
            sign = "+" if value > 0 else "-"
            printed_string += "{:<15s} {:^1s} {:^1.2f}\n".format(text, sign, abs(value))

        # linecolor is red if the difference is strongly
        # negative and green if the difference is strongly positive
        if name_of_class not in decorator_locations:
            decorator_locations[name_of_class] = len(list(decorator_locations.keys())) * 2

        # generates a color between
        hex_color = (ColorUtils.blend_colors('#24f26c', '#4931ff', (div_input + 1) / 2))
        line_color = ColorUtils.hex_to_carla(hex_color)

        # get relevant carla locations
        ego_location = self.ego_location
        vec_between = self.act_location - ego_location
        label_location = vec_between * (0.33 if vec_between.length() > 10 else - 0.33) + ego_location

        # set the z values to be uniform in hight for different actor
        # current offset prevents labels (a bit) from laying on top of each other
        current_offset = decorator_locations[name_of_class]
        vec_between.z = 0
        ego_location.z = 1 + current_offset
        label_location.z = 3 + current_offset

        # get debugger and print the parameters in the world
        carla_debug = self.ego.world.debug
        carla_debug.draw_arrow(ego_location, ego_location + vec_between, life_time=1 / 30, thickness=0.2 * abs(div_input), color=line_color)
        carla_debug.draw_string(label_location, printed_string, color=ColorUtils.hex_to_carla("#000000"))
        return out_driver_input

    return decorated


def debug_combination(func):
    """
    This function should be used as decorator. It wrapps the
    decorated function with a debugger.
    This debugger will prints all reponses which are executed above the vehicle.
    Just use this to decorate run step methods of vehicles responding to other vehicles.
    """
    @wraps(func)
    def decorated(*args, **kwargs):
        ego: SimulationActor = args[0]
        result = func(*args, **kwargs)
        handler = ego.event_handler

        if handler is None:
            return result

        return result

    raise NotImplementedError("Add Later")


class DataStorage:

    def __init__(self):
        self.actor_responses = {}
        self.bounding_boxes = {}
        self.observed_actors = {}
        self.transforms = {}

    def add_data(self, actor: SimulationActor):
        name = actor.name
        if name not in self.bounding_boxes:
            self.bounding_boxes[name] = actor.get_bounding_box()
            self.transforms[name] = []

        self.transforms[name].append(actor.get_transform())

    def get_act_data(self, actor):
        trafo = actor.get_transform()
        loc = trafo.location
        rot = trafo.rotation
        vel = actor.get_velocity()
        return {
            'location': (loc.x, loc.y, loc.z),
            'rotation': (rot.yaw, rot.roll, rot.pitch),
            'velocity': (vel.x, vel.y, vel.z)
        }

    def add_response_data(self, act_name: str, event_handler):
        if act_name not in self.actor_responses:
            self.actor_responses[act_name] = event_handler.responses

        if act_name not in self.observed_actors:
            self.observed_actors[act_name] = []

        act_params = [self.get_act_data(act) for act in event_handler.acts]
        self.observed_actors[act_name].append(act_params)


class Plotter:

    def __init__(self, data: DataStorage):
        self.data_stored = data


instance_data_storage = DataStorage()


def make_debug_replay(func):
    """
    This is supposed to be used as decorator of the run step method of at least
    Simulation actors.
    """

    @wraps(func)
    def decorated(*args, **kwargs):
        new_control = func(*args, **kwargs)

        if func.__name__ != 'run_step':
            print("Pragrammed Only as a decorator of the run step method of SimulationActors!")
            return new_control

        self: SimulationActor = args[0]
        instance_data_storage.add_data(self)

        if 'ped' in self.name:
            return new_control

        instance_data_storage.add_response_data(self.name, self.event_handler)
        obs_act_per_frame = instance_data_storage.observed_actors[self.name]
        test_past = 120

        if len(obs_act_per_frame) > test_past:
            bbox: carla.BoundingBox = instance_data_storage.bounding_boxes[self.name]
            trafo: carla.Transform = instance_data_storage.transforms[self.name][-test_past]
            bbox.location = trafo.location
            self.world.debug.draw_box(bbox, trafo.rotation, color=carla.Color(0, 200, 0, 0), life_time=1 / 15)

            for act in obs_act_per_frame[-test_past]:
                loc = act['location']
                x, y, z = loc[0], loc[1], loc[2]
                self.world.debug.draw_point(carla.Location(x=x, y=y, z=z) + carla.Vector3D(z=3), life_time=1 / 15, size=0.2, color=carla.Color(100, 0, 0, 0))
        return func(*args, **kwargs)

    return decorated
