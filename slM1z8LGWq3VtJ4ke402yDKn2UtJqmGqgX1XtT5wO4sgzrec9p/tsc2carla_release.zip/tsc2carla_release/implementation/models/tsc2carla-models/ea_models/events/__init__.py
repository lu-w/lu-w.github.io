from typing_extensions import Deque, Tuple
import carla
from ea_models.utils import get_time_to_intersection
from ea_models.events.responses import ResponseSuper, IntersectionResponse, FollowingResponse, DeadlockResponse, TrajectoryDistance, OtherActorDetected, TimeSeriesEval
from ea_models.simulation_actor import SimulationActor
from typing import List


def get_ego_responses(aggression: float) -> List[ResponseSuper]:
    """
    Returns a possible list of responses for the ego vehicle which can be used to initialize the EventHandler class
    """
    return [
        IntersectionResponse(aggression, 0.1),
        FollowingResponse(aggression, 0.1),
        TrajectoryDistance(aggression, 0.1),
        OtherActorDetected(aggression, 0.4),
        TimeSeriesEval(aggression, 0.2)
    ]


def get_bic_responses(aggression: float) -> List[ResponseSuper]:
    """
    Returns a possible list of responses for the bicycle agent which can be used to initialize the EventHandler class
    """
    return [
        FollowingResponse(aggression, 0.1),
        IntersectionResponse(aggression, 0.1),
        DeadlockResponse(aggression, 0.85),
        TrajectoryDistance(aggression, 1)
    ]


class EventHandler:
    """
    This class has the purpose to differentiate between the situations to which the ego vehicle will response.

    the corrent approuch is to collect events in each frame, where one event is the interaction between
    one actors and the ego. If the method get_response is called, for all actors is a response calculated and compared to
    each other.

    Usage
    -----
        1. At the start of each frame the events of the last must be cleared with `start_event_collection()`
        2. The events get then added with the method `add_event(event)`
        3. To get the responding speed for the ego call `get_response(ego)`
    """

    def __init__(
            self,
            used_responses: List[ResponseSuper],
            config: dict) -> None:
        """
        Consturctor of EgoEvent Class
        :return: None
        """
        self.responses = used_responses

        self.ego: SimulationActor
        self.acts = []
        self._calls = 0
        self._act_visible_frames = {}

        self._same_direction = config['same direction angle']
        self._intersec_threshold = config['max time to intersec']

        self._steer_history = Deque()
        [self._steer_history.appendleft(0) for _ in range(config['steer history length'])]
        self._steer_uncertainty_multiplier = config['steer uncertainty multiplier']

    def start_event_collection(self):
        """
        This method clears the currently saved events as well as all other parameters used for the response calculation.
        """
        self.acts = []

    def add_event(self, event):
        """
        Adds the event of a sensor to the events which need to be handled in the next response
        """
        act_id = event.other_actor.id
        # print(f'actor with id {act_id} ahead')
        if act_id not in self._act_visible_frames:
            self._act_visible_frames[act_id] = 0

        self._act_visible_frames[act_id] += 1
        self.acts.append(event.other_actor)

    def get_response(self, ego: SimulationActor, control):
        if len(self.acts) == 0:
            # print('no other actors in list')
            return control

        # print(f'other actors: {self.acts}')

        # define vars
        self.ego = ego
        act_responses = []

        # go throw all actors which are detected by the ego
        for act in self.acts:
            act_responses.append(self._get_response_to_act(act))

        respond = min(act_responses)

        if respond != 0:
            control = self._handle_driver_input(control, respond)

        # print(f'overall response: {respond} {control.throttle=} {control.brake=}')

        self.acts = []
        return control

    def _get_response_to_act(self, act) -> float:
        """ Method to return the response as a driver_input for a given actor. """
        driver_input = 0.0
        event_type = self._get_event_type(act)
        self.responses[0].update(self.ego, act, event_type)
        input_progress = [driver_input]

        [input_progress.append(response(input_progress[-1])) for response in self.responses]

        return input_progress[-1]

    def _get_response_changes(self, act) -> List[Tuple[str, float]]:
        driver_input = 0.0
        event_type = self._get_event_type(act)
        self.responses[0].update(self.ego, act, event_type)

        input_progress = [driver_input]
        [input_progress.append(response(input_progress[-1])) for response in self.responses]

        return [(str(response), value) for response, value in zip(self.responses, input_progress)]

    def _get_event_type(self, act) -> str:
        """
        Method returning the event type.
        :return: one of the following strings 'following', 'intersec' or 'no risk'
        """
        if self._check_if_following(act):
            return 'following'

        if self._check_if_intersection(act):
            return 'intersec'

        return 'no risk'

    def _check_if_following(self, act) -> bool:
        """
        Returns true if the ego follows the actor
        """
        ego_direction = self.ego.get_transform().rotation.yaw
        act_direction = act.get_transform().rotation.yaw

        # The following looks scatchy, but as in curves the vehicle can still follow,
        # but have different angles in most cases (as the leading is further in the curve),
        # we need to adjust the categorization respectively.

        # As carla steers super hard or not at all we need to calculate
        # the average over past frames to obtain reasonable values
        self._steer_history.append(self.ego.get_control().steer)

        # get angle
        steer_angle = sum(self._steer_history) / len(self._steer_history) * 45
        steer_uncertainty_addon = steer_angle
        ego_direction += steer_angle
        angle = ego_direction - act_direction
        self._steer_history.popleft()

        return angle is not None and abs(angle) < self._same_direction + steer_uncertainty_addon

    def _check_if_intersection(self, act) -> bool:
        """
        Returns true if the ego and the other actor intersect each other
        """
        ego_location = self.ego.get_location()
        act_location = act.get_location()

        # to ensure that the other actor is not behind the ego
        point_behind_ego = ego_location - self.ego.get_forward_vector()
        if ego_location.distance_2d(act_location) > point_behind_ego.distance_2d(act_location):
            return False

        ego_velocity = self.ego.get_velocity()
        act_velocity = act.get_velocity()

        act_time, ego_time = get_time_to_intersection(ego_location, ego_velocity, act_location, act_velocity)

        return act_time < self._intersec_threshold or ego_time < self._intersec_threshold

    @staticmethod
    def _handle_driver_input(control, input) -> carla.VehicleControl:
        if input > 0:
            control.throttle = input
            control.brake = 0.0
        else:
            control.brake = - input
            control.throttle = 0.0

        return control
