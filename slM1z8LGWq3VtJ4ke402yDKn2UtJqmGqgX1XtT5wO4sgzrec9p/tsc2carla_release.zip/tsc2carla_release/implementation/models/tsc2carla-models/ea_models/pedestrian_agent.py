from abc import abstractmethod
import math

import carla
import numpy as np
from ea_models.simulation_actor import SimulationActor


class PedestrianAgent(SimulationActor):
    """
    Agent that controls a Pedestrian in the Carla simulator. Extended version of the Carla Walker AI.
    Ensures that the agents of AVS, bicycles and pedestrians have similar methods.
    """

    def __init__(self,
                 world: carla.World,
                 mass: float,
                 start_transform: carla.Transform,
                 target_speed: float,
                 name: str = 'ped'):
        """
        Creates an Agent that extends the Carla Walker AI
        :param target_speed: the target speed of the agent (in m/s)
        """
        self.mass = mass
        super().__init__(world, start_transform, name, initialize_behavior_agent=False)

        self.is_finished = False
        self.last_jump = 0

        # add controller to the actor so that it possible to control him
        # The carla documentation states that the start() method of the ai controller enables the ai control.
        # this is wrong the method start causes the walker to stay in place.
        controller_blueprint = self.world.get_blueprint_library().find('controller.ai.walker')
        controller_blueprint.set_attribute('role_name', name)
        self.controller = self.world.spawn_actor(controller_blueprint, start_transform, self.actor)

        self.config = self.config_file['pedestrian config']

        self.destination_list = []
        self.speed = target_speed
        self.target_speed = target_speed
        self.route_trace = []
        self._speed_eps = self.config['speed epsilon teleport up']
        self._tp_height = self.config['teleport height']
        self._tp_possibility_duration = self.config['duration between teleports']
        self._next_tp_possible_in = 120

    @staticmethod
    def angle_between_vectors(v1: carla.Vector3D, v2: carla.Vector3D) -> float:
        """
        method to get the angle between 2 vectors
        """
        dot_product = np.dot(v1, v2)
        magnitude_v1 = np.linalg.norm(v1)
        magnitude_v2 = np.linalg.norm(v2)
        if magnitude_v1 * magnitude_v2 == 0:
            denominator = 1
        else:
            denominator = magnitude_v1 * magnitude_v2

        if dot_product != 0:
            cosine_angle = dot_product / denominator
        else:
            cosine_angle = 0

        angle_rad = np.arccos(cosine_angle) if -1 < cosine_angle < 1 \
            else np.arccos(cosine_angle - math.floor(cosine_angle))
        angle_deg = np.degrees(angle_rad)

        cross_product = np.cross(v1, v2)

        if cross_product < 0:
            angle_deg = -angle_deg

        return angle_deg

    @staticmethod
    def rotate_vector(vector, angle_deg):
        """
        Used to make the turn of the walker when reaching a waypoint more realistic
        """
        angle_rad = np.radians(angle_deg)

        rotation_matrix = np.array([
            [np.cos(angle_rad), -np.sin(angle_rad)],
            [np.sin(angle_rad), np.cos(angle_rad)]
        ])

        rotated_vector = np.dot(rotation_matrix, vector)

        return rotated_vector

    def set_destination_with_locations(self, destination_list: list):
        """
        Sets the destination of the pedestrian.
        :param destination_list: carla location of the destination
        """
        self.destination_list = destination_list

    def get_direction_of_next_waypoint(self) -> carla.Vector3D:
        """
        Methode to calculate next direction
        returns a carla 3 d vector wih len 1 which represents the direction in which the pedestrian has to wolk to
        get the next waypoint
        :param control: control of the actor
        """
        current_wp = 5 - len(self.destination_list)
        current_location = self.get_location()
        control = self.get_control()

        if current_wp == 4:
            return carla.Vector3D(x=control.direction.x, y=control.direction.y)

        target_location = self.destination_list[0]
        vec_between = np.array([target_location.x - current_location.x, target_location.y - current_location.y])
        norm = np.linalg.norm(vec_between)

        if norm == 0:
            return carla.Vector3D(x=vec_between[0] / norm, y=vec_between[1] / norm)

        vec_between = vec_between / norm
        vec_previous_direction = np.array([control.direction.x, control.direction.y])

        # degrees between the wanted direction and the one which is indicated by the control
        angle_diff = self.angle_between_vectors(vec_previous_direction, vec_between)

        if math.fabs(angle_diff) > self.config['threshold direction adjustment'] \
                and current_wp > 1:
            vec_between = self.rotate_vector(vec_previous_direction, angle_diff * 0.05)
        elif current_wp == 1:
            self.rotate_vector(vec_previous_direction, angle_diff)

        rotation_vector = carla.Vector3D(x=vec_between[0], y=vec_between[1], z=0)

        if self.config['draw direction arrow']:
            print(vec_previous_direction)
            print(vec_between)
            print(rotation_vector)
            self.world.debug.draw_arrow(current_location, target_location, color=carla.Color(0, 0, 250), life_time=0.1)
            self.world.debug.draw_arrow(current_location,
                                        carla.Location(current_location.x + 3 * rotation_vector.x,
                                                       current_location.y + 3 * rotation_vector.y,
                                                       z=0),
                                        color=carla.Color(255, 0, 0),
                                        life_time=0.1)

        return rotation_vector

    def update(self):
        self.bounding_box = self.actor.bounding_box

    def run_step(self, debug: bool = False):
        """
        iterates throw one simulation step or one frame in time for the pedestrian
        returns a control object which than can be given to the control wrapper

        :return: control of the actor
        """
        if self.is_finished:
            return self.get_control()

        # 5 is used so that current_wp = 1 is the first waypoint
        current_wp = 5 - len(self.destination_list)
        distance_waypoint = self.get_location().distance(self.destination_list[0])
        reached_checkpoint = distance_waypoint < self.config['threshold checkpoint']

        # if actor is close enough to the next waytpoint
        if reached_checkpoint and current_wp <= 3:
            self.destination_list = self.destination_list[1:]

        # sometimes useful for debugging purposes
        if reached_checkpoint and self.config['print reaching of checkpoints']:
            print('Pedestrian reached checkpoint {:d}/4'.format(current_wp))

        # set finish to true if at last checkpoint
        if current_wp == 4:
            self.is_finished = True
            return self.actor.get_control()

        vec_direction = self.get_direction_of_next_waypoint()

        if abs(self.speed - self.target_speed) > self._speed_eps and self._next_tp_possible_in <= 0:
            print("Ported")
            act_location = self.actor.get_location()
            self.actor.set_location(act_location + carla.Vector3D(z=self._tp_height))
            self._next_tp_possible_in = self._tp_possibility_duration
        elif self._next_tp_possible_in > 0:
            self._next_tp_possible_in -= 1

        # set parameters of control
        control = carla.WalkerControl()
        control.speed = self.speed
        control.direction = vec_direction
        return control

    def get_blueprint(self):
        """
        Method that gets a pedestrian blueprint that corresponds to the mass.
        :param mass: mass of the pedestrian
        :return: carla blueprint that corresponds to the mass
        """
        return 'walker.pedestrian.0001'

    def stop(self) -> None:
        self.controller.stop()
        self.actor.destroy()
