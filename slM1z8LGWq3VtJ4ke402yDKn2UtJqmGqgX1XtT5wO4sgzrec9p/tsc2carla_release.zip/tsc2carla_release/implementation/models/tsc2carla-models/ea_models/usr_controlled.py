from abc import abstractmethod
import math
from typing import List

import carla
import pygame
import numpy as np
import json

from ea_models.simulation_actor import SimulationActor


class ControlledBic(SimulationActor):

    def __init__(
            self,
            world,
            spawn_transform: carla.Transform,
            name: str = 'UserControlled',
            save_to_json: bool = False,
            vehicle_blueprint_name: str = 'vehicle.diamondback.century') -> None:
        """
        Constructor for an actor which is controled by the user of the application.

        Recording
        ---------
        The actor can be recorded by pressing enter.
            - the recorded data contains the values for the creation of an spawn transform and the values for the creation of an control object.
            - data can be obtained with self.get_recorded_control() or saved to a json file with self.save_recorded_control().
            - The status of the recording can be obtained by the method self.finished_recording() which will return true if the recording was finished.

        """
        # get blueprint and configuration parameters, initilize super
        self._used_blueprint = vehicle_blueprint_name
        super().__init__(world, spawn_transform, name, False)
        self._config = self.config_file['user controlled']

        # initilize the surface of the game
        pygame.init()
        disp_param = (self._config['display width'], self._config['display height'])
        init_image = np.random.randint(0, 255, (disp_param[0], disp_param[1], 3), dtype='uint8')
        self.surface = pygame.surfarray.make_surface(init_image.swapaxes(0, 1))

        # create the camera from which the data is used in the pygame view
        camera_init_trans = carla.Transform(carla.Location(x=-5, z=3), carla.Rotation(pitch=-20))
        camera_bp = self.world.get_blueprint_library().find('sensor.camera.rgb')
        camera_bp.set_attribute('image_size_x', str(disp_param[0]))
        camera_bp.set_attribute('image_size_y', str(disp_param[1]))
        self._camera = self.world.spawn_actor(camera_bp, camera_init_trans, attach_to=self.actor)
        self._camera.listen(lambda image: self._pygame_callback(image))

        # initialize game view
        self._gameDisplay = pygame.display.set_mode(disp_param, pygame.HWSURFACE | pygame.DOUBLEBUF)
        self._gameDisplay.fill((0, 0, 0))
        self._gameDisplay.blit(self.surface, (0, 0))

        # initialize recording parameters
        self._recording = False
        self._rec_start_transform = spawn_transform
        self._control_list = []
        self._finished_recording = False
        self._save_to_json = save_to_json

        pygame.display.flip()
        print("Everything called")

    def _pygame_callback(self, data):
        """ Callback method for the transformation of the camera data to the pygame data """
        img = np.reshape(np.copy(data.raw_data), (data.height, data.width, 4))
        img = img[:, :, :3]
        img = img[:, :, ::-1]
        self.surface = pygame.surfarray.make_surface(img.swapaxes(0, 1))

    def _handle_key_down_event(self, control: carla.VehicleControl, event):
        """
        method to handle key down events.

        :param control: curently used control
        :param event: pygame event cantaining the key instance variable
        :return: control respecting the key events
        """
        if event.key == pygame.K_SPACE:
            control.hand_brake = True

        if event.key == pygame.K_LEFT:
            initial_step = -0.8 / (math.sqrt(self.get_velocity().length()) + 1)
            control.steer = initial_step if control.steer == 0 else max(control.steer * 1.2, -1)

        if event.key == pygame.K_RIGHT:
            initial_step = 0.8 / (math.sqrt(self.get_velocity().length()) + 1)
            control.steer = initial_step if control.steer == 0 else min(control.steer * 1.2, 1)

        if event.key == pygame.K_UP:
            control.throttle = 1

        if event.key == pygame.K_DOWN:
            control.brake = 0.5 if control.brake == 0 else control.brake * 1.3

        return control

    @staticmethod
    def _handle_key_up_event(control, event):
        """
        method to handle key up events.

        :param control: curently used control
        :param event: pygame event cantaining the key instance variable
        :return: control respecting the key events
        """
        if event.key == pygame.K_SPACE:
            control.hand_brake = False

        if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
            control.steer = 0

        if event.key == pygame.K_UP:
            control.throttle = 0

        if event.key == pygame.K_DOWN:
            control.brake = 0

        return control

    def _toggle_recording(self):
        if self._recording:
            self._recording = False

            if self._save_to_json:
                self.save_recorded_control()

            self._finished_recording = True
        else:
            self._rec_start_transform = self.get_transform()
            self._control_list = []
            self._recording = True

    def _parse_events(self, events: list = []) -> carla.VehicleControl:
        """
        Checks all pygame events which occured adjusts the control with respect to the key presses.
        :return: vehicle control for the next simulation step
        """
        control = self.get_control()
        for event in events:
            try:
                event.key
            except Exception:
                continue

            if event.key == pygame.K_RETURN and event.type == pygame.KEYUP:
                self._toggle_recording()

            if event.type == pygame.KEYDOWN:
                control = self._handle_key_down_event(control, event)

            if event.type == pygame.KEYUP:
                control = self._handle_key_up_event(control, event)

        return control

    def finished_recording(self) -> bool:
        """ Is true when a recording was completed """
        return self._finished_recording

    def get_recorded_control(self) -> dict:
        """
        returns the control of the actor which was generated within the recording time.
        """
        json_data = {'start params': None, 'controls': []}

        # Transform the carla.Transform objects to a json serializable format (dict)
        loc = self._rec_start_transform.location
        rot = self._rec_start_transform.rotation
        json_data['start params'] = {
            'x': loc.x, 'y': loc.y, 'z': loc.z,
            'pitch': rot.pitch, 'roll': rot.roll, 'yaw': rot.yaw
        }

        # Transform the carla.VehicleControl objects to a json serializable format (dict)
        json_data['controls'] = [
            {'throttle': ctrl.throttle, 'steer': ctrl.steer,
             'brake': ctrl.brake, 'hand_brake': ctrl.hand_brake}
            for ctrl in self._control_list
        ]
        return json_data

    def save_recorded_control(self, path: str = ''):
        """
        Method to save the recorded control and the start transform to a json file

        :param path: path to which the data should be saved. (Not directory!)
        """
        if path == '':
            path = self._config['default saving path']

        json_data = self.get_recorded_control()

        with open(path, 'w') as file:
            json.dump(json_data, file)

    @abstractmethod
    def run_step(self, debug: bool = False):
        # get events and adjust control
        events = pygame.event.get()
        new_control = self._parse_events(events=events)

        # update display
        self._gameDisplay.blit(self.surface, (0, 0))
        pygame.display.flip()
        self._gameDisplay.fill((0, 0, 0))

        # safe control and display a red circle if recording
        if self._recording:
            pygame.draw.circle(self.surface, '#ed1010', (15, 15), 20)
            self._control_list.append(new_control)

        # dont know why but it is needed to update the display again
        self._gameDisplay.blit(self.surface, (0, 0))
        pygame.display.flip()

        return new_control

    @abstractmethod
    def get_blueprint(self):
        return self._used_blueprint

    @abstractmethod
    def stop(self):
        self.actor.destroy()
        pygame.quit()


class UserReplay(SimulationActor):

    def __init__(
            self,
            world: carla.World,
            replay_data: dict,
            name: str = 'UserReplay',
            vehicle_blueprint_name: str = 'vehicle.diamondback.century') -> None:
        """
        Constructor for an actor which mirrors the inputs from the UserControlled-Actor.
        To work properly the UserControlled-Actor has to stand still at start of the record

        :param world: carla.World of the scenario
        :param replay_data: dict created by the UserControlled-Actor
        :param name: Role name of the created actor
        """
        self._used_blueprint = vehicle_blueprint_name

        # get the spawn transform in order to initialize the SimulationActor
        start_params = replay_data['start params']
        start_loc = carla.Location(start_params['x'], start_params['y'], start_params['z'])
        start_rot = carla.Rotation(yaw=start_params['yaw'], roll=start_params['roll'], pitch=start_params['pitch'])
        spawn_transform = carla.Transform(start_loc, start_rot)

        super().__init__(world, spawn_transform, name, False)

        # to prevent major memory usage use generator to obtain controls
        self.control_gen = self._get_control_gen(replay_data['controls'])

    @staticmethod
    def _get_control_gen(controls: List[dict]):
        """
        Returns a generator which (if called once per frame) returns the control from the user in this frame
        """
        while True:
            control = carla.VehicleControl()
            control.steer = controls[0]['steer']
            control.throttle = controls[0]['throttle']
            control.brake = controls[0]['brake']
            control.hand_brake = controls[0]['hand_brake']

            if len(controls) > 1:
                controls = controls[1:]

            yield control

    @abstractmethod
    def run_step(self, debug: bool = False):
        return next(self.control_gen)

    @abstractmethod
    def get_blueprint(self):
        return self._used_blueprint

    @abstractmethod
    def stop(self):
        self.actor.destroy()
