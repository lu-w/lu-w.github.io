import carla
import time
import json
import argparse
import math

from ea_models.automated_vehicle_agent import AutomatedVehicleAgent as AVAgent

parser = argparse.ArgumentParser(description="model runner")
parser.add_argument("--data", "-d", metavar='d', nargs=1, required=True, help="the input data file for the model")

args = parser.parse_args()
data_file = args.data[0]

file = open(data_file, "r")
data = json.load(file)
file.close()

print(data)

print("Sleeping 10s to wait for the scenario to be loaded")
time.sleep(10)

host = "127.0.0.1"
port = 2000
client_timeout = 2000

client = carla.Client(host, int(port))
client.set_timeout(client_timeout)

world = client.get_world()

vehicle_name = data["ego"]
target_speed = data["target_speed"]

start_heading = math.degrees(float(data["start_transform"][2]))
target_heading = math.degrees(float(data["target_location"][2]))

start_transform = carla.Transform(carla.Location(x=float(data["start_transform"][0]), y=-float(data["start_transform"][1]), z=2), carla.Rotation(yaw=start_heading, pitch=0, roll=0))
target_location = carla.Transform(carla.Location(x=float(data["target_location"][0]), y=-float(data["target_location"][1]), z=0), carla.Rotation(yaw=target_heading, pitch=0, roll=0))

agent = AVAgent(world=world, mass=900, start_transform=start_transform, target_location=target_location,
                target_speed=target_speed * 3.6, name=vehicle_name)

agent.set_dest(target_location.location)
actor = agent.get_vehicle()

blueprint_library = world.get_blueprint_library()
collision_sensor_blueprint = blueprint_library.find('sensor.other.collision')
collision_sensor = world.spawn_actor(collision_sensor_blueprint, carla.Transform(), attach_to=actor)


ticked = 40

last_tick = 0
while not agent.done():
    if ticked > 0:
        last_tick = world.wait_for_tick().frame
        ticked = ticked - 1
        continue
    elif ticked == 0:
        ticked = ticked - 1
        # TODO calculate x and y from start_heading
        actor.set_target_velocity(carla.Vector3D(x=target_speed, y=0, z=0))
    control = agent.run_step()
    # print(f'Ego speed = {actor.get_velocity().length()}')
    actor.apply_control(control)

    next_tick = world.wait_for_tick().frame
    if next_tick - last_tick != 1:
        print(f'Skip frames: {next_tick - last_tick - 1}')
    last_tick = next_tick
