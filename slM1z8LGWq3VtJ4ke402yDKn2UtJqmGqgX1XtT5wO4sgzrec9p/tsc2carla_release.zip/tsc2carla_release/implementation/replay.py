import sys
from pathlib import Path

import carla

host = "127.0.0.1"
port = 2000
client_timeout = 2000

client = carla.Client(host, int(port))
client.set_timeout(client_timeout)

scenario_nr = sys.argv[1]
log_base_path = Path('data_storage', 'traces', 'carla', 'recording').absolute()
log_path = list(log_base_path.glob(f'*_{scenario_nr}.log'))[0]
open_drive_path = log_path.parents[3].joinpath('scenarios').joinpath('drive' + log_path.stem[8:] + '.xodr')

open_drive = open_drive_path.read_text()

client.generate_opendrive_world(open_drive)
info = str(client.show_recorder_file_info(str(log_path), False))
print(info)
actor_id = 0
for l in info.split('\n'):
    l = l.strip()
    if l.startswith('Create '):
        actor_id = int(l.split(':', 1)[0].split()[1])
    elif l == 'role_name = VehicleA':
        break

client.replay_file(str(log_path), 0.0, 0.0, actor_id, False)

