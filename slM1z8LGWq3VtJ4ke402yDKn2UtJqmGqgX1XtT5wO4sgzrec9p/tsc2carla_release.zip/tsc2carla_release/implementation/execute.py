import os
import glob

import yaml as yl
from pathlib import Path
from time import time_ns
from utils.namespace import Namespace
from utils.config_distribution import distribute_config
import components.scenario_generation_controller as sce_gen_con
import components.simulation_controller as sim_con
import components.metric_evaluation_controller as met_man
import argparse


class TSC2CARLA(object):
    def __init__(self):
        self.static_config_path = 'data_storage/config/static_config.yaml'
        self.dynamic_config_path = 'data_storage/config/analysis_task.yaml'
        self._load_config()

    def _load_config(self):
        argparser = argparse.ArgumentParser()
        argparser.add_argument('-r', '--resume', action='store_true',
                               help='Resume a previous broken run by running missing test cases only.')
        commandline_args = argparser.parse_args()
        self.resume = commandline_args.resume
        with open(self.static_config_path) as static_config_file:
            self.static_config = yl.safe_load(static_config_file)
        with open(self.dynamic_config_path) as dynamic_config_file:
            self.dynamic_config = yl.safe_load(dynamic_config_file)
        self.dynamic_config['stub'] = time_ns()
        distribute_config(self.static_config_path, self.dynamic_config_path, self.dynamic_config['stub'])

    def run(self):
        tmp_dir = self.static_config['tmp_dir']
        tmp_state = os.listdir(tmp_dir)

        sgc_args = Namespace(
            tsc2smt_root=Path(self.static_config['tsc2smt_root']),
            tsc2smt_conf_dir=Path(self.static_config_path).parent / Path('tsc2smt'),
            smt2instance_root=Path(self.static_config['smt2instance_root']),
            smt2instance_conf_dir=Path(self.static_config_path).parent / Path('smt2instance'),
            instance2openx_root=Path(self.static_config['instance2openx_root']),
            instance2openx_conf_dir=Path(self.static_config_path).parent / Path('instance2openx'),
            smt_dir=Path(self.static_config['smt_dir']),
            instance_dir=Path(self.static_config['instance_dir']),
            scenario_dir=Path(self.static_config['scenario_dir'])
        )
        sgc = sce_gen_con.ScenarioGenerationController(sgc_args)
        if not self.resume:
            sgc.run(generation=self.dynamic_config['generation'], preprocessing=self.dynamic_config['preprocessing'])

        sc_args = Namespace(
            scenario_list=sgc.get_scenario_list(),
            esmini=self.dynamic_config['esmini'],
            esmini_log_dir=Path(self.static_config['esmini_log_dir']),
            carla=self.dynamic_config['carla'],
            carla_root=self.static_config['carla_root'],
            carla_low_quality=self.static_config['carla_low_quality'],
            carla_log_dir=Path(self.static_config['carla_log_dir'])
        )
        sc = sim_con.SimulationController(sc_args)
        sc.run(esmini=self.dynamic_config['esmini'], carla=self.dynamic_config['carla'], run_external_model=True,
               missing_only=self.resume)

        mec_args = Namespace(
            esmini=self.dynamic_config['esmini'],
            esmini_log_dir=Path(self.static_config['esmini_log_dir']),
            carla=self.dynamic_config['carla'],
            carla_log_dir=Path(self.static_config['carla_log_dir']),
            carla_low_quality=self.static_config['carla_low_quality'],
            carla_root=Path(self.static_config['carla_root']),
            criticality_evaluation=self.dynamic_config['criticality_evaluation']
        )
        mec = met_man.MetricEvaluationController(mec_args)
        mec.run()

        print("Deleting tmp folder contents at", tmp_dir)
        for f in os.listdir(tmp_dir):
            if f not in tmp_state:
                print("deleting", f)
                os.remove(f)


if __name__ == '__main__':
    # try:
    tsc2carla = TSC2CARLA()
    tsc2carla.run()
# except Exception as e:
#    print(e)
