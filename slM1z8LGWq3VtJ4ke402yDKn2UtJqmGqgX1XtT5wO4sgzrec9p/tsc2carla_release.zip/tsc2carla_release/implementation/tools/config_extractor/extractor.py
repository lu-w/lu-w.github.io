import json
import argparse
import xmltodict

parser = argparse.ArgumentParser(description="export carla sut configuration")
parser.add_argument("--input", "-i", metavar='i', nargs=1, required=True, help="the input openscenario file")
parser.add_argument("--output", "-o", metavar='o', nargs=1, required=True, help="the output sut configuration file")
parser.add_argument("--ego", "-e", metavar='e', nargs=1, required=True, help="the name of the ego")

args = parser.parse_args()
inputFile = args.input[0]
outputFile = args.output[0]
egoName = args.ego[0]

# TODO add target_speed as cli argument
export_data = {"ego": egoName, "target_speed": 12.5}

file = open(inputFile, "r")
xml_string = file.read()
file.close()
python_dict = xmltodict.parse(xml_string)
maneuvers = python_dict["OpenScenario"]["Storyboard"]["Story"]["Act"]["ManeuverGroup"]
for maneuver in maneuvers:
    entityRef = maneuver["Actors"]["EntityRef"]["@entityRef"]
    if entityRef != egoName:
        continue

    waypoint = maneuver["Maneuver"]["Event"]["Action"]["PrivateAction"]["RoutingAction"]["FollowTrajectoryAction"]["Trajectory"]["Shape"]["Polyline"]["Vertex"][0]
    position = waypoint["Position"]["WorldPosition"]
    export_data["start_transform"] = [position["@x"], position["@y"], position["@h"]]

    waypoint = maneuver["Maneuver"]["Event"]["Action"]["PrivateAction"]["RoutingAction"]["FollowTrajectoryAction"]["Trajectory"]["Shape"]["Polyline"]["Vertex"][-1]
    position = waypoint["Position"]["WorldPosition"]
    export_data["target_location"] = [position["@x"], position["@y"], position["@h"]]
    break


with open(outputFile, 'w') as f:
    json.dump(export_data, f)

print("Extracted scenario information")

