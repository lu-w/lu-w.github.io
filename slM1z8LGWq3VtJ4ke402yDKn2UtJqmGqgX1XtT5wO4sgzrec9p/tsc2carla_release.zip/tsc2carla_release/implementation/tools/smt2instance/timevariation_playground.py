from locale import LC_COLLATE
from msvcrt import SEM_FAILCRITICALERRORS
from io import StringIO
import os
import numpy as np
from numpy import Inf, number
from pysmt.shortcuts import *
from pysmt.smtlib.parser import SmtLibParser
from pysmt.formula import FormulaManager
from pysmt.solvers.z3 import Z3Converter
import allPySmt
from allPySmt import isSubset

from modelSearcher import ModelSearcher
from atomPolarityWalker import AtomPolarityWalker
from getDefinitAtoms import getDefinitAtoms
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

#######################################################################################################
###### Examples on how to read an smt formula, use basic pysmt-functions and search with allpysmt #####
#######################################################################################################

# adapt according your current folder and smt-file you want to use
smtFilePath = "../tscs/tc1/tsc-3_safetyDist_10steps.smt"
#smtFilePath = "example/tmp/output_corrected.smt"

# Adding '(check-sat)' to the end, if it is not at in the file
with open(smtFilePath,'r+') as smtFile:
    if ('(check-sat)' not in smtFile.read()):
        print("no check-sat")
        smtFile.write('(check-sat)')


smtFormula = allPySmt.rewriteEQ(simplify(read_smtlib(smtFilePath)))

print("Is Sat:", is_sat(smtFormula))
print("Number of Atoms: ", len(get_atoms(smtFormula)))
print("Number of Variables: ", len(get_free_variables(smtFormula)))

vars = get_free_variables(smtFormula)

spatialview_names_to_distribute = [
    'var__spatialView_U_A',
    'var__spatialView_U_B',
    'var__spatialView_U_C',
    'var__spatialView_U_D',
    'var__spatialView_U_E'
]

other_VariableNames_to_plot = [
    'tmp_0__Operation_0_0_1_start',
    'tmp_1__Operation_0_0_1_complete'
]

searcher = ModelSearcher(smtFormula)
searcher.recursive_blocking_invariants(spatialview_names_to_distribute, maxNumberOfModels=260)
searcher.make_spatialviewSatisfaction_figures(spatialview_names_to_distribute + other_VariableNames_to_plot,'tools/tscplayout/redgreen_test', numberOfPlots=10)

assert(False)

def get_sat_over_time(spatialView_names, timesteps, model):
    sat_over_time = []
    for spVar in spatialView_names:
        satAtTime = [model.get_py_value(Symbol('var__spatialView_U' + spVar + '@' + str(timestep), BOOL)) 
            for timestep in range(timesteps)]
        sat_over_time.append(satAtTime)
    
    return sat_over_time

#"""
#------------------------ Examples for searching with all_smt -------------------------------
spatialview_vars = [var for var in vars if any(('spatialView_U' + varname) in var.serialize() for varname in spatialview_names_to_distribute)]
print("spatial view vars created")
numberOfModels = 0
satisfactions = []

#smtFormula = And(smtFormula, Iff(Symbol('var__spatialView_U_A@0',types.BOOL),TRUE()))

for m,c in allPySmt.all_pySmt(smtFormula, spatialview_vars, check_redundant = False, check_subset = False, 
check_completeness=False, check_soundness=False):
    numberOfModels += 1
    print("--------------------------------------")
    print("")
    print("Number of Models: ", numberOfModels, ", counter: ", c*100)#/(2**len(list(get_atoms(smtFormula)))))
    assert( m.get_value( smtFormula ).is_true() )
    sat_over_time = get_sat_over_time(spatialview_names_to_distribute, 11, m)
    satisfactions.append(sat_over_time)

    #if numberOfModels > 9:
    #    break

print("I found ", numberOfModels, " models.")
