import pandas as pd
import matplotlib.pyplot as plt
import argparse


parser = argparse.ArgumentParser(description="Plot Scenario distances")
parser.add_argument("--log_file", "-l", metavar='l', nargs=1, required=True, help="The patho to the log csv file")
args = parser.parse_args()
log_file = args.log_file[0]

df = pd.read_csv(log_file,delimiter=';')
print(df)
pl = df.plot(title = 'Evolution of metrics', x="Number_of_models", y = [
    #"Time",
    "frechet",
    "dtw",
    "statistical_dispersion"])
#plt.show()
plt.savefig(log_file.split('.csv')[0])
