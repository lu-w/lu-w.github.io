import numpy as np
import json

def read_spline(jsonpath,variable_names):
    ##Daten einlesen und aufbereiten
    # Ziel: Zwei Splines, spline0 und spline2.
    # Jeder Spline wird als ein Array mit zwei Einträgen X und X2 kodiert, die selbst vektorwertig sind,
    # dabei ist X eine Stützstelle und X2 ein Kontrollpunkt

    with open(jsonpath, 'r') as jsonfile:
        json_data = json.load(jsonfile)

    spline = []

    for i in range(0, len(json_data[variable_names[0]])):
        col1 = [json_data[varname][i] for varname in variable_names]
        col2 = [json_data[varname + '2'][i] for varname in variable_names]
        row = [col1, col2]
        spline.append(row)
    return spline

def sample_spline(spline, sampling_rate, dimension = 0):
    #spline i2 3d array.
    #first dimension is @t
    #second is either 0 for real poin or 1 for control point
    #third is variable
    # we consider quadratic bezier curve
    # rows := rows of spline
    output_spline = []

    #print(len(spline))
    t_max=len(spline) - 1
    for t in np.arange(0,t_max,t_max/sampling_rate):
        if t < t_max:
            # Safety hack

            # print(t)
            row = int(t)
            #print(row)
            #print(spline[row][0][0])
            tt = t -row
            if dimension == 2:# acceleration
                func = [2 * (spline[row][0][v] - 2*spline[row][1][v] + spline[row+1][0][v]) for v in range(0,len(spline[row][0])) ]
            elif dimension == 1:# velocity
                func = [ 2 * (spline[row][0][v] - 2*spline[row][1][v] + spline[row+1][0][v]) * tt + (-2*spline[row][0][v] + 2*spline[row][1][v]) for v in range(0,len(spline[row][0])) ]
            else:# position
                func = [ spline[row][0][v]*(1-tt)**2 + 2.0*spline[row][1][v]*tt*(1-tt) + spline[row+1][0][v]*tt**2 for v in range(0,len(spline[row][0])) ]
            output_spline.append(func)

    return output_spline

def sample_single_bezier_spline(spline, sampling_rate):
    #spline is 2d array.
    #first dimension is @t
    #second is either 0 for real poin or 1 for control point
    # we consider quadratic bezier curve
    # rows := rows of spline
    output_spline = []

    #print(len(spline))
    t_max=len(spline) - 1
    for t in np.arange(0,t_max,t_max/sampling_rate):
        if t < t_max:
            # Safety hack

            #print(t)
            row = int(t)
            #print(row)
            #print(spline[row][0][0])
            tt = t -row
            func = [ spline[row][0]*(1-tt)**2 + 2.0*spline[row][1]*tt*(1-tt) + spline[row+1][0]*tt**2 ]
            output_spline.append(func)
    return output_spline