import pysmt
import pysmt.walkers as walkers
import pysmt.operators as op
from pysmt.smtlib.parser import SmtLibParser
from pysmt.shortcuts import *

from pysmt import typing

from pysmt.logics import Logic, Theory, get_closer_pysmt_logic

from io import StringIO

class AtomPolarityWalker(walkers.DagWalker):

    def get_AtomPolarity(self, formula):
        """Returns a mapping of atoms and polarity as a dictionary {atom: polarity}. 
        polarity 
            -1: Atom occurs in negative polarity only
             0: Atom occurs in negative as well as positive polarity
            +1: Atom occurs in positive plarity only
         """
        return self.walk(formula)
    
    # overwrite this function to disable memoization
    def _compute_node_result(self, formula, **kwargs):
        """Apply function to the node and memoize the result.

        Note: This function assumes that the results for the children
              are already available.
        """
        key = self._get_key(formula, **kwargs)
        #if key not in self.memoization:
        try:
            f = self.functions[formula.node_type()]
        except KeyError:
            f = self.walk_error

        args = [self.memoization[self._get_key(s, **kwargs)] \
                for s in self._get_children(formula)]
        self.memoization[key] = f(formula, args=args, **kwargs)
        #else:
        #    pass

    def walk_real_constant(self, formula, args, **kwargs):
        return

    def walk_bool_constant(self, formula, args, **kwargs):
        return

    def walk_plus(self, formula, args, **kwargs):
        return
    
    def walk_minus(self, formula, args, **kwargs):
        return

    def walk_times(self, formula, args, **kwargs):
        return
    
    def walk_symbol(self, formula, args, **kwargs):
        if formula.is_symbol(typing.BOOL):
            return {formula: 1}
        return

    def walk_bool_constant(self, formula, args, **kwargs):
        return {formula: 1}

    def walk_lt(self, formula, args, **kwargs):
        # print("I found a lower than: " + str(formula))
        return {formula: 1}

    def walk_gt(self, formula, args, **kwargs):
        #print("I found a greater equal: " + str(formula))
        return {formula: 1}

    def walk_le(self, formula, args, **kwargs):
        #print("I found a lower equal: " + str(formula))
        return {formula: 1}

    def walk_ge(self, formula, args, **kwargs):
        #print("I found a greater equal: " + str(formula))
        return {formula: 1}

    def walk_equals(self, formula, args, **kwargs):
        return {formula: 1}

    def walk_or(self, formula, args, **kwargs):
        # print("I found an or: "  + str(formula))
        return self.merge_dicts(args)

    def walk_and(self, formula, args, **kwargs):
        # print("I found an and: "  + str(formula))
        return self.merge_dicts(args)

    def walk_not(self, formula, args, **kwargs):
        #print("I found a not: "  + str(formula))
        for key in args[0]:
            args[0].update({key: args[0][key]*-1})
        return args[0]

    def walk_implies(self, formula, args, **kwargs):
        # print("Args of => :", args)
        # A => B
        # invert first dictionary (dictionary of A, because (A => B) <-> ((not A) and B))
        for key in args[0]:
            args[0].update({key: -1*args[0][key]})

        return self.merge_dicts(args)

    def walk_iff(self, formula, args, **kwargs):
        # print("I found an iff: "  + str(formula))
        # print("Arguments of iff: ", args)
        outDict = {}
        for dict in args:
            for key in dict:
                outDict.update({key: 0})
        
        return outDict

    def merge_dicts(self, dicts):
        outDict = {}
        for dict in dicts:
            # print("Dictionary: ", dict)
            for key in dict:
                if key in outDict:
                    if (outDict[key] * dict[key]) == 1:
                        newEntry = outDict[key] * dict[key] * outDict[key]
                    else:
                        newEntry = 0                    
                    outDict.update({key: newEntry})
                else:
                    outDict.update({key: dict[key]})
        return outDict

#smt_f=\
"""
(declare-fun x () Real)
(declare-fun y () Real)
(assert (> x 1.0))
(assert (> y 1.0))
(assert (or (> (+ x y) 3.0) (< (- x y) 2.0)))
(assert (not (<= (+ x y) -6.0)))
(assert (not (and (= x 10.0) (>= (+ x y) 9.0))))
(assert (=> (> x 5.0) (< y -6.0)))
(assert (or (not (> x 1.0)) (> y 1.0) ))
(check-sat)
"""
"""
parser = SmtLibParser()

script = parser.get_script(StringIO(smt_f))
f = script.get_strict_formula()

print("Formula: ",f)

atPolWalker = AtomPolarityWalker()
result = atPolWalker.get_AtomPolarity(f)
# print(atPolWalker.memoization)
#print("Result: ", result[f])
print("Result: ",result)
"""