# create example/out
# python runner.py -n 10 -i ../TSCdata/output.smtlib -o example/out

import math
import argparse
from pathlib import Path
from pysmt.shortcuts import *
from pysmt.shortcuts import read_smtlib, simplify
from modelSearcher import ModelSearcher


parser = argparse.ArgumentParser(description="find convex tsc solutions")
parser.add_argument("--num_models", "-n", metavar='m', type=int, nargs=1, required=True, help="how many solutions have to be found")
parser.add_argument("--input", "-i", metavar='i', nargs=1, required=True, help="the input smtlib file")
parser.add_argument("--output", "-o", metavar="o", nargs=1, required=True, help="the output folder")
parser.add_argument("--no_model_export", required=False, default=False, action='store_true', help='whether no models should be exported to json. This overrides the export_during_search flag.')
parser.add_argument("--make_satisfactionFigures", required=False, default=False, action='store_true', help="whether satisfaction figures should be made")
parser.add_argument("--make_trajectoryFigures", required=False, default=False, action='store_true', help="whether trajectory figures should be made")
parser.add_argument("--compare_variation", required=False, default=False, action='store_true', help="whether variation method should be evaluated")
parser.add_argument("--searching_methods", "-m", type=str, nargs='+', required=False, default='solver_seed', help="Used solving method 'solver_seed', 'recursive_blocking', 'recursive_blocking_terms','recursive_blocking_invs' 'iterative_blocking' ")
parser.add_argument("--z3_solver_seed", "-z", metavar='m', type=int, nargs=1, required=False, help="optional solver seed for z3")

# Parse arguments
args = parser.parse_args()

inputFile = args.input[0]
outputFolder = args.output[0]
num_models = args.num_models[0]
no_model_export = args.no_model_export
export_during_search = True
if no_model_export:
    export_during_search = False
makeSatisfactionFigures = args.make_satisfactionFigures
makeTrajectoryFigures = args.make_trajectoryFigures
compare_variation = args.compare_variation
searching_methods = args.searching_methods
z3_solver_seed = args.z3_solver_seed[0]

smtFormula = simplify(read_smtlib(inputFile))

# run iterations
if num_models < 0:
    num_models = math.inf

forbidden_strings = []#'_min', '_max']
searching_terms = [at for at in get_atoms(smtFormula) if not any(forbit in at.serialize() for forbit in forbidden_strings)]

############ Additional Options and Inputs #########################

invariantNames_to_search = [
    'var__spatialView_U_Start',
    'var__spatialView_U_Occlusion',
    'var__spatialView_U_End'
]
other_VariableNames_to_plot = []
variety_check_methods=['dtw'] #,'frechet', 'statistical_dispersion']
trajectories_to_compare = [
    ['object_VehicleA.AbstractDynamicObject$x', 'object_VehicleA.AbstractDynamicObject$y'],
    ['object_VehicleB.AbstractDynamicObject$x', 'object_VehicleB.AbstractDynamicObject$y'],
    ['object_VehicleC.AbstractDynamicObject$x', 'object_VehicleC.AbstractDynamicObject$y']
]
colordict = {} # {vehicleName: colorInTrajectoryfigure}

############ End Additional Options and Inputs #####################
for method in searching_methods:
    args = {'name_stem': Path(inputFile).stem,
            'smtFormula': smtFormula,
            'model_variable_exportPath': outputFolder,
            'variety_check_methods': variety_check_methods if compare_variation else [],
            'loggingPath': f"{outputFolder}/log_{method}/",
            'solver_seed': z3_solver_seed,
            'loggingFilenameIdentifier': f'_{method}'}
    searcher = ModelSearcher(**args)
    #searcher.loggingFilenameIdentifier = f'_{method}'
    print("Searcher build")

    if compare_variation:
        searcher.set_trajectories_to_compare(trajectories_to_compare)

    if method == 'solver_seed':
        searcher.solver_seed_variation(maxNumberOfModels=num_models, export_during_search=export_during_search)
    elif method == 'recursive_blocking':
        searcher.recursive_blocking(maxNumberOfModels=num_models, export_during_search=export_during_search)
    elif method == 'recursive_blocking_terms':
        searcher.recursive_blocking(terms=searching_terms,maxNumberOfModels=num_models, export_during_search=export_during_search)
    elif method == 'recursive_blocking_invs':
        searcher.recursive_blocking_invariants(invariantNames=invariantNames_to_search, maxNumberOfModels=num_models,
                                               export_during_search=export_during_search)
    elif method == 'iterative_blocking':
        searcher.iterative_blocking(maxNumberOfModels=num_models)
    else:
        raise(ValueError('No valid searching method specified'))

    if makeSatisfactionFigures:
        searcher.make_spatialviewSatisfaction_figures(
            invariantNames_to_search + other_VariableNames_to_plot,
            f"{outputFolder}/satisfactionFigures_{method}/", 1, (7, 5))

    if makeTrajectoryFigures:
        searcher.make_trajectory_figures(
            ['object_VehicleA.AbstractDynamicObject',
             'object_VehicleB.AbstractDynamicObject',
             'object_VehicleC.AbstractDynamicObject'],
            f"{outputFolder}/trajectoryFigures_{method}/",
            colordict
        )