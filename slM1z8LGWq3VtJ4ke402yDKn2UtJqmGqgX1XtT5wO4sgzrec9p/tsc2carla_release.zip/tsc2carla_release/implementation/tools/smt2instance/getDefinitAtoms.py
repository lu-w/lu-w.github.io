from pysmt.shortcuts import *

def getDefinitAtoms(formula, atsToCheck = []):
    s = Solver(name="z3")
    s.add_assertion(formula)
    if len(atsToCheck) == 0:
        atsToCheck = get_atoms(formula)

    definitAtoms = []
    undefinitAtoms = []
    definitLiterals = {}

    if s.solve():
        m = s.get_model()
        for at in atsToCheck:
            s.push()
            s.add_assertion(Iff(at,Not(m[at])))
            satRes = s.solve()
            if satRes:
                undefinitAtoms.append(at)
            else:
                definitAtoms.append(at)
                if at.is_literal():
                    definitLiterals.update({at: m[at]})
            s.pop()

    return definitAtoms, undefinitAtoms, definitLiterals