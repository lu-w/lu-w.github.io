import matplotlib.pyplot as plt
import pandas as pd
import argparse

path = 'test_suite_diversity_evaluation_13timesteps_n1000_seed1333'
#path = 'data_storage_bicycleOcclusion_seed1333/log_recursive_blocking_2/'

variety_methods = {
    'solver_seed': 'Solver Seed',
    #'solverSeed_1',
    #'recursive_blocking',
    #'iterativeBlocking',
    'recursive_blocking': 'Recursive Blocking',
    'recursive_blocking_invs': 'Recursive Blocking Invariants'
}

distance_methods_to_plot = {
    'dtw': 'Dynamic Time Warping'
}

# get distances for each variety method
distances_methods = {method: pd.read_csv(f"{path}/log_{method}/distances_{method}.csv", delimiter=';') for method in variety_methods}

for distance in distance_methods_to_plot:
    concat_frame = pd.concat([distances_methods[method][distance] for method in variety_methods],axis=1, keys=[variety_methods[key] for key in variety_methods])
    concat_frame.plot(title='Comparison of Variation Methods', xlabel='Number of Models', ylabel=f"Test Suite Quality").legend(loc='upper right')
    #plt.show()
    plt.savefig(f"{path}/distances_{distance}.png", dpi=600)
    #concat_frame.columns(variety_methods)