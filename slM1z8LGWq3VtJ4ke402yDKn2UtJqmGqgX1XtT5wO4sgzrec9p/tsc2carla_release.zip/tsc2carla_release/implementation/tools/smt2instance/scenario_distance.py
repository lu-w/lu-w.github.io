import io
import json
import math

import numpy as np
import similaritymeasures as sm
from dtaidistance import dtw, dtw_ndim
from spline_helper import *

def frechet_splines(splines1,splines2,sampling_rate = 500, dimension = 0):

    control_points1 = sample_spline(splines1,sampling_rate,dimension)
    control_points2 = sample_spline(splines2,sampling_rate,dimension)
    
    return sm.frechet_dist(control_points1,control_points2)

def dtw_splines(splines1,splines2,sampling_rate = 500, dimension = 0):
    control_points1 = sample_spline(splines1,sampling_rate,dimension)
    control_points2 = sample_spline(splines2,sampling_rate,dimension)

    return dtw_ndim.distance(np.array(control_points1),np.array(control_points2))

def frechet_samples(samples1,samples2):
    return sm.frechet_dist(samples1,samples2)

def dtw_samples(samples1,samples2):
    return dtw_ndim.distance(np.array(samples1),np.array(samples2))
