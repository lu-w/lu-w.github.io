import json
import random

import sympy
import csv
import time
import tracemalloc
import math
import os
import re
from fractions import Fraction
from pathlib import Path

from pysmt.shortcuts import *
from pysmt.typing import REAL
from matplotlib import pyplot as plt, cm
from matplotlib.colors import ListedColormap
from itertools import cycle
import numpy as np
#from pysmt.solvers.solver import Solver
from atomPolarityWalker import AtomPolarityWalker
from spline_helper import sample_single_bezier_spline, sample_spline
from scenario_distance import dtw_samples, frechet_samples
import allPySmt

class ModelSearcher:
    def __init__(self, name_stem, smtFormula, model_variable_exportPath = '', loggingPath = '', variety_check_methods = [], solver_seed = [], loggingFilenameIdentifier = ''):
        self.name_stem = name_stem
        self.variables = get_free_variables(smtFormula)
        self.smtFormula = smtFormula
        self.models = []

        # Logging Parameters
        self.loggingPath = ''
        if loggingPath:
            #self.log = True
            self.loggingPath = loggingPath
        self.loggingFilenameIdentifier = loggingFilenameIdentifier
        eventlogging_header = {'events': ['Time', 'Event']}
        self.init_logging(eventlogging_header)
        self.starttime = time.time()
        self.log({'events': [0,'Start_Initializing']})

        self.model_variable_exportPath = model_variable_exportPath
        self.logPairwiseDistance = True
        self.solver_seed = solver_seed
        if self.solver_seed:
            self.solver = Solver( name="z3", random_seed=solver_seed)
        else:
            self.solver = Solver( name="z3")

        # Prepare model export
        self.variable_names_constant = []
        self.variable_names_dynamic = []
        self.max_time_point = 0
        self.variety = []
        self.trajectories_to_compare = []
        self.collective_scenario_distances = {} # dictonary with the pairwise scenario distances for each variation method {'frechet': [.., ...], 'dtw': [.., ...]}
        self.sum_of_pairwise_trajectory_distance = {} # dictonary for each variation method: For index i, this array contains the average pairwise distance to all models with lower index

        # extract variable names and sort to dynamic and constant
        for var in self.variables:
            split = str(var).split('@')
            var_name = split[0]
            if len(split) > 1:
                temp_timepoint = int(split[1])
                if temp_timepoint > self.max_time_point:
                    self.max_time_point = temp_timepoint
                if var_name != "time" and var_name not in self.variable_names_dynamic and var.is_symbol(type_=REAL):
                    self.variable_names_dynamic.append(var_name)
            elif var_name != "time" and var_name not in self.variable_names_constant and var.is_symbol(type_=REAL):
                self.variable_names_constant.append(var_name)

            # variation measurement
            self.sampling_rate = self.max_time_point * 2
            self.sampling_dimension = 0
            self.sampledict = {}  # nested dictionary: {'model_idx': {'splinename' :sampled spline, ...}, ...}
            self.variety_distance_methods = variety_check_methods

        # Sort variables alphabetically
        self.variable_names_constant.sort(key=lambda x: str(x))
        self.variable_names_dynamic.sort(key=lambda x: str(x))

        now = time.time() - self.starttime
        self.log({'events': [now, 'End_Initializing']})

    def solver_seed_variation(self, maxNumberOfModels, export_during_search = True):
        now = time.time() - self.starttime
        self.log({'events': [now, 'Start_Search_SolverSeedVariation']})
        for numberOfModels in range(1,maxNumberOfModels+1):
            self.solver.add_assertion(self.smtFormula)
            self.solver.solve()
            model = self.solver.get_model()

            if model:
                if export_during_search:
                    if not self.model_variable_exportPath:
                        raise (ValueError("No Path to export model variables specified"))

                    self.export_model_variables([model], numberOfModels - 1)

                self.models.append(model)
                modelVars = [obj[0] for obj in model]
                modelVars.sort(key=lambda x: str(x))

                if (numberOfModels == 1):
                    headerLog = ['Seconds'] + [str(var) for var in modelVars]
                    headerDistances = ['Number_of_models', 'Time'] + [method for method in
                                                                      self.variety_distance_methods]
                    logging_headers = {'models': headerLog}

                    if len(self.variety_distance_methods) > 0:
                        logging_headers.update({
                            'distances': headerDistances
                        })

                    self.init_logging(logging_headers)

                print('Number of models: ', numberOfModels)

                now = time.time() - self.starttime

                dataLog = [now] + [model[var] for var in modelVars]
                eventLog = [now] + [f'Found Model Nr: {numberOfModels}']

                self.log({'models': dataLog,
                          'events': eventLog})

                if numberOfModels > 1 and len(self.variety_distance_methods) > 0:
                    now = time.time() - self.starttime
                    self.log({'events': [now, f'Start distance calculation with {numberOfModels} models']})
                    distances = self.collective_scenario_distance()
                    now = time.time() - self.starttime
                    self.log({'events': [now, f'End distance calculation with {numberOfModels} models']})
                    dataDistances = [numberOfModels, now] + distances

                    self.log({'distances': dataDistances})
            else:
                print("No new model found.")

        if len(self.models) == maxNumberOfModels:
            print(f"Max number of {maxNumberOfModels} models found.")

        now = time.time() - self.starttime
        self.log({'events': [now, 'End_Search_SolverSeedVariation']})

    def iterative_blocking(self, maxNumberOfModels, export_during_search = True):
        now = time.time() - self.starttime
        self.log({'events': [now, 'Start_Search_IterativeBlocking']})
        def getTrueAssertions(model, considerPolarity = True):
            assertions = []
            for at in atoms:
                if at.is_equals() or at.is_le() or at.is_lt():
                    # print(at)
                    if model.get_py_value(at) and (not(considerPolarity) or (polarityDict[at] >= 0)):
                        assertions.append(at)

                    if not(model.get_py_value(at)) and (not(considerPolarity) or (polarityDict[at] <= 0)):
                        assertions.append(Not(at))
                        # assertions.append(GT(at.arg(0),at.arg(1)))
            return assertions

        self.solver.add_assertion(self.smtFormula)
        if self.solver.solve():
            self.models.append(self.solver.get_model())
        else:
            ValueError("Formula is unsatisfiable")

        atoms = get_atoms(self.smtFormula)
        formulae = [self.smtFormula]
        atPolWalker = AtomPolarityWalker()
        polarityDict = atPolWalker.get_AtomPolarity(self.smtFormula)

        # Start searching for new model. If a model was found, the polarity of each linear equation is taken and excluded in the next searching steps
        newModelFound = True
        while newModelFound and (len(self.models) <= maxNumberOfModels):
            numberOfModels = len(self.models)
            print('Number of models: ', numberOfModels)

            trueModelAssertions = getTrueAssertions(self.models[-1], True)
            # print("Number of not-Atoms: ", len(trueModelAssertions))

            # todo needs to be optimized via solver push and pop functions
            newFormula = And(formulae[-1],Not(And(trueModelAssertions)))
            model = get_model(newFormula, solver_name='z3')

            if model:
                if export_during_search:
                    if not self.model_variable_exportPath:
                        raise (ValueError("No Path to export model variables specified"))

                    self.export_model_variables([model], numberOfModels - 1)

                self.models.append(model)
                formulae.append(newFormula)
                modelVars = [obj[0] for obj in model]
                modelVars.sort(key=lambda x: str(x))

                if (numberOfModels == 1):
                    headerLog = ['Seconds'] + [str(var) for var in modelVars]
                    headerDistances = ['Number_of_models', 'Time'] + [method for method in
                                                                      self.variety_distance_methods]

                    logging_headers = {'models': headerLog}

                    if len(self.variety_distance_methods) > 0:
                        logging_headers.update({
                            'distances': headerDistances
                        })

                    self.init_logging(logging_headers)


                now = time.time() - self.starttime

                dataLog = [now] + [model[var] for var in modelVars]
                eventLog = [now] + [f'Found Model Nr: {numberOfModels}']

                self.log({'models': dataLog,
                          'events': eventLog})

                if numberOfModels > 1 and len(self.variety_distance_methods) > 0:
                    now = time.time() - self.starttime
                    self.log({'events': [now, f'Start distance calculation with {numberOfModels} models']})
                    distances = self.collective_scenario_distance()
                    now = time.time() - self.starttime
                    self.log({'events': [now, f'End distance calculation with {numberOfModels} models']})
                    dataDistances = [numberOfModels, now] + distances

                    self.log({'distances': dataDistances})

            else:
                print('No new model found!')
                newModelFound = False

        print(f"Max number of {maxNumberOfModels} found.")
        now = time.time() - self.starttime
        self.log({'events': [now, 'End_Search_IterativeBlocking']})

        
    def recursive_blocking(self, maxNumberOfModels, terms = [], export_during_search = True, check_redundant = False, check_subset = False,
                           check_completeness = False, check_soundness = False):
        print("Start searching with allPySmt")
        now = time.time() - self.starttime
        self.log({'events': [now, 'Start_Search_RecursiveBlocking']})
        numberOfModels = 0
        if len(terms) == 0:
            terms = get_atoms(self.smtFormula)

        #terms = [term for term in terms]
        #random.shuffle(terms)

        tracemalloc.start()

        for model,c in allPySmt.all_pySmt(self.smtFormula, terms,
            check_redundant, check_subset, check_completeness, check_soundness,
            self.solver):
            numberOfModels += 1
            print("Number of Models: ", numberOfModels)

            if export_during_search:
                if not self.model_variable_exportPath:
                    raise(ValueError("No Path to export model variables specified"))
                
                self.export_model_variables([model],numberOfModels - 1)
            
            self.models.append(model)

            if (numberOfModels == 1): # and (self.log):
                modelVars = [obj[0] for obj in model]
                modelVars.sort(key=lambda x: str(x))

                headerLog = ['Seconds'] + [str(var) for var in modelVars]

                #headerExplorationdata = ['Seconds', 'MemoryCurrent', 'MemoryPeak']
                #headerExplorationdata += ['Coverage']

                logging_headers = {'models': headerLog}
                headerDistances = ['Number_of_models', 'Time'] + [method for method in self.variety_distance_methods]
                if len(self.variety_distance_methods) > 0:
                    logging_headers.update({
                        'distances': headerDistances
                    })

                self.init_logging(logging_headers)

            modelVars = [obj[0] for obj in model]
            modelVars.sort(key=lambda x: str(x))
            now = time.time() - self.starttime

            dataLog = [now] + [model[var] for var in modelVars]
            eventLog = [now] + [f'Found Model Nr: {numberOfModels}']

            #memory = tracemalloc.get_traced_memory()
            #dataExploration = [now, memory[0],memory[1]]
            #dataExploration += [c]

            self.log({'models': dataLog,
                      'events': eventLog})

            if numberOfModels > 1 and len(self.variety_distance_methods) > 0:
                now = time.time() - self.starttime
                self.log({'events': [now, f'Start distance calculation with {numberOfModels} models']})
                distances = self.collective_scenario_distance()
                now = time.time() - self.starttime
                self.log({'events': [now, f'End distance calculation with {numberOfModels} models']})
                dataDistances = [numberOfModels, now] + distances

                self.log({'distances': dataDistances})

            if numberOfModels >= maxNumberOfModels:
                print(f"Max number of {maxNumberOfModels} found.")
                break

        tracemalloc.stop()
        now = time.time() - self.starttime
        self.log({'events': [now, 'End_Search_RecursiveBlocking']})
        return

    def recursive_blocking_invariants(self, invariantNames = [], maxNumberOfModels = math.inf, export_during_search = True,
                                      check_redundant = False, check_subset = False,
                                      check_completeness = False, check_soundness = False):
        print(f"Start searching satisfactions for invariants: {invariantNames}")
        numberOfModels = 0
        spatialview_vars = [var for var in self.variables if any((varname) in var.serialize() for varname in invariantNames)]
        #print(spatialview_vars)

        return self.recursive_blocking(maxNumberOfModels, spatialview_vars, export_during_search, check_redundant, check_subset, check_completeness, check_soundness)

    # select, which elements should be logged.
    # logging_files = {'logging_file_name': header}
    # header= ['first_entry_name', 'second_entry_name', ...]
    # The logs will be stored in 'logging_path/' + 'logging_filename' + '.csv'
    def init_logging(self, logging_files = {}):
        if not self.loggingPath:
            self.loggingPath = 'tools/smt2instance/log/'
            print(f'No logging path specified. Setting logging path to {self.loggingPath}')

        isExist = os.path.exists(self.loggingPath)
        if not isExist:
            # Create a new directory because it does not exist
            os.makedirs(self.loggingPath)
            print(f"The new loggingPath {self.loggingPath} created!")

        for key in logging_files:
            log_file = open(self.loggingPath + key + self.loggingFilenameIdentifier + '.csv', "w", newline='')
            writer = csv.writer(log_file, delimiter=';')
            writer.writerow(logging_files[key])
            log_file.close()

    # log the given data
    # logging_data = {'logging_file_name: [first_entry_data, second_entry_data, ...]}
    def log(self, logging_data):
        for key in logging_data:
            log_file = open(self.loggingPath + key + self.loggingFilenameIdentifier + '.csv', "a", newline='')
            writer = csv.writer(log_file, delimiter=';')
            writer.writerow(logging_data[key])
            log_file.close()

    def export_model_variables(self, models = [], index_offset = 0):
        variables_of_all_models = []

        if not self.model_variable_exportPath:
            raise(ValueError("No Path to export model variables specified"))

        if len(models) == 0:
            raise(ValueError("No models to export given"))

        # fill values for each variable per model
        for i, model in enumerate(models):
            #model_data = {'time': list(range(self.max_time_point + 1))}
            model_data = {'time': [model.get_py_value(Symbol(f"time@{timepoint}", REAL)) for timepoint in range(self.max_time_point)]}
            time_data = [0]

            for timepoint in range(self.max_time_point + 1):
                pyvalue = model.get_py_value(Symbol(f"time@{timepoint}", REAL))
                if (type(pyvalue) is Fraction):
                    time_data.append(pyvalue.numerator/pyvalue.denominator)
                else:
                    # Type is not fraction. Convert via float and sympy
                    time_data.append(float(sympy.nsimplify(pyvalue)))
            model_data = {'time': time_data}

            for v in self.variable_names_constant:
                pyvalue = model.get_py_value(Symbol(f"{v}", REAL))
                if (type(pyvalue) is Fraction):
                    model_data.update({v: [pyvalue.numerator/pyvalue.denominator]})
                else:
                    # Type is not fraction. Convert via float and sympy
                    model_data.update({v: [float(sympy.nsimplify(model.get_py_value(Symbol(f"{v}", REAL))))]})

            for v in self.variable_names_dynamic:
                model_data[v] = []
                for t in range(self.max_time_point + 1):
                    #model_data[v].append(float(sympy.nsimplify(model.get_py_value(Symbol(f"{v}@{t}", REAL)))))
                    pyvalue = model.get_py_value(Symbol(f"{v}@{t}", REAL))
                    if type(pyvalue) is Fraction:
                        model_data[v].append(pyvalue.numerator/pyvalue.denominator)
                    else:
                        # Type is not fraction. Convert via float and sympy
                        model_data[v].append(float(sympy.nsimplify(model.get_py_value(Symbol(f"{v}@{t}", REAL)))))

            variables_of_all_models.append(model_data)
            path_obj = Path(self.model_variable_exportPath)
            path_obj.mkdir(exist_ok=True)
            with open(f'{str(path_obj)}/instance_{self.name_stem}_{index_offset + i}.json', 'w+', encoding='utf-8') as f:
                json.dump(model_data, f, ensure_ascii=False, indent=4)
                print(f"saved: {f}")

        return variables_of_all_models

    # Compare model with index model_index_to_compare
    # variables names example: ['object_VehicleA.AbstractDynamicObject$x', 'object_VehicleA.AbstractDynamicObject$y']
    def model_to_spline_by_index(self, model_idx, variable_names):
        spline = []

        for t in range(0,self.max_time_point):
            col1 = [self.models[model_idx].get_py_value(Symbol(varname + '@' + str(t), REAL)) for varname in variable_names]
            col2 = [self.models[model_idx].get_py_value(Symbol(varname + '2@' + str(t), REAL)) for varname in variable_names]
            row = [col1,col2]
            spline.append(row)

        return spline
        # return: list with two colums: col1 contains first bezier points, col2 contains second bezier points

    def get_sample_by_model_index(self, model_idx, trajectory):

        # update sampledict
        if model_idx not in self.sampledict:
            self.sampledict.update({model_idx: {}})

        if trajectory[0] not in self.sampledict[model_idx]:
            spline = self.model_to_spline_by_index(model_idx, trajectory)
            sample = np.array(sample_spline(spline, self.sampling_rate, self.sampling_dimension), dtype=float)

            self.sampledict[model_idx].update({trajectory[0]: sample})

            return sample
        else:
            return self.sampledict[model_idx][trajectory[0]]

    # calculate average distance of trajectory control points with one of the methods:
    # methods = ['frechet', 'dtw', 'statistical distribution']
    # trajectories_to_compare = [
    #             ['object_Ego.AbstractDynamicObject$x', 'object_Ego.AbstractDynamicObject$y']
    #             ,['object_Other.AbstractDynamicObject$x', 'object_Other.AbstractDynamicObject$y']
    #         ]
    def pairwise_trajectory_distance(self, method, model_idx_1, model_idx_2, trajectories_to_compare):
        
        distances_total = [] # pairwise distances between model_idx_1 und model_idx_2 for all trajectories to compare

        for trajectory in trajectories_to_compare:
            distance = []

            if method == 'frechet':
                # make splines and samples out of it
                sample_idx_1 = self.get_sample_by_model_index(model_idx_1, trajectory)
                sample_idx_2 = self.get_sample_by_model_index(model_idx_2, trajectory)

                # compare splines with frechet
                distance.append(frechet_samples(sample_idx_1, sample_idx_2))

            elif method == 'dtw':
                sample_idx_1 = self.get_sample_by_model_index(model_idx_1, trajectory)
                sample_idx_2 = self.get_sample_by_model_index(model_idx_2, trajectory)

                distance.append(dtw_samples(sample_idx_1, sample_idx_2))

            elif method == 'statistical_dispersion':
                distances_in_trajectory = []
                cp_vars_x = [Symbol(trajectory[0] + '@' + str(t), REAL) for t in range(0, self.max_time_point)]
                cp_vars_y = [Symbol(trajectory[1] + '@' + str(t), REAL) for t in range(0, self.max_time_point)]

                for cp_var_x,cp_var_y in zip(cp_vars_x,cp_vars_y):
                    cp_x_idx_1 = self.models[model_idx_1].get_py_value(cp_var_x)
                    cp_y_idx_1 = self.models[model_idx_1].get_py_value(cp_var_y)
                    cp_x_idx_2 = self.models[model_idx_2].get_py_value(cp_var_x)
                    cp_y_idx_2 = self.models[model_idx_2].get_py_value(cp_var_y)

                    d = math.sqrt((cp_x_idx_2 - cp_x_idx_1) ** 2 + (cp_y_idx_2 - cp_y_idx_1) ** 2)

                    distances_in_trajectory.append(d)

                distance = np.mean(distances_in_trajectory)
            else:
                raise (NotImplementedError(f"The trajectory distance method {method} is not implemented."))

            distances_total.append(np.mean(distance))

        distance_out = np.mean(distances_total)
        if self.logPairwiseDistance:
            self.log({
                f"pairwise_distance_{method}": [
                model_idx_1,
                model_idx_2,
                distance_out,
                str(model_idx_1) + "->" + str(model_idx_2) + "[len=" + str(distance_out) + "];"]
            })

        return distance_out

    # return mean of all pairwise model distances
    def collective_scenario_distance(self):
        if len(self.trajectories_to_compare) == 0:
            raise RuntimeError("No trajectories to compare specified")

        distances = []
        numberOfModels = len(self.models)

        for distance_method in self.variety_distance_methods:
            if numberOfModels == 2:
                if self.logPairwiseDistance:
                    log = {f'pairwise_distance_{distance_method}': ['i','j','distance','graphiviz_string']}
                    self.init_logging(log)
                self.sum_of_pairwise_trajectory_distance[distance_method] = [self.pairwise_trajectory_distance(distance_method, 0, 1, self.trajectories_to_compare)]
            else:
                self.sum_of_pairwise_trajectory_distance[distance_method].append(np.sum([self.pairwise_trajectory_distance(distance_method, numberOfModels - 1, j, self.trajectories_to_compare) for j in range(0, numberOfModels - 1)]))
            distances.append(2 / ( numberOfModels * (numberOfModels - 1) ) * np.sum(self.sum_of_pairwise_trajectory_distance[distance_method]))

        return distances

    def check_model_variety(self):
        n = len(self.models)
        variable_names = ['object_Ego.AbstractDynamicObject$x',
                          'object_Ego.AbstractDynamicObject$y',
                          'object_Ego.AbstractDynamicObject$x2',
                          'object_Ego.AbstractDynamicObject$y2'
                          ]

        SUM = 0
        for t in range(0,self.max_time_point):
            for varname in variable_names:
                varname_val = []
                for m in self.models:
                    varname_val.append(float(m.get_py_value(Symbol(varname + '@' + str(t), REAL))))
                varname_variety = np.var(varname_val)
                varname_mean = np.mean(varname_val)
                SUM += math.sqrt(varname_variety)/varname_mean/math.sqrt(self.max_time_point) # Sum up normalized variention coefficient
        
        variety = SUM/self.max_time_point/len(variable_names)/2
        self.variety.append(variety)
        print(f"Variety: {variety}")

        if n == 1:
            plt.ion()
            self.fig = plt.figure()
            self.ax = self.fig.add_subplot(111)
            self.ax.set_xlim([-1,100])
            self.ax.set_ylim([0,1])
            self.line1, = self.ax.plot(range(0,n),self.variety, 'r-')
            self.fig.canvas.draw()
            self.fig.canvas.flush_events()
            plt.show()
        else:
            self.line1.set_xdata(range(0,n))
            self.line1.set_ydata(self.variety)
            self.fig.canvas.draw()
            self.fig.canvas.flush_events()
        return variety

    def set_trajectories_to_compare(self, trajectories_to_compare):
        self.trajectories_to_compare = trajectories_to_compare

    def plotModels(self, numberOfModelsToPrint, vehicleTypeNames=["PassengerCar"], laneTypeNames = ["Lane"]):
        vehiclevarNames = []
        laneObjNames = []
        maxTimePoint = 0

        ## !!!!Adapt capital of X-Variable (yes I know it's not nice ...)
        
        for var in self.variables:
            for name in vehicleTypeNames:
                if name in str(var) and ("$x@0" in str(var)):
                    vehiclevarNames.append(str(var).split('$')[0])
            
            for laneName in laneTypeNames:
                if laneName in str(var) and "$width" in str(var):
                    laneObjNames.append(str(var).split('$')[0])

            if 'time@' in str(var):
                timepoint = int(str(var).split('@')[1][0])
                if timepoint > maxTimePoint:
                    maxTimePoint = timepoint
        
        print("Vehiclevars: ", vehiclevarNames)
        plt.figure(figsize=(14, 8), frameon=False)
        plots = []
        legend = []
        rainbowMap = cm.rainbow(np.linspace(0, 1, numberOfModelsToPrint))
        lines = ["-","--",":","-."]
        linecycler = cycle(lines)
        objLineStyle = {}
        for obj in vehiclevarNames:
            objLineStyle.update({obj: next(linecycler)})
            plots.append(plt.plot(-20, -10, marker='o', color='black', linestyle = objLineStyle[obj]))
        # plots.append(plt.plot(-20, -10, marker='x', color='black'))

        for idxModel in range(numberOfModelsToPrint):
            ## Plot Vehicles
            egoPositionsX = []
            egoPositionsY = []
            otherPositionsX = []
            otherPositionsY = []
            egoV = []
            otherV = []

            for obj in vehiclevarNames:
                objPositionsX = []
                objPositionsY = []

                for time in range(maxTimePoint + 1):
                    objPositionsXvar = Symbol(obj + '$x@' + str(time), REAL)
                    objPositionsYvar = Symbol(obj + '$y@' + str(time), REAL)

                    objPositionsX.append(float(self.models[idxModel].get_py_value(objPositionsXvar)))
                    objPositionsY.append(float(self.models[idxModel].get_py_value(objPositionsYvar)))

                vX = [objPositionsX[i+1]-objPositionsX[i] for i in range(len(objPositionsX)-1)]
                vY = [objPositionsY[i+1]-objPositionsY[i] for i in range(len(objPositionsY)-1)]

                print(objPositionsX[:-1])
                print("")
                print(vX)

                plots.append(plt.quiver(objPositionsX[:-1], objPositionsY[:-1], vX, vY, angles='xy', color=rainbowMap[idxModel], linestyle = objLineStyle[obj]))
                #plots.append(plt.plot(objPositionsX, objPositionsY, marker='o', color=rainbowMap[idxModel], linestyle = objLineStyle[obj]))
                legend.append('Region ' + str(idxModel) + ': ' + obj)

            # Plot Lanes
            if idxModel == 0:
                for lane in laneObjNames:
                    lanePositionsYvar = Symbol(lane + '$y', REAL)
                    laneWidthVar = Symbol(lane + '$width', REAL)
                    laneUpperBound = self.models[idxModel].get_py_value(lanePositionsYvar) + 0.5*self.models[idxModel].get_py_value(laneWidthVar)
                    laneLowerBound = self.models[idxModel].get_py_value(lanePositionsYvar) - 0.5*self.models[idxModel].get_py_value(laneWidthVar)

                    plots.append(plt.axhline(y = laneUpperBound, color = 'black', linestyle = (0, (5, 10))))
                    plots.append(plt.axhline(y = laneLowerBound, color = 'black', linestyle = (0, (5, 10))))


        #plt.legend(legend,loc='upper right')
        plt.legend(['Trajectories of ' + varname.split('.')[0] for varname in vehiclevarNames], fontsize=14, loc='upper left')
        plt.axis([-5, 200, -6, 6])
        # plt.xlabel("Longitudinal Coordinate in m", fontsize=18)
        # plt.ylabel("Lateral Coordinate in m", fontsize=18)
        # plt.title('Vehicle Velocities of Different Sample Regions',loc='center')
        plt.savefig('OvertakingRegions.png', dpi=300)

        plt.show()

    # Colerdict example
    # colordict = {
    #    'object_Ego.AbstractDynamicObject': 'r',
    #    'object_Other.AbstractDynamicObject': 'b',
    #    'object_Obstruction.AbstractDynamicObject': 'grey'
    # }
    def make_trajectory_figures(self, vehicles_to_plot = [], figurepath = '', colordict = {}, figuresize = (15,5)):
        numberOfTimeSteps = 0
        for var in self.variables:
            if 'time@' in str(var):
                timepoint = int(str(var).split('@')[1])
                if timepoint > numberOfTimeSteps:
                    numberOfTimeSteps = timepoint

        numberOfTimeSteps += 1
        print(f"Max timepoints: {numberOfTimeSteps}")

        if not os.path.exists(figurepath):
            os.makedirs(figurepath)
            print(f"Created folder: {figurepath}")

        for i_fig in range(len(self.models)):
            print(f"Creating Trajectory Figure {i_fig}")
            fig = plt.figure(figsize=figuresize)

            # Get splines
            for vehicle in vehicles_to_plot:
                #print(f"Plot vehicle {vehicle}")
                vehiclenamex = []
                vehiclenamey = []
                for var in self.variables:
                    if (vehicle in str(var)) and ("@0" in str(var)):
                        if ("$X@0" in str(var) or "$x@0" in str(var)):
                            vehiclenamex = str(var).split('@')[0]
                        if ("$Y@0" in str(var) or "$y@0" in str(var)):
                            vehiclenamey = str(var).split('@')[0]

                if len(vehiclenamex) == 0:
                    raise(ValueError(f"x-variable of vehicle {vehicle} not found in smtformula"))
                if len(vehiclenamey) == 0:
                    raise(ValueError(f"y-variable of vehicle {vehicle} not found in smtformula"))
                #print("Symbolname: ", vehiclenamex + f"@{0}")

                x = [self.models[i_fig].get_py_value(Symbol(vehiclenamex + f"@{t}",REAL)) for t in range(0,numberOfTimeSteps)]
                x2 = [self.models[i_fig].get_py_value(Symbol(vehiclenamex + f"2@{t}",REAL)) for t in range(0,numberOfTimeSteps)]
                y = [self.models[i_fig].get_py_value(Symbol(vehiclenamey + f"@{t}",REAL)) for t in range(0,numberOfTimeSteps)]
                y2 = [self.models[i_fig].get_py_value(Symbol(vehiclenamey + f"2@{t}",REAL)) for t in range(0,numberOfTimeSteps)]

                #print(x)
                #print(x2)
                #print([[x[t],x2[t]] for t in range(0,len(x))])

                sampled_spline_x = sample_single_bezier_spline([[x[t],x2[t]] for t in range(0,len(x))],500)
                sampled_spline_y = sample_single_bezier_spline([[y[t],y2[t]] for t in range(0,len(y))],500)

                if vehicle in colordict.keys():
                    splineplot = plt.plot(sampled_spline_x,sampled_spline_y,label=f"Vehicle: {vehicle}",color=colordict[vehicle])
                else:
                    splineplot = plt.plot(sampled_spline_x, sampled_spline_y, label=f"Vehicle: {vehicle}")

                linecolor = splineplot[0].get_color()
                plt.plot(x,y,marker="o",markersize=5,linestyle="None",color=linecolor)

                for t in range(len(x)):

                    plt.annotate(f"{t}",
                                 (x[t],y[t]),
                                 textcoords="offset points",
                                 xytext=(0,10),
                                 ha='center')
            
            plt.ylabel("y-Positions")
            plt.xlabel("x-Positions")
            plt.legend()
            plt.savefig(f"{figurepath}/Trajectories_model_{i_fig}")
            plt.close()

        return

    def make_spatialviewSatisfaction_figures(self, booleanVariableNames_to_plot = [],  figurepath = '', numberOfModelsInFigure = 10, figuresize = (15,5)):

        def get_sat_over_time(variableNames, timesteps, model):
            sat_over_time = []
            for varname in variableNames:
                satAtTime = [model.get_py_value(Symbol(varname + '@' + str(timestep), BOOL)) 
                    for timestep in range(timesteps)]
                sat_over_time.append(satAtTime)
            
            return sat_over_time

        if len(booleanVariableNames_to_plot) == 0:
            print('No spatial views to make plots')
            return
        
        if len(self.models) == 0:
            print('No models to make a plot')
            return

        numberOfTimeSteps = 0
        number_of_booleanVariableNames = len(booleanVariableNames_to_plot)
        numberOfModels = len(self.models)

        for var in self.variables:
            if 'time@' in str(var):
                timepoint = int(str(var).split('@')[1])
                if timepoint > numberOfTimeSteps:
                    numberOfTimeSteps = timepoint

        numberOfTimeSteps += 1
        print(f"Max timepoints: {numberOfTimeSteps}")

        satisfactions = np.array([get_sat_over_time(booleanVariableNames_to_plot, numberOfTimeSteps, m) for m in self.models])
        satisfactions_to_plot = np.empty([numberOfModels * numberOfTimeSteps, number_of_booleanVariableNames])

        for i_fig in range(numberOfModels):
            satisfactions_to_plot[i_fig * numberOfTimeSteps: (i_fig + 1) * numberOfTimeSteps,:] = satisfactions[i_fig].transpose()

        numberOfFigures = max(int(numberOfModels / numberOfModelsInFigure),1)
        print(f"Number of Figures: {numberOfFigures}")

        if not os.path.exists(figurepath):
            os.makedirs(figurepath)
            print(f"Created folder: {figurepath}")

        for i_fig in range(numberOfFigures):
            print(f"Creating figure {i_fig}")
            fig = plt.figure(figsize=figuresize)
            colours = (["red", "green"])
            cmap = ListedColormap(colours)
            yticknames = [re.sub("var__spatialView_U_|tmp_[0-9]+__","", str(var)) for var in booleanVariableNames_to_plot]
            plt.pcolormesh(satisfactions_to_plot[i_fig*numberOfModelsInFigure*numberOfTimeSteps:(i_fig + 1)*numberOfModelsInFigure*numberOfTimeSteps,:].transpose(), cmap=cmap)
            plt.vlines(x = [numberOfTimeSteps * i for i in range(numberOfModelsInFigure)], ymin=0, ymax=number_of_booleanVariableNames, color='white' )
            if numberOfModelsInFigure != 1:
                plt.xlabel(f"Models {numberOfModelsInFigure*i_fig}-{numberOfModelsInFigure*(i_fig+1) - 1} with {numberOfTimeSteps} timesteps")
                plt.ylabel("Invariants")
                plt.xticks([(numberOfTimeSteps * i + int(numberOfTimeSteps/2) + 1) for i in range(numberOfModelsInFigure)], [str(i_fig*numberOfModelsInFigure + i) for i in range(numberOfModelsInFigure)])
            #else:
                #plt.xticks([(numberOfTimeSteps * i + int(numberOfTimeSteps/2) + 1) for i in range(numberOfModelsInFigure)], ["Model " + str(i_fig*numberOfModelsInFigure + i) for i in range(numberOfModelsInFigure)],fontsize=15)
            plt.xticks([i for i in range(numberOfModelsInFigure*numberOfTimeSteps)], [], minor=True)
            plt.yticks([0.5 + i for i in range(number_of_booleanVariableNames)],yticknames,rotation='vertical',va='center',fontsize=15)
            if numberOfModelsInFigure != 1:
                plt.title(f"Invariant satisfaction over time for models number {numberOfModelsInFigure*i_fig} - {numberOfModelsInFigure*(i_fig+1) - 1}")
            plt.tight_layout()
            plt.savefig(f"{figurepath}/ModelSatisfaction{numberOfModelsInFigure*i_fig}-{numberOfModelsInFigure*(i_fig+1)-1}")
            plt.close()

        print(f"Satisfaction figures sucessfully created.")
        return

"""
#------------------------ Examples for using the modelSearcher -------------------------------
#smtFilePath = "smtFiles/singleInv.smt"
#smtFilePath = "smtFiles/TSC_LaneChangeForced_Inv0_Bezier.smt"
#smtFilePath = "smtFiles/star.smt" ##Error
#smtFilePath = "smtFiles/TSC_overtakingSafetydist_50.smt"
#smtFilePath = "smtFiles/threeLaneOvertake.smt"
smtFilePath = "smtFiles/tsc-1.smt"

# Adding '(check-sat)' to the end, if it is not at in the file
with open(smtFilePath,'r+') as smtFile:
    if ('(check-sat)' not in smtFile.read()):
        print("no check-sat")
        smtFile.write('(check-sat)')

smtFormula = allPySmt.rewriteEQ(simplify(read_smtlib(smtFilePath)))

### Find special variables and atoms
#atomsLeq = [at for at in get_atoms(smtFormula) if (at.is_le() or at.is_lt() or at.is_equals())]
#atomsElse = [at for at in get_atoms(smtFormula) if not (at.is_le() or at.is_lt() or at.is_equals())]
#atomsBool = [at for at in get_atoms(smtFormula) if (at.get_type() == BOOL)]# and "var__" in str(var)]
#invariantVariables = [var for var in get_free_variables(smtFormula) if "var__" in str(var)]

### rearange Order of Atoms randomly
#seed = random.randrange(10000)
#seed = 881
#rng = random.Random(seed)
#print("Seed was:", seed)
#rng.shuffle(atomsLeq)

loggingPath = 'logs/Search_' + time.strftime("%Y%m%d_%H%M", time.gmtime(time.time()))

modelSearcher = ModelSearcher(smtFormula, loggingPath=loggingPath, collectGarbadge=False)
modelSearcher.search_allPySmt(10, get_atoms(smtFormula), False, False, False, False)
#modelSearcher.plotModels(5, ["PassengerCar", "Truck"], ["Lane"])
#modelSearcher.plotModels(5, ["Car"], ["Lane"])
#modelSearcher.export_model_variables(path = "testOutfolder")
"""