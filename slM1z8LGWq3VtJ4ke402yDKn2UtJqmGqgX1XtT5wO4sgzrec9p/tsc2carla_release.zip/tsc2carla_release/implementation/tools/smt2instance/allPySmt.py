from pysmt.solvers.solver import Solver
from pysmt.shortcuts import *
from pysmt.solvers.z3 import Z3Converter
from pysmt.operators import op_to_str
from z3 import And as z3And
import copy
import math

def binom(n, k):
    return math.factorial(n) // math.factorial(k) // math.factorial(n - k)

def rewriteEQ( formula ):
    subst = {}
    for atom in formula.get_atoms():
        if atom.is_equals():
            assert (len(atom.args()) == 2)
            p1 = LE(atom.arg(0), atom.arg(1))
            p2 = GE(atom.arg(0), atom.arg(1))
            subst[atom] = And( p1, p2)
    return( substitute( formula, subst) )

def removeEQ( atoms ):
    newatoms = []
    for atom in atoms:
        if not atom.is_theory_relation():
            #print( "Added Boolen variable")
            newatoms.append(atom)
        elif atom.is_le():
            #print( "Added LEQ")
            newatoms.append(atom)
        elif atom.is_lt():
            #print( "Added LTH")
            newatoms.append(atom)
        elif atom.is_equals():
            #print( "Added EQ")
            assert( len(atom.args()) == 2)
            newatoms.append( LE( atom.arg(0), atom.arg(1)))
            newatoms.append( GE( atom.arg(0), atom.arg(1)))
        else:
            print("Unknown theory atom!")
            assert(False)
    return newatoms

def isPureReal( term ):
    for subexp in term.args():
        if subexp.get_type() is not REAL:
            return False
        if not isPureReal( subexp ):
            return False
    return True

def getFormulaFromSolver( solver ):
    z3conv = Z3Converter(get_env(), solver.z3.ctx)
    return z3conv.back_via_smtlib(z3And(solver.z3.assertions()))

def isSubset(formulaA, formulaB ):
    #Checks whether formulaA is a Subset of formulaB
    # i.e. formulaA -> formulaB is valid,
    # i.e. not( formulaA -> formulaB ) is unsat
    # i.e. not( not(formulaA) or formulaB ) is unsat
    # i.e. formulaA and not(formulaB) is unsat
    s = Solver(name="z3")
    s.add_assertion(formulaA)
    s.add_assertion(Not(formulaB))
    return not s.solve()

def all_pySmt( formula, initial_terms,
               check_redundant = False, check_subset = False,
               check_completeness = True, check_soundness = True,
               solver = Solver(name="z3",)):
    #Note: check_completeness and check_soundness will fail if initial_terms is not a complete list of atoms
    
    def block_term( solver, model, term):
        if model.get_value(term).is_true():
            solver.add_assertion( Not( term ) )
        else:
            solver.add_assertion( term )

    def fix_term( solver, model, term):
        if model.get_value(term).is_true():
            solver.add_assertion( term )
        else:
            solver.add_assertion( Not(term) )

    def mark_relevant( redundancy_solver, term):
        if check_redundant:
            redundancy_solver.add_assertion( Iff( term, termcopymap[term] ) )

    def redundancy_check( redundancy_solver, terms, skip_terms, check_term, redundant_terms ):
        if check_redundant:
            redundancy_solver.push()
            open_terms = [ open_term for open_term in terms
                           if open_term not in skip_terms
                           and open_term not in redundant_terms
                           and open_term is not check_term ]
            for open_term in open_terms:
                redundancy_solver.add_assertion( Iff( open_term, termcopymap[open_term] ) )
            returnval = not( redundancy_solver.solve() )
            redundancy_solver.pop()
            return returnval
        else:
            return False


    def subset_check( subset_solver, model, terms, skip_terms, check_term, redundant_terms ):
        if check_subset:
            subset_solver.push()
            open_terms = [ open_term for open_term in terms
                           if open_term not in skip_terms
                           and open_term not in redundant_terms
                           and open_term is not check_term ]
            for open_term in open_terms:
                fix_term( subset_solver, model, open_term )
            returnval = not( subset_solver.solve() )
            subset_solver.pop()
            return returnval
        else:
            return False

    def solvers_push():
        if check_subset:
            subset_solver.push()
        if check_redundant:
            redundancy_solver.push()
        solver.push()

    def solvers_pop():
        solver.pop()
        if check_redundant:
            redundancy_solver.pop()
        if check_subset:
            subset_solver.pop()

    def all_smt_rec( terms, p_fixed_terms = [] ):
        global counter
        fixed_terms = copy.copy( p_fixed_terms )

        if solver.solve():
            #counter += 1
            #counter += 1/(2**len(initial_terms))
            model = solver.get_model()
            yield model, counter

            skip_terms = []
            redundant_terms = []
            solvers_push()
            last_term = None
            for term in terms:
                if redundancy_check( redundancy_solver, terms, skip_terms, term, redundant_terms ):
                    redundant_terms.append( term)
                    continue

                if subset_check( subset_solver, model, terms, skip_terms, term, redundant_terms ):
                    skip_terms.append( term )
                    continue

                if last_term is not None:
                    fix_term(solver, model, last_term)
                    if check_redundant:
                        fix_term(redundancy_solver, model, last_term)
                        mark_relevant(redundancy_solver, last_term)
                    if check_subset:
                        fix_term(subset_solver, model, last_term)

                solvers_push()
                block_term( solver, model, term)
                block_term( redundancy_solver, model, term )
                mark_relevant( redundancy_solver, term )
                block_term( subset_solver, model, term )

                fixed_terms.append(term)
                last_term = term
                
                yield from all_smt_rec( [term for term in terms if term not in fixed_terms], fixed_terms )
                solvers_pop()

            solvers_pop()

            region_formula = And([term if model.get_value(term).is_true() else Not(term)
                                  for term in fixed_terms])
            region_formulae.append( region_formula )
            if check_soundness:
                assert( isSubset( region_formula, formula ) )
        else:
            #counter += 2**(len(terms) - len(initial_terms))
            counter += 2**(len(terms))
            #n = len(terms)
            #counter += n+1
            

    #Ensure that atoms are "pure"
    #This is a HACK!
    if check_redundant or check_subset:
        for term in initial_terms:
            if term not in get_free_variables( formula ):
                if not isPureReal(term):
                    print( "check_redundant or check_subset is not supported for the term ", term)
                    assert( False )

    solver.add_assertion( formula )
    region_formulae = []
    dimension = len(get_free_variables(formula))

    #needed for check_redundant:
    varcopymap = { var: Symbol(var.symbol_name() + "_copy", get_type(var)) for var in get_free_variables(formula) }
    termcopymap = { atom: substitute( atom, varcopymap ) for atom in formula.get_atoms() }
    redundancy_solver = Solver( name="z3" )
    redundancy_solver.add_assertion( And(formula, Not( substitute(formula, termcopymap ) ) ) )

    #needed for check_subset:
    subset_solver = Solver(name="z3")
    subset_solver.add_assertion( Not( formula ) )

    global counter
    counter = 0
    
    yield from all_smt_rec( initial_terms )
    print("Final counter: ", counter)
    if check_completeness:
        dnf = Or( [cnf for cnf in region_formulae] )
        assert( isSubset( dnf, formula) )
        assert( isSubset( formula, dnf) )
        print( "Successfully decomposed the formula into convex regions!" )
