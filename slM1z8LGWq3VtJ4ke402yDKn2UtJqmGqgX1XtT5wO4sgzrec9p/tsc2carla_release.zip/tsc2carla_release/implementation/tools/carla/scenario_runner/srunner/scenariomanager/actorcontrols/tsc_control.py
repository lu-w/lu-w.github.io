import carla
import math
import pid

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.actorcontrols.basic_control import BasicControl
from srunner.scenariomanager.timer import GameTime
from agents.navigation.local_planner import LocalPlanner
from agents.navigation.local_planner import RoadOption

class TscControl(BasicControl):

    def __init__(self, actor, args=None):
        super(TscControl, self).__init__(actor)
        # actor.set_enable_gravity(False)

        self._last_update = None
        self._next_waypoint = None
        self._time_delta = None

        self._reached_goal = False
        self._location_pid = pid.PID(1.0, 0.01, 0.1)
        self._planner = None

    def _on_obstacle(self, event):
        print("on_obstacle called")
        if not event:
            return

    def reset(self):
        print("reset called")
        # self._location_pid.log()

    def run_step(self):
        print("--- rs ---")
        print(GameTime.get_time())

        # if self._waypoints and not self._planner:
        #     self._planner = LocalPlanner(self._actor)
        #     plan = []
        #     for transform in self._waypoints:
        #         waypoint = CarlaDataProvider.get_map().get_waypoint(
        #         transform.location, project_to_road=True, lane_type=carla.LaneType.Any)
        #         plan.append((waypoint, RoadOption.LANEFOLLOW))
        #     #wps = []
        #     #for nw in self._waypoints:
        #     #    wps.append([nw, RoadOption.LANEFOLLOW])
        #     self._planner.set_global_plan(plan)
        #
        # if self._planner:
        #     control = self._planner.run_step(False)
        #     #self._actor.

        # if self._next_waypoint and self._next_waypoint.location.distance(self._actor.get_location()) < 0.2:
        #     print("next waypoint reached")
        #     self._next_waypoint = None
        #
        # if self._waypoints and not self._next_waypoint:
        #     self._next_waypoint = self._waypoints[0]
        #     self._waypoints = self._waypoints[1:]
        #     print("next: ", self._next_waypoint)
        #     #self._last_update = GameTime.get_time()
        #     self._location_pid.set_target(self._next_waypoint.location)
        #
        # if self._next_waypoint:
        #     #self._set_new_velocity(self._next_waypoint)
        #     self.pid_control(self._next_waypoint)



    # def run_step(self):
    #     print("-rs")
    #
    #     if self._reached_goal:
    #         self._actor.set_target_velocity(carla.Vector3D(0, 0, 0))
    #         return
    #
    #     #if not self._waypoints:
    #     #    self._reached_goal = True
    #     #    return
    #     #else:
    #     #    self._reached_goal = False
    #
    #
    #
    #     if self._waypoints and (not self._next_waypoint or self._next_waypoint.location.distance(self._actor.get_location()) < 0.2):
    #         self._next_waypoint = self._waypoints[0]
    #         self._waypoints = self._waypoints[1:]
    #
    #     if self._next_waypoint:
    #         self._set_new_velocity(self._next_waypoint)


        # if not self._next_waypoint:
        #     self._next_waypoint = self._waypoints[0]
        #
        #     self._waypoints = self._waypoints[1:]
        #     if self._waypoints is None:
        #         self._reached_goal = True
        #
        # print(self._next_waypoint)
        # print(self._actor.get_location())
        #
        # if self._next_waypoint.distance(self._actor.get_location()) < 0.2:
        #     print("waypoint reached, get next one")
        #     self._next_waypoint = None
        # else:
        #     self._set_new_velocity(self._next_waypoint)


    # def run_step(self):
    #     if self._reached_goal:
    #         # Reached the goal, so stop
    #         self._actor.set_target_velocity(carla.Vector3D(0, 0, 0))
    #         return
    #     #print("run step")
    #
    #     if not self._waypoints:
    #         # no waypoint given by scenario, just do nothing
    #         return
    #
    #     if self._waypoints and self._waypoints[0].location.distance(self._actor.get_location()) < 0.5:
    #         self._waypoints = self._waypoints[1:]
    #
    #     self._reached_goal = False
    #     if not self._waypoints:
    #         self._reached_goal = True
    #     else:
    #         self._set_new_velocity(self._waypoints[0])
    #         #self._set_new_velocity(self._offset_waypoint(self._waypoints[0]))
    #         #direction_norm = self._set_new_velocity(self._offset_waypoint(self._waypoints[0]))
    #         #if direction_norm < 4.0:
    #         #    self._waypoints = self._waypoints[1:]
    #         #    if not self._waypoints:
    #         #        self._reached_goal = True


    def _offset_waypoint(self, transform):
       # print("offset waypoint")
        if self._offset == 0:
            offset_location = transform.location
        else:
            right_vector = transform.get_right_vector()
            offset_location = transform.location + carla.Location(x=self._offset*right_vector.x,
                                                                  y=self._offset*right_vector.y)

        return offset_location

    def pid_control(self, target_transform):
        print(self._actor)
        self.pid_location(target_transform.location)
        #self.pid_rotation(target_transform.location, target_transform.rotation)

    def pid_location(self, target_location):
        target_speed = self._target_speed

        current_location = CarlaDataProvider.get_location(self._actor)
        #error_location = target_location - current_location

        #td = self._last_update - GameTime.get_time()


        #pid_location = (kp * error_location) +

        error_location = self._location_pid.step(current_location)

        direction_norm = math.sqrt(error_location.x**2 + error_location.y**2)
        time_req = direction_norm / target_speed

        velocity = carla.Vector3D(0, 0, min(0, target_location.z - current_location.z))
        if direction_norm != 0.0:
            velocity.x = error_location.x / time_req
            velocity.y = error_location.y / time_req

        print(f"vel {velocity}")
        self._actor.set_target_velocity(velocity)



    def pid_rotation(self, target_location, target_rotation):
        target_speed = self._target_speed
        current_location = CarlaDataProvider.get_location(self._actor)

        error_location = target_location - current_location

        direction_norm = math.sqrt(error_location.x**2 + error_location.y**2)


        time_req = direction_norm / target_speed

        current_yaw = CarlaDataProvider.get_transform(self._actor).rotation.yaw

        delta_yaw = target_rotation.yaw - current_yaw

        if math.fabs(delta_yaw) > 360:
            delta_yaw = delta_yaw % 360

        if delta_yaw > 180:
            delta_yaw = delta_yaw - 360
        elif delta_yaw < -180:
            delta_yaw = delta_yaw + 360

        angular_velocity = carla.Vector3D(0, 0, 0)
        if direction_norm != 0.0:
            angular_velocity.z = delta_yaw / time_req
        self._actor.set_target_angular_velocity(angular_velocity)

    def _set_new_velocity(self, transform):
        #print("set new velocity")
        print(self._actor)
        target_speed = self._target_speed

        next_location = transform.location
        next_rotation = transform.rotation

        #if not self._last_update:
        #    self._last_update = current_time

        if target_speed == 0:
            return

        #  current_speed = math.sqrt(self._actor.get_velocity().x**2 + self._actor.get_velocity().y**2)
        # set speed
        #print("---")
        #print(transform)
        current_location = CarlaDataProvider.get_location(self._actor)
        direction = next_location - current_location
        direction_norm = math.sqrt(direction.x**2 + direction.y**2)
        print(f"speed {target_speed}")
        print(f"cdir {current_location}")
        print(f"ndir {next_location}")
        print(f"dir {direction}")
        print(f"dir {direction_norm}")
        time_req = direction_norm / target_speed

        velocity = carla.Vector3D(0, 0, min(0, 0 - current_location.z))
        if direction_norm != 0:
            velocity.x = direction.x / time_req
            velocity.y = direction.y / time_req
        print(f"vel {velocity}")

        self._actor.set_target_velocity(velocity)
        # set heading
        current_yaw = CarlaDataProvider.get_transform(self._actor).rotation.yaw

        delta_yaw = next_rotation.yaw - current_yaw

        if math.fabs(delta_yaw) > 360:
            delta_yaw = delta_yaw % 360

        if delta_yaw > 180:
            delta_yaw = delta_yaw - 360
        elif delta_yaw < -180:
            delta_yaw = delta_yaw + 360

        angular_velocity = carla.Vector3D(0, 0, 0)
        if direction_norm != 0.0:
            angular_velocity.z = delta_yaw / time_req
        self._actor.set_target_angular_velocity(angular_velocity)

        current_time = GameTime.get_time()
        print(current_time)
        self._last_update = current_time
        print(f"ang {angular_velocity}")
