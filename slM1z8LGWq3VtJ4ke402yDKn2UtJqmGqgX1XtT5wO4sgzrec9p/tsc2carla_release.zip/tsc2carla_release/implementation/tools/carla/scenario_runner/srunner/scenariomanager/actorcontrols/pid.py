import carla
import csv
import matplotlib.pyplot as plt
import random
import numpy as np

class PID:

    def __init__(self, p, i, d):
        self._p = p
        self._i = i
        self._d = d
        self._target_location = None
        self._error_sum = None
        self._last_current_location = None
        self._logging = True
        self._log = []
        self.csv = False
        self.seed = random.randint(0, 200000)


    def set_target(self, target_location):
        self._target_location = target_location
        self._error_sum = carla.Location(0, 0, 0)

    def step(self, current_location):
        location = carla.Location(0, 0, 0)
        if not self._target_location:
            return location

        error_location = self._target_location - current_location

        op = self._p * error_location

        oi = self._i * self._error_sum
        self._error_sum = self._error_sum + error_location

        if not self._last_current_location:
            self._last_current_location = current_location

        od = - self._d * (current_location - self._last_current_location)
        self._last_current_location = current_location

        o = op + oi + od

        if self._logging:
            self._log.append({
                'target_location_x': self._target_location.x,
                'target_location_y': self._target_location.y,
                'target_location_z': self._target_location.z,
                'current_location_x': current_location.x,
                'current_location_y': current_location.y,
                'current_location_z': current_location.z,
                'p_x': op.x,
                'p_y': op.y,
                'p_z': op.z,
                'i_x': oi.x,
                'i_y': oi.y,
                'i_z': oi.z,
                'd_x': od.x,
                'd_y': od.y,
                'd_z': od.z,
                'output_x': o.x,
                'output_y': o.y,
                'output_z': o.z
            })

        return o

    def log(self):
        threshold = 0.5

        tx = [entry["target_location_x"] for entry in self._log]
        ty = [entry["target_location_y"] for entry in self._log]

        plt.plot(tx, ty, color="green", linewidth=1, marker='o', markersize=2)

        cx = [entry["current_location_x"] for entry in self._log]
        cy = [entry["current_location_y"] for entry in self._log]

        plt.plot(cx, cy, color="red", linewidth=1, marker='o', markersize=2)

        # calculate min x max x and min y max x, the greater difference has not to be iqr'd
        minx = min(tx)
        maxx = max(tx)
        miny = min(ty)
        maxy = max(ty)
        dx = abs(maxx - minx)
        dy = abs(maxy - miny)

        if dx < dy:
            q1 = np.percentile(cy, 35)
            q3 = np.percentile(cy, 65)
            iqr = q3 - q1
            lower_limit = q1 - threshold * iqr
            upper_limit = q3 + threshold * iqr
            plt.ylim(lower_limit, upper_limit)
            plt.xlim(minx, maxx)
        else:
            q1 = np.percentile(cx, 35)
            q3 = np.percentile(cx, 65)
            iqr = q3 - q1
            lower_limit = q1 - threshold * iqr
            upper_limit = q3 + threshold * iqr
            plt.xlim(lower_limit, upper_limit)
            plt.ylim(minx, maxx)

        plt.savefig(f"C:\\Users\\kalw_vi\\Desktop\\ex-{self.seed}.png")




