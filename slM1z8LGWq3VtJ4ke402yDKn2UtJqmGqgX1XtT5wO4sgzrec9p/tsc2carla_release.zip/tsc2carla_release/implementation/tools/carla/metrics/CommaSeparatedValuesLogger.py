from basic_metric import BasicMetric
import pandas as pd
from pathlib import Path


class CommaSeparatedValuesLogger(BasicMetric):
    def __init__(self, town_map, log, criteria=None):
        super().__init__(town_map, log)

    def _create_metric(self, town_map, log, criteria):
        ego_id = log.get_ego_vehicle_id()
        other_id = log.get_actor_ids_with_role_name('Bus')[0]
        dataframe = pd.DataFrame()

        ego_transforms = log.get_all_actor_transforms(ego_id)
        ego_velocities = log.get_all_actor_velocities(ego_id)
        ego_accelerations = log.get_all_actor_accelerations(ego_id)
        dataframe['ego_x'] = [transform.location.x for transform in ego_transforms if transform]
        dataframe['ego_y'] = [transform.location.z for transform in ego_transforms if transform]
        dataframe['ego_yaw'] = [transform.rotation.yaw for transform in ego_transforms if transform]
        dataframe['ego_vx'] = [velocity.x for velocity in ego_velocities if velocity]
        dataframe['ego_vy'] = [velocity.z for velocity in ego_velocities if velocity]
        dataframe['ego_ax'] = [acceleration.x for acceleration in ego_accelerations if acceleration]
        dataframe['ego_ay'] = [acceleration.z for acceleration in ego_accelerations if acceleration]

        other_transforms = log.get_all_actor_transforms(other_id)
        other_velocities = log.get_all_actor_velocities(other_id)
        other_accelerations = log.get_all_actor_accelerations(other_id)
        dataframe['other_x'] = [transform.location.x for transform in other_transforms if transform]
        dataframe['other_y'] = [transform.location.z for transform in other_transforms if transform]
        dataframe['other_yaw'] = [transform.rotation.yaw for transform in other_transforms if transform]
        dataframe['other_vx'] = [velocity.x for velocity in other_velocities if velocity]
        dataframe['other_vy'] = [velocity.z for velocity in other_velocities if velocity]
        dataframe['other_ax'] = [acceleration.x for acceleration in other_accelerations if acceleration]
        dataframe['other_ay'] = [acceleration.z for acceleration in other_accelerations if acceleration]

        dataframe.to_csv(f'results/carla/{Path(log.get_log_file()).stem}.csv')
