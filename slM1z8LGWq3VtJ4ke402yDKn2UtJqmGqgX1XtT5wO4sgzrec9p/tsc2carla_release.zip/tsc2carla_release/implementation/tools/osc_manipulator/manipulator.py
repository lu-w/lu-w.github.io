import argparse
import xmltodict
import xml.dom.minidom

# parse arguments
parser = argparse.ArgumentParser(description="manipulate openscenario files to be usable in tsc2carla")
parser.add_argument("--input", "-i", metavar='i', nargs=1, required=True, help="the input openscenario file")
parser.add_argument("--output", "-o", metavar='o', nargs=1, required=True, help="the output openscenario file")
parser.add_argument("--ego", "-e", metavar='e', nargs=1, required=True, help="the name of the ego")

args = parser.parse_args()
inputFile = args.input[0]
outputFile = args.output[0]
egoName = args.ego[0]

# read file and convert to xml
file = open(inputFile, "r")
xml_string = file.read()
file.close()
python_dict = xmltodict.parse(xml_string)

# search for maneuvergroup of ego vehicle and delete
maneuverGroups = python_dict["OpenScenario"]["Storyboard"]["Story"]["Act"]["ManeuverGroup"]
for i in range(len(maneuverGroups)):
    maneuverGroup = maneuverGroups[i]
    entityRef = maneuverGroup["Actors"]["EntityRef"]["@entityRef"]
    if entityRef != egoName:
         continue
    del python_dict["OpenScenario"]["Storyboard"]["Story"]["Act"]["ManeuverGroup"][i]
    break

# parse back to string and prettyprint
xml_output = xmltodict.unparse(python_dict)
xml_dom = xml.dom.minidom.parseString(xml_output)

# write to file
with open(outputFile, 'w') as f:
    f.write(xml_dom.toprettyxml())
    f.close()

print("Removed ego trajectory")