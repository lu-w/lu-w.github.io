import yaml as yl
from time import time_ns
from pathlib import Path

def archive_old_config():
    config_dir = 'data_storage/config'
    for tool_config_dir in Path(config_dir).iterdir():
        if tool_config_dir.is_dir():
            for old_conf in Path(tool_config_dir).iterdir():
                if not old_conf.is_dir():
                    old_conf.rename(tool_config_dir / Path('archive') / old_conf.name)

def distribute_config(static_config_path: str, dynamic_config_path: str, stub: int = time_ns()):
    archive_old_config()
    with open(static_config_path) as static_config_file:
        static_config = yl.safe_load(static_config_file)
    with open(dynamic_config_path) as dynamic_config_file:
        dynamic_config = yl.safe_load(dynamic_config_file)

    for tsc_ind, tsc in enumerate(dynamic_config['tsc2smt']['tsc_paths']):
        with open(f'data_storage/config/tsc2smt/tsc2smt_{Path(tsc).stem}_{stub}.yaml', 'w') as tsc2smt_config_file:
            temp_config = dynamic_config['tsc2smt']
            temp_config['tsc_path'] = tsc
            temp_config['export_file_name'] = Path(tsc).stem + '.smt'
            temp_config['solver_configuration'] = dynamic_config['solver_configuration']
            temp_config.pop('tsc_paths')
            yl.dump(temp_config, tsc2smt_config_file)

        with open(f'data_storage/config/instance2openx/instance2openx_{Path(tsc).stem}_{stub}.yaml', 'w') as tsc2smt_config_file:
            temp_config = dynamic_config['instance2openx']
            temp_config['tsc_path'] = tsc
            yl.dump(dynamic_config['instance2openx'], tsc2smt_config_file)

    for inst_ind, instance in enumerate(dynamic_config['smt2instance']['instances'].items()):
        with open(f'data_storage/config/smt2instance/smt2instance_{instance[0]}_{stub}.yaml', 'w') as tsc2smt_config_file:
            temp_config = dynamic_config['smt2instance']
            temp_config['instances'] = instance[1]
            yl.dump(temp_config, tsc2smt_config_file)

if __name__ == '__main__':
    distribute_config(static_config_path='data_storage/config/static_config.yaml',
                      dynamic_config_path='data_storage/config/dynamic_config.yaml')
