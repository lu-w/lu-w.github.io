import os
import sys
import time

import carla
import psutil
import subprocess
from pathlib import Path
from utils.process_manager import find_processes_by_name


def stop_all_carla_servers():
    running_carla_servers = find_processes_by_name('carla')
    if len([p['name'] for p in running_carla_servers]) > 0:
        for pid in [p['pid'] for p in running_carla_servers]:
            psutil.Process(pid).kill()
            print(pid)


def start_carla_server(carla_root=Path(''), port=2000, low_quality=False):
    if sys.platform == "linux" or sys.platform == "linux2":
        carla_exe = "CarlaUE4.sh"
    elif sys.platform == "win32":
        carla_exe = "CarlaUE4.exe"
    else:
        print("Unsupported platform: {}".format(sys.platform))
        sys.exit()
    print(f"Loading CARLA from " + str(carla_root) + "/" + carla_exe + (" with low quality" if low_quality else ""))
    with open("carla_server.log", "wb") as out:
        cmd = [os.path.join(carla_root, carla_exe), f'-carla-world-port={port}']
        if low_quality:
            cmd.append('-quality-level=Low')
        subprocess.Popen(cmd, stdout=out, stderr=out)
        print("Waiting for CARLA server to become available")
        # TODO there must be a better solution. However, checking whether the port is open won't help
        #  (it's open way too early), and using a fake client and call client.get_world() does not do the trick either
        time.sleep(20)
        print("CARLA server is now available")


def carla_server_available():
    return len(find_processes_by_name('carla')) > 0
