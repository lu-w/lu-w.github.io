import psutil


def find_processes_by_name(process_name):
    """
    Get a list of all the PIDs of a all the running process whose name contains
    the given string processName
    """
    process_objects = []
    # Iterate over the all the running process
    for proc in psutil.process_iter():
        try:
            p_info = proc.as_dict(attrs=['pid', 'name', 'create_time'])
            # Check if process name contains the given name string.
            if process_name.lower() in p_info['name'].lower():
                process_objects.append(p_info)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return process_objects
