import sys

import pandas as pd
import numpy as np
import dtw
import glob
from pathlib import Path


def distance_dtw(a, b):
    return dtw.dtw(a, b, keep_internals=True, step_pattern=dtw.rabinerJuangStepPattern(6, "c"))


def calc_variation(simulator):
    scenario_results = set(glob.glob(f'results/{simulator}/*'))
    normalized_distances = []
    for scenario_result_1 in scenario_results:
        for scenario_result_2 in scenario_results - {scenario_result_1}:
            first_data = pd.read_csv(scenario_result_1,
                                     header=6,
                                     usecols=['#1 World_Position_X [m] ', '#2 World_Position_X [m] '],
                                     skipinitialspace=True,
                                     dtype=float)
            second_data = pd.read_csv(scenario_result_2,
                                      header=6,
                                      usecols=['#1 World_Position_Y [m] ', '#2 World_Position_Y [m] '],
                                      skipinitialspace=True,
                                      dtype=float)
            dtw_res = distance_dtw(first_data.to_numpy(), second_data.to_numpy())
            norm_dist = dtw_res.normalizedDistance
            normalized_distances.append(norm_dist)
    return normalized_distances


def main():
    for simulator in [path.name for path in Path('simulator').iterdir() if path.is_dir()]:
        distances_list = calc_variation(simulator)
        print(
            f'Simulator:, {simulator}'
            f'Mean: {np.mean(distances_list)}, '
            f'Median: {np.median(distances_list)}, '
            f'Variance: {np.var(distances_list)}'
        )


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(e)
