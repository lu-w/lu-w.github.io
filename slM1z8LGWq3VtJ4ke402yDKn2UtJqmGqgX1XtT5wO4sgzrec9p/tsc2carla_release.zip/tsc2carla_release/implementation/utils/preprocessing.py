from lxml import etree
import os
from pathlib import Path
import glob


class Preprocessor(object):
    def __init__(self, args):
        self.source = args.source
        if args.target is None:
            self.target = args.source
        else:
            self.target = args.target
        self.et = etree.parse(args.source)
        self.root = self.et.getroot()
        self.stop_trigger = args.stop_trigger
        self.start_trigger = args.start_trigger
        self.priority = args.priority
        self.header_description = args.header_description
        self.clean_up = args.clean_up
        self.remove_ego_trajectory = args.remove_ego_trajectory
        self.extract_scenario_information = args.extract_scenario_information
        self.ego = args.ego

    def change_stop_trigger(self):
        simulation_time = max([x.attrib['time'] for x in self.root.iter('Vertex')])
        stop_trigger = self.et.find('./Storyboard/StopTrigger')
        stop_trigger[0] = etree.fromstring(f"""<ConditionGroup><Condition conditionEdge="rising" delay="0.0"
        name="scenario_end"><ByValueCondition><SimulationTimeCondition rule="greaterThan" value="{simulation_time}"/>
        </ByValueCondition></Condition></ConditionGroup>""")

    def change_start_trigger(self):
        start_triggers = self.et.findall('./Storyboard/Story/Act/ManeuverGroup/Maneuver/Event/StartTrigger')
        for start_trigger in start_triggers:
            start_trigger[0] = etree.fromstring("""<ConditionGroup><Condition conditionEdge="none" delay="0"
        name="overtakeManeuverStartCondition"><ByValueCondition><SimulationTimeCondition rule="greaterThan" value="0.0"
        /></ByValueCondition></Condition></ConditionGroup>""")

    def add_priority_to_events(self, priority='parallel'):
        for event in self.root.iter('Event'):
            event.set('priority', priority)

    def change_file_header_description(self):
        file_header = self.et.find('./FileHeader')
        file_header.set('description', self.source.stem)

    def remove_trajectory(self):
        osc_manipulator = Path(glob.glob('tools/osc_manipulator/manipulator.py')[0])
        os.system(f'python {osc_manipulator} '
                  f'--input {self.source} '
                  f'--output {self.target} '
                  f'--ego {self.ego} '
                  )

    def extract_sut_information(self):
        config_extractor = Path(glob.glob('tools/config_extractor/extractor.py')[0])
        path = Path(self.source)
        filename = path.stem
        parent_path = path.parent.parent.absolute()
        output_path = parent_path.joinpath("model_data", f'{filename}.json')
        os.system(f'python {config_extractor} '
                  f'--input {self.source} '
                  f'--output {output_path} '
                  f'--ego {self.ego} '
                  )

    def cleaner(self):
        etree.indent(self.root, '    ')

    def run(self):
        print(f"--- RUNNING PREPROCESSOR for {self.source} ---")
        if self.stop_trigger:
            self.change_stop_trigger()
        if self.start_trigger:
            self.change_start_trigger()
        if self.priority:
            self.add_priority_to_events()
        if self.header_description:
            self.change_file_header_description()
        if self.clean_up:
            self.cleaner()
        self.et.write(self.target)
        if self.extract_scenario_information:
            self.extract_sut_information()
        if self.remove_ego_trajectory:
            self.remove_trajectory()
        print("--- FINISHED PREPROCESSOR ---")



if __name__ == '__main__':
    print('This is a module and not supposed to be directly executed.')
