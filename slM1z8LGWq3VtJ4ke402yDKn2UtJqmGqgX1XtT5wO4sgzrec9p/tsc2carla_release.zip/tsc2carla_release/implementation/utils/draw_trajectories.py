from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import glob


def main():
    for csv in glob.glob('traces/esmini/scenario_*.csv'):
        csv_path = Path(csv)
        trajectory_data_1 = pd.read_csv(csv_path,
                                        usecols=['ego_x', 'ego_y'],
                                        skipinitialspace=True,
                                        dtype=float).to_numpy()
        trajectory_data_2 = pd.read_csv(csv_path,
                                        usecols=['bus_x', 'bus_y'],
                                        skipinitialspace=True,
                                        dtype=float).to_numpy()

        plt.plot(trajectory_data_1[:, 0], trajectory_data_1[:, 1])
        plt.plot(trajectory_data_2[:, 0], trajectory_data_2[:, 1])
        plt.savefig(f'trajectories/{csv_path.stem}.png')
        # plt.clf()


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(e)
