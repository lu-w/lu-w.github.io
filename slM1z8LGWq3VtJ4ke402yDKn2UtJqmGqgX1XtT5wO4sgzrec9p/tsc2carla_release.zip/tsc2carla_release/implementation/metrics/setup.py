from distutils.core import setup
from setuptools import find_packages

setup(
    name="carlametrics",
    author="Matthis Ehrhardt, Lukas Westhofen",
    author_email="lukas.westhofen@dlr.de",
    description="A module for computing and graphing criticality metrics in CARLA",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=["carla", "numpy", "shapely", "pandas", "pyyaml", "matplotlib"]
)
