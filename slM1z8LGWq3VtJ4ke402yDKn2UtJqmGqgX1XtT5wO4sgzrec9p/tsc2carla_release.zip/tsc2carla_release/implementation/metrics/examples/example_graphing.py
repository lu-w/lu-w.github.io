import logging

import carla

from carlametrics.data.log import Log
from carlametrics.data.recording import Recorder
from carlametrics.graphing.graphing import MetricGrapher
from carlametrics.metrics.a_req import AReq
from carlametrics.metrics.dpret import DPrET
from scenario_example import scenario_setup, scenario_run

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s: %(message)s")
logging.getLogger("carlametrics").setLevel(logging.DEBUG)


def show_graphs(log: Log):
    # Allows to graph the given metrics for the given actors w.r.t. to the ego actor
    grapher = MetricGrapher(log, [AReq, DPrET], ["one", "two"], ego_name="three")
    # This replays the record and synchronously prints a live graph
    grapher.live_graph()
    # If you just want to display the graph you can also call
    # grapher.show_graph()


print("=== Example for creating a log during a scenario using the record() feature ===\n")
actors = scenario_setup()
recording = Recorder()
recording.start()
scenario_run(*actors)
recording.stop()
scenario_log = recording.get_log()
show_graphs(scenario_log)

print("\n=== Example for loading a pre-recorded log from file instead of recording the scenario live ===\n")
restored_log = Log(scenario_log.get_filepath())
client = carla.Client("localhost", 2000)
client.set_timeout(20.0)
client.get_world().get_spectator().set_transform(
    carla.Transform(carla.Location(115, 10, 10), carla.Rotation(yaw=120, pitch=-10)))
show_graphs(restored_log)
