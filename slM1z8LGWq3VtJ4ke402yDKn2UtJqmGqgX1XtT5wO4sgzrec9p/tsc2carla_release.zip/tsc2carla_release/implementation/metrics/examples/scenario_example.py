import random

from carlametrics.config.config import global_config
import carla


def scenario_setup():
    client = carla.Client("localhost", 2000)
    client.set_timeout(20.0)
    world = client.get_world()
    settings = world.get_settings()
    settings.fixed_delta_seconds = 1 / global_config.get_config_param('frame rate', default=30)
    settings.synchronous_mode = True
    settings.substepping = False
    world.apply_settings(settings)

    # delete old actors
    world_actors = world.get_actors()
    actor_list = world_actors.filter('vehicle.*')
    client.apply_batch([carla.command.DestroyActor(x) for x in actor_list])

    # spawn the first actor
    blueprint_library = world.get_blueprint_library()
    bp = random.choice(blueprint_library.filter('vehicle.*'))
    bp.set_attribute('role_name', 'one')
    vehicle_one = world.spawn_actor(bp, carla.Transform(carla.Location(105, 70, 2), carla.Rotation(yaw=-90)))

    # spawn second actor
    bp = random.choice(blueprint_library.filter('vehicle.*'))
    bp.set_attribute('role_name', 'two')
    vehicle_two = world.spawn_actor(bp, carla.Transform(carla.Location(70, 29, 2)))

    # spawn third actor
    bp = random.choice(blueprint_library.filter('vehicle.*'))
    bp.set_attribute('role_name', 'three')
    vehicle_three = world.spawn_actor(bp, carla.Transform(carla.Location(105, 29, 2), carla.Rotation(yaw=-90)))

    # set spectator position
    world.get_spectator().set_transform(
        carla.Transform(carla.Location(115, 10, 10), carla.Rotation(yaw=120, pitch=-10)))

    return vehicle_one, vehicle_two, vehicle_three


def scenario_run(*actors: carla.Actor):
    client = carla.Client("localhost", 2000)
    client.set_timeout(20.0)
    world = client.get_world()
    frame = 0
    while frame < 100:
        world.tick()
        frame += 1
        control = carla.VehicleControl()
        control.throttle = 1
        for actor in actors:
            actor.apply_control(control)
