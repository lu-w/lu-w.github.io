import logging

from carlametrics.aggregates.aggregates_1d.max import Maximum
from carlametrics.aggregates.aggregates_1d.min import Minimum
from carlametrics.aggregates.aggregates_2d.minmax import MinMax
from carlametrics.aggregates.aggregation import TimeAndActorAggregation
from carlametrics.data.log import Log
from carlametrics.data.recording import Recorder
from carlametrics.metrics.pret import PrET

from scenario_example import scenario_setup, scenario_run


def compute_and_show_pret(log: Log):
    # Computes the PrET w.r.t. one and two, one and three and shows some (aggregated) results.
    result_metrics_2 = PrET(log, "one", "two").calculate()
    result_metrics_3 = PrET(log, "one", "three").calculate()
    print("PrET for actors one and two:")
    print(result_metrics_2)
    print("\nPrET for actors one and three:")
    print(result_metrics_3)
    print("\nMinimum PrET for actors one and two:")
    print(Minimum().aggregate(result_metrics_2))
    print("\nMaximum PrET for actors one and three:")
    print(Maximum().aggregate(result_metrics_3))
    print("\nMinMax-Aggregated PrET for all actors:")
    print(MinMax().aggregate([result_metrics_2, result_metrics_3]))

    # Example for a custom 2D aggregation function
    class MaxMin(TimeAndActorAggregation):
        _OVER_TIME = Maximum()
        _OVER_ACTORS = Minimum()
    print("\nMaxMin-Aggregated PrET for all actors:")
    print(MaxMin().aggregate([result_metrics_2, result_metrics_3]))


logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(levelname)s: %(message)s")

print("=== Example for creating a log during a scenario using the record() feature ===\n")
actors = scenario_setup()
recording = Recorder()
recording.start()
scenario_run(*actors)
recording.stop()
scenario_log = recording.get_log()
compute_and_show_pret(scenario_log)

print("\n=== Example for loading a pre-recorded log from file instead of recording the scenario live ===\n")
# Note that the CARLA server still needs to be running even when loading from file, as the log parser is on server-side.
restored_log = Log(scenario_log.get_filepath())
compute_and_show_pret(restored_log)
