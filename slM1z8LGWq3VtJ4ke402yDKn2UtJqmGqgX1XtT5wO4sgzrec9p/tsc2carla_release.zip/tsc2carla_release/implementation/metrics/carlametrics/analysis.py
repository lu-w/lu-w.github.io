import pathlib
from typing import List, Tuple, Dict, Type

import numpy as np
import pandas

from carlametrics.aggregates.aggregation import TimeAndActorAggregation
from carlametrics.data.log import Log
from carlametrics.metrics.metric import Metric


class VerdictCriterion:
    def __init__(self, target_value: float, fail_in_negative_direction: True):
        """
        :param target_value:
        :param fail_in_negative_direction:
        """
        self._target_value = target_value
        self._fail_in_negative_direction = fail_in_negative_direction

    def evaluate(self, metric_value: float) -> bool:
        """
        :param metric_value: A computed value for a criticality metric.
        :return: True iff the verdict is 'passed' for the given metric value.
        """
        if self._fail_in_negative_direction:
            return metric_value >= self._target_value
        else:
            return metric_value <= self._target_value


class MetricAnalyzer:
    def __init__(self, logs: List[Log], metrics: List[Type[Metric]], actors: List[Tuple[str, str]],
                 aggregate: Dict[Type[Metric], Type[TimeAndActorAggregation]]):
        """
        Initializes the analyzer for the given list of metrics between the actor pairs on the sequence of log files.
        The aggregate is used for aggregating within a single scenario over time and actors, depending on each metric.
        :param logs: The log files to analyze (one for each recorded scenario)
        :param metrics: The metrics to analyze
        :param actors: The pairs of actors to compute the single metrics for
        :param aggregate: An aggregate function to assemble a single value result for each scenario
        """
        self._logs = logs
        self._metrics = metrics
        self._actors = actors
        self._aggregate = aggregate
        self._values = None

    def batch_evaluation(self) -> pandas.DataFrame:
        """
        Computes a batch evaluation.
        :return: A data frame containing a row for each scenario (log) and a column for each metric. The cells contain
                 the aggregated results for each metric on the scenario, over time and actors, using the aggregate.
        """
        if self._values is None:
            data = []
            for log in self._logs:
                scenario_result = []
                for metric in self._metrics:
                    try:
                        metric_results = []
                        for (a1, a2) in self._actors:
                            metric_func = metric(log, a1, a2)
                            metric_results.append(metric_func.calculate())

                        scenario_result.append(self._aggregate[metric]().aggregate(metric_results))
                    except Exception as e:
                        print(f'Exception during evaluation of {metric.__name__} on '
                              f'{pathlib.Path(log.get_filepath()).stem}: {e}')
                        scenario_result.append(np.NaN)
                data.append([pathlib.Path(log.get_filepath()).stem] + scenario_result)
            columns = ["Scenario"] + [m.__name__ for m in self._metrics]
            result = pandas.DataFrame(data, columns=columns)
            self._values = result
        return self._values.copy()

    def verdict(self, criteria: Dict[Type[Metric], VerdictCriterion]) -> Tuple[bool, pandas.DataFrame]:
        """
        Computes a verdict based on the batch evaluation
        :param criteria: Pass/fail criterion for each metric.
        :return: A tuple with the following information:
                 - True iff. the verdicts for all scenarios are positive, false otherwise.
                 - A data frame containing a row for each scenario (log) and a column for each metric. The cells contain
                   True/False, depending on the verdict of the metric in the scenario. An additional row 'Overall'
                   contains True iff. all single metric verdicts for the scenarios are True.
        """
        assert set(criteria.keys()) == set(self._metrics)
        data = self.batch_evaluation()
        for metric in self._metrics:
            data[metric.__name__] = data[metric.__name__].apply(criteria[metric].evaluate)
        data["Overall"] = data.apply(lambda row: row.all(), axis=1)
        return data["Overall"].all(), data
