from typing import List

import numpy
import numpy as np

from carlametrics.config.config import global_config
from carlametrics.data.log import Log
from carlametrics.metrics.dpret import DPrET
from carlametrics.metrics.btn import BTN
from carlametrics.metrics.metric import Metric


class PCI(Metric):
    """
    Implements the Predictive Conflict Index.
    """
    def __init__(self, log: Log, ego_name: str, other_name: str):
        """
        Computes the PCI.

        Note
        ----
        The calculation of this metric needs a probability metric. Default probability metric is DPrET.
        Changeable with 'set_probability_metric'.

        :param log:        log file on whose data to compute the metric on
        :param ego_name:   the name of the ego actor in the log file
        :param other_name: the name of the other actor in the log file
        """
        super().__init__(log, ego_name, other_name)
        self.alpha = 1
        self.beta = 1
        probability_selection = global_config.get_config_param('params pci', 'probability metric', default='BTN')
        if probability_selection == 'BTN':
            self.probability_metric = BTN(log, ego_name, other_name)
        elif probability_selection == 'DPrET':
            self.probability_metric = DPrET(log, ego_name, other_name)
        self.max_result_value = global_config.get_config_param('params pci', 'upper bound', default=1)

    def set_probability_metric(self, probability_metric: Metric):
        """
        Changes the used probability metric.
        :param probability_metric: class of the new probability metric
        """
        self.probability_metric = probability_metric

    def __str__(self):
        return "PCI_with_" + self.probability_metric.__str__()

    def set_alpha(self, new_alpha: int or float):
        self.alpha = new_alpha

    def set_beta(self, new_beta: int or float):
        self.beta = new_beta

    def calculate(self) -> List[float or int]:
        """
        Computes the PCI as defined by Allen.
        :returns: The PCI value (in s), possibly infinity.
        """
        ego_mass = self.ego.get_mass()
        act_mass = self.other_actor.get_mass()
        mass_both = ego_mass + act_mass

        ego_velocities = self.ego.get_velocity_list()
        act_velocities = self.other_actor.get_velocity_list()

        ego_velocities_np = np.array([[velocity.x, velocity.y] for velocity in ego_velocities])
        act_velocities_np = np.array([[velocity.x, velocity.y] for velocity in act_velocities])
        ego_velocities_np_with_mass = ego_mass * ego_velocities_np
        act_velocities_np_with_mass = act_mass * act_velocities_np

        collision_velocity = 1 / mass_both * (ego_velocities_np_with_mass + act_velocities_np_with_mass)

        ego_kinetic_energy = ego_mass * np.sum(np.square(ego_velocities_np), axis=1)
        act_kinetic_energy = act_mass * np.sum(np.square(act_velocities_np), axis=1)
        energy_after_collision = mass_both * np.sum(np.square(collision_velocity), axis=1)
        predicted_kinetic_energy = numpy.multiply(0.5,
                                                  (ego_kinetic_energy + act_kinetic_energy - energy_after_collision))
        # get the results of the probability metrics and remove infinity
        probability_metric_results = self.probability_metric.calculate()
        probability_metric_results = np.array(probability_metric_results)

        predicted_kinetic_energy = self.alpha * predicted_kinetic_energy

        exponent = self.beta * probability_metric_results

        if isinstance(self.probability_metric, BTN):
            pci = predicted_kinetic_energy * probability_metric_results
        else:
            pci = np.divide(predicted_kinetic_energy, np.exp(exponent))

        pci[np.isinf(pci)] = 0
        pci[np.isnan(pci)] = 0
        return list(pci)
