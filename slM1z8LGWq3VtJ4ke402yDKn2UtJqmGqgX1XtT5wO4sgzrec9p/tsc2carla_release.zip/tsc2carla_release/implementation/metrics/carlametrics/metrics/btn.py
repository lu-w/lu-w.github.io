from typing import List

from carlametrics.data.log import Log
from carlametrics.metrics.metric import Metric
from carlametrics.metrics.a_req import AReq


class BTN(Metric):
    """
    Implements the Brake Threat Number.
    """
    def __init__(self, log: Log, ego_name: str, other_name: str):
        """
        :param log:        log file on whose data to compute the metric on
        :param ego_name:   the name of the ego actor in the log file
        :param other_name: the name of the other actor in the log file
        """
        self.areq = AReq(log, ego_name, other_name)
        super().__init__(log, ego_name, other_name)

    def calculate(self) -> List[float or int]:
        """
        Calculate the BTN of a scene between two actors. Tthe definition of the BTN metric is given by
        :math:`a_{req} / a_{max}` where :math:`a_{max}` stands for the maximal deceleration available to the ego.

        :return: list of calculated values where the index in the list is equivalent to the frame in the scenario
        """
        required_deceleration = self.areq.calculate()
        maximal_deceleration = self.ego.get_maximal_deceleration()
        return [min(1, required_deceleration[i] / maximal_deceleration) for i in range(self.ego.get_max_frame())]
