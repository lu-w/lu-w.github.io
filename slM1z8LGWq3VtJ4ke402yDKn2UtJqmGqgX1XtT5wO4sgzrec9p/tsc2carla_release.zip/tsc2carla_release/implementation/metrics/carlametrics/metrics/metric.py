import math
from typing import Callable, List
import carla

from carlametrics.config.config import global_config
from carlametrics.data.recording import Log


class Metric:

    def __init__(self, log: Log, ego_name: str, other_name: str):
        """
        Metrics super class. Allows to compute a criticality metric based on some log that contains the two
        actors with the roles 'name' containing ego_name resp. other_name.
        :param log:        log file on whose data to compute the metric on
        :param ego_name:   the name of the ego actor in the log file
        :param other_name: the name of the other actor in the log file
        """
        self.ego, self.other_actor = log.extract_actors(ego_name, other_name)

    def calculate(self) -> List[float or int]:
        """
        Calculates the metric for objects and self.ego and self.other_actor. Implemented by concrete metrics.
        """
        pass

    def __str__(self) -> str:
        """
        :return: Name of the metric
        """
        return self.__class__.__name__

    def get_metric_parameters(self) -> dict:
        """
        Returns a dictionary with the following values:
        'name':                 name of the metric
        'lower bound':          the lower bound if there is a fixed one
        'lower bound printing': the lower bound for a graph so that there are most of the values smaller.
        'upper bound':          the upper bound if there is a fixed one
        'upper bound printing': the upper bound for a graph so that there are most of the values smaller.
        """
        if global_config.has_config_param("params " + str(self.__class__.__name__)):
            params = global_config.get_config_param("params " + str(self.__class__.__name__))
        else:
            params = {"lower bound": 0, "lower bound printing": 0, "upper bound": 100, "upper bound printing": 100}
        if "name" not in params:
            params["name"] = str(self)
        return params

    def debug_metric(self, world: carla.World) -> Callable:
        """
        Method to get a function which can be called to draw certain parts of the metric calculation into the carla map

        Usage
        -----
            - to draw something you need to set the boolean value in the default_config.yml to True
            - this method returns a callable which can be called while the replay runs
            - the callable takes a frame number as input and returns nothing

        :param world: carla.World in which the drawing should take place
        """
        # initialize ego params
        ego_locations = self.ego.get_location_list()
        ego_velocities = self.ego.get_velocity_list()
        ego_transforms = self.ego.get_transform_list()

        # initialize actor params
        name_actor = self.other_actor.get_name_actor()
        act_locations = self.other_actor.get_location_list()
        act_velocities = self.other_actor.get_velocity_list()
        act_transforms = self.other_actor.get_transform_list()

        # get values from config file
        frame_rate = global_config.get_config_param('frame rate', default=60)
        ego_colors = global_config.get_config_param('actor carla colors', 'ego', default=[0, 0, 160, 200])
        act_colors = global_config.get_config_param('actor carla colors', name_actor, default=[0, 150, 200, 100])
        ego_color = carla.Color(r=ego_colors[0], g=ego_colors[1], b=ego_colors[2], a=ego_colors[3])
        act_color = carla.Color(r=act_colors[0], g=act_colors[1], b=act_colors[2], a=act_colors[3])

        forward_vector, left_lim_start, right_lim_start = self.ego.get_predicted_path_under_constant_velocity()
        for i in range(len(forward_vector)):
            forward_vector[i].z = 0
            left_lim_start[i].z = 0.5
            right_lim_start[i].z = 0.5

        projections = self.ego.compute_projection_of(self.other_actor)
        intersection_points = [self.ego.get_intersection_point_of_paths_for_frame(self.other_actor, i) for i in
                               range(self.ego.get_max_frame())]

        def draw_arrow_from_actor(frame, point):
            point.z = 1
            world.debug.draw_line(act_locations[frame] + carla.Location(z=1), point, color=act_color, life_time=0.1,
                                  thickness=0.2)

        def draw_arrow_from_ego(frame, point):
            point.z = 1
            world.debug.draw_arrow(ego_locations[frame] + carla.Location(z=1), point, color=ego_color, life_time=0.1,
                                   thickness=0.2)

        def debug_function(frame):
            """
            function which prints/draws the predefined values in the carla world
            the values are set in the config file
            """
            ego_location = ego_locations[frame]
            act_location = act_locations[frame]
            intersections_trajectories = self.ego.time_to_intersection_point_of_trajectories(self.other_actor)

            if global_config.get_config_param('metric debugging options', 'draw velocity arrows', default=False):
                world.debug.draw_arrow(ego_location, ego_location + ego_velocities[frame],
                                       color=ego_color, life_time=0.1, thickness=0.15)
                draw_arrow_from_actor(frame, act_location + act_velocities[frame])

            if global_config.get_config_param('metric debugging options', 'print distance to ego', default=False):
                world.debug.draw_string(act_location + carla.Location(z=6),
                                        'Distance to Ego: {}'.format(act_location.distance(ego_location)),
                                        color=act_color)
            if global_config.get_config_param('metric debugging options', 'print speed', default=False):
                world.debug.draw_string(act_location + carla.Location(z=4),
                                        'Speed: {:2.3f}'.format(self.other_actor.get_speed_list()[frame]),
                                        color=act_color)
                world.debug.draw_string(ego_location + carla.Location(z=4),
                                        'Speed: {:2.3f}'.format(self.ego.get_speed_list()[frame]),
                                        color=ego_color)

            if global_config.get_config_param('metric debugging options', 'print mass', default=False):
                world.debug.draw_string(act_location + carla.Location(z=2),
                                        'Mass: {:4.1f}'.format(self.other_actor.mass()),
                                        color=act_color)
                world.debug.draw_string(ego_location + carla.Location(z=2),
                                        'Mass: {:4.1f}'.format(self.ego.mass()),
                                        color=ego_color)

            if global_config.get_config_param('metric debugging options', 'draw area before ego', default=False):
                world.debug.draw_arrow(left_lim_start[frame], left_lim_start[frame] + forward_vector[frame],
                                       color=ego_color, life_time=0.1, thickness=0.1)
                world.debug.draw_arrow(right_lim_start[frame], right_lim_start[frame] + forward_vector[frame],
                                       color=ego_color, life_time=0.1, thickness=0.1)
                world.debug.draw_line(left_lim_start[frame] + carla.Location(z=1),
                                      right_lim_start[frame] + carla.Location(z=1),
                                      thickness=0.2, life_time=0.1,
                                      color=ego_color)

            if global_config.get_config_param('metric debugging options',
                                              'draw intersection of trajectories longitudinal lines', default=False):
                # check there is a projection
                if projections[frame] is not None:
                    projection = carla.Location(x=projections[frame][0], y=projections[frame][1], z=1)
                    draw_arrow_from_actor(frame, projection)

            if global_config.get_config_param('metric debugging options',
                                              'draw intersection of path lines', default=False):
                # check if there is intersection
                if intersection_points[frame] != math.inf:
                    draw_arrow_from_actor(frame, intersection_points[frame])
                    draw_arrow_from_ego(frame, intersection_points[frame])

            if global_config.get_config_param('metric debugging options',
                                              'draw intersection of path point', default=False):

                if intersection_points[frame] != math.inf:
                    intersection_points[frame].z = 2
                    world.debug.draw_point(intersection_points[frame], color=act_color,
                                           size=0.25, life_time=0.1)
                    world.debug.draw_string(intersection_points[frame] + carla.Location(z=2),
                                            'ego and {} intersection of path at {} seconds'.format(
                                                self.other_actor.get_name_actor(),
                                                frame / 60), color=act_color)

            if global_config.get_config_param('metric debugging options', 'draw intersection of trajectories point',
                                              default=False):
                time_to_intersection = intersections_trajectories[frame]

                if time_to_intersection != math.inf:  # check if there is an intersection
                    location = time_to_intersection * ego_velocities[frame] + ego_location + carla.Location(z=2)
                    world.debug.draw_point(location, color=act_color, size=0.25, life_time=0.1)

            if global_config.get_config_param('metric debugging options', 'draw intersection of trajectories lines',
                                              default=False):
                time_to_intersection = intersections_trajectories[frame]

                if time_to_intersection != math.inf:  # check if there is an intersection
                    draw_arrow_from_ego(frame, ego_location + ego_velocities[frame] * time_to_intersection)
                    draw_arrow_from_actor(frame, act_location + act_velocities[frame] * time_to_intersection)

            if global_config.get_config_param('metric debugging options', 'draw bounding boxes actors', default=False):
                used_bbox_actor = self.other_actor.get_bounding_box_as_matrix(transform=act_transforms[frame])

                for j in range(4):
                    location = carla.Location(x=used_bbox_actor[j][0], y=used_bbox_actor[j][1], z=0)
                    world.debug.draw_line(location, location + carla.Location(z=4),
                                          color=act_color, thickness=0.05, life_time=2 / frame_rate)

            if (global_config.get_config_param('metric debugging options', 'draw bounding boxes ego', default=False) and
                    (name_actor == 'bic' or name_actor == 'bic1')):
                used_bbox_actor_ego = self.ego.get_bounding_box_as_matrix(transform=ego_transforms[frame])

                for j in range(4):
                    location = carla.Location(x=used_bbox_actor_ego[j][0], y=used_bbox_actor_ego[j][1], z=0)
                    world.debug.draw_line(location, location + carla.Location(z=4),
                                          color=act_color, thickness=0.05, life_time=2 / frame_rate)

        return debug_function

    def _expand(self, value: float or int) -> List[float or int]:
        """
        :returns: The value expanded into a list as long as the lifetime of the ego.
        """
        return [value for _ in self.ego.get_location_list()]
