from typing import List

import numpy as np

from carlametrics.metrics.metric import Metric


class AReq(Metric):
    """
    Implements the Required Longitudinal Acceleration.
    """
    def calculate(self) -> List[float or int]:
        """
        Calculate the required longitudinal acceleration of the ego to stop in before the intersection trajectories
        with the other actor (in m/s², as a negative value).

        Implementation
        --------------
            - this method differentiates between a following scenario and intersection situation
            - in a following scenario the return is the time the driver would need to stop before the point where the
              actor is right now
            - in an intersection situation this method uses the intersection of trajectories for calculation

        :returns: list of results for the given ego/actor parameters
        """
        # get if both actors are following each other in a given frame
        before_and_same_direction = self.ego.compute_projection_of(self.other_actor)

        # initialize actor params
        ego_locations = self.ego.get_location_list()
        act_locations = self.other_actor.get_location_list()
        ego_speed = self.ego.get_speed_list()
        act_speed = self.other_actor.get_speed_list()

        # calculate the ego distances
        intersection_times_list = self.ego.time_to_intersection_point_of_trajectories(self.other_actor)
        time_ego = np.array(intersection_times_list)
        with np.errstate(invalid='ignore'):
            ego_distances = np.where(time_ego != np.inf, np.multiply(time_ego, ego_speed), np.inf)

        # calculate areq for the intersection values
        ego_distances[ego_distances == 0] = 0.001
        areq = -((ego_speed ** 2) / (2 * ego_distances))

        # calculate longitudinal areq
        location_differences = np.array([ego_locations[i].distance(act_locations[i])
                                         for i in range(len(act_locations))])
        speed_difference = ego_speed - act_speed
        speed_difference = speed_difference ** 2
        denominator_array = (2 * location_differences)
        areq_long = -(speed_difference / denominator_array)

        # if they are following each other the areq_long (longitudinal) is returned if not the value before and same
        # direction is None and areq is returned
        return list(np.where(before_and_same_direction is not None, areq, areq_long))

    def __str__(self):
        return 'a_req,long'
