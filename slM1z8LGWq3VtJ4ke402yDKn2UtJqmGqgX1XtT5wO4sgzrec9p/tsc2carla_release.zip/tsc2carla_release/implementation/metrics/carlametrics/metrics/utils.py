import logging
import math
from typing import Tuple

import carla
import numpy as np

from shapely.geometry import Polygon

from carlametrics.config.config import global_config

logger = logging.getLogger(__name__)


def get_bounding_box_function_over_transforms(bounding_box):
    extent = bounding_box.extent
    corners = [-extent.x, -extent.y, extent.x, -extent.y, extent.x, extent.y, -extent.x, extent.y]

    # TODO: improve this method
    def min_max_cords_for_transform(transform: carla.Transform):
        # Convert the corners to world-space
        min_X = math.inf
        min_Y = math.inf
        max_X = - math.inf
        max_Y = - math.inf
        for i in range(0, len(corners), 2):
            local_corner = carla.Location(x=corners[i], y=corners[i + 1])
            world_corner = transform.transform(local_corner)
            min_X = world_corner.x if world_corner.x < min_X else min_X
            min_Y = world_corner.y if world_corner.y < min_Y else min_Y
            max_X = world_corner.x if world_corner.x > max_X else max_X
            max_Y = world_corner.y if world_corner.y > max_Y else max_Y

        return Polygon([(min_X, min_Y), (min_X, max_Y), (max_X, min_Y), (max_X, max_Y)])

    return min_max_cords_for_transform


def orthogonal_projection(point: carla.Location,
                          location_on_line: carla.Location,
                          direction_of_line: carla.Vector3D, project_only_on_vector: bool = False) -> np.array:
    """
    Method to get an orthogonal projection from one point to a vector in 2 Dimensions

    :param point:                   location from which you want to project orthogonal
    :param location_on_line:        point on the line on which should be projected
    :param direction_of_line:       direction of the line on which should be projected
    :param project_only_on_vector:  if true there will be no projection before or behind the vector

    :return:                        numpy vector which is orthogonal to the line which is defined by last 2 parameters
    """
    # initialize
    p = np.array([point.x, point.y])
    v = np.array([direction_of_line.x, direction_of_line.y])
    location_on_line = np.array([location_on_line.x, location_on_line.y])

    # Gram Schmidt
    p_minus_origin_v = p - location_on_line
    t = np.dot(p_minus_origin_v, v) / np.dot(v, v)

    if not 1 > t > 0 and project_only_on_vector:
        return None

    projection = location_on_line + t * v
    return projection


def point_between(carla_vector_one: carla.Vector3D, carla_vector_two: carla.Vector3D,
                  point: np.array or list) -> bool:
    """
    Method to check if a point is in between 2 Vectors

    :param carla_vector_one:    vector left
    :param carla_vector_two:    second carla vector
    :param point:       point which should be checked as a np array or list ATTENTION: this method uses np arrays
                        for calculation but the first 2 inputs are carla vectors this is because this method has
                        limited use cases and in those that exists (at the moment) this convention make more sens

    :return:            Boolean which is true if the point is in between and false else
    """
    # initialization
    vector_one = np.array([carla_vector_one.x, carla_vector_one.y])
    vector_two = np.array([carla_vector_two.x, carla_vector_two.y])
    point = np.array(point)

    # returns a vector which has the angel of between the 2 vectors
    segment_vector = vector_two - vector_one
    point_vector = point - vector_one
    dot_product = point_vector.dot(segment_vector)  # calculate the angle between the vectors

    if dot_product < 0:  # return false if the point is not in the direction between the vectors
        return False

    segment_length_squared = np.sum(segment_vector ** 2)  # calculate the length of the vector

    # return false if the point is further away than the length of the vectors
    return not dot_product > segment_length_squared


def interval_distance(min1: float or int, max1: float or int,
                      min2: float or int, max2: float or int) -> float or int:
    """
    Returns the distance between 2 intervals

    Return
    ------
    Minimal distance between 2 given intervals

    :return: if (intervals overlab) 0; else: distance between

    Use Case
    --------
    get distance between bounding boxes
    """
    if min1 > max2:
        return min1 - max2
    elif min2 > max1:
        return min2 - max1
    else:
        return 0


def get_intersection_point_of_paths(ego_location: carla.Location, ego_velocity: carla.Vector3D,
                                    actor_location: carla.Location, actor_velocity: carla.Vector3D,
                                    allow_locations_behind: bool = False,
                                    epsilon_speed: float = 0) -> carla.Location:
    """
    Calculates the intersection of paths of 2 vectors
    if both drive parallel the returned location is carla.Location(math.inf, math.inf, math.inf)

    :param ego_location:            the Location of the ego from carla
    :param ego_velocity:            the Velocity of the ego from carla
    :param actor_location:          the Location of the actor from carla
    :param actor_velocity:          the Velocity of the actor from carla

    :param allow_locations_behind:  if False the return for an intersection point where at least one have to drive
                                    backwards is also carla.Location(math.inf, math.inf, math.inf)
    :param epsilon_speed:           lower bound for the usage af velocities.
                                    any speed lower than this is assumed as standing still.
                                    if eps is lower or equal to 0 it takes the default from config (=0.1)

    :return:        carla Location where the paths of the actors intersect assuming constant velocity
    """
    if epsilon_speed <= 0:
        epsilon_speed = global_config.get_config_param('epsilon speed default', default=0.1)
    if ego_velocity.length() <= epsilon_speed or actor_velocity.length() <= epsilon_speed:
        return carla.Location(x=math.inf, y=math.inf, z=math.inf)

    ego_velocity = ego_velocity.make_unit_vector()
    actor_velocity = actor_velocity.make_unit_vector()

    # initialize values for ego
    ego_location = np.array([ego_location.x, ego_location.y])
    ego_velocity = np.array([ego_velocity.x, ego_velocity.y])

    # initialize values for actor
    act_location = np.array([actor_location.x, actor_location.y])
    act_velocity = np.array([actor_velocity.x, actor_velocity.y])

    # difference of the location vectors
    location_difference = ego_location - act_location

    # create a matrix to solve the linear equation later on
    vectors = np.array([
        [- ego_velocity[0], act_velocity[0]],
        [- ego_velocity[1], act_velocity[1]]
    ])

    # if det 0 both are linear dependent
    if np.linalg.det(vectors) == 0:
        return carla.Location(x=math.inf, y=math.inf, z=math.inf)

    # numpy function for solving linear equations with the form Ax = b
    distances = np.linalg.solve(a=vectors, b=location_difference)
    # get distances for ego and actor
    ego_distance = distances[0]
    act_distance = distances[1]

    # if locations behind the actors are not allowed return infinity if the location is behind
    if not allow_locations_behind and act_distance < 0 or ego_distance < 0:  # if there is no intersection
        return carla.Location(x=math.inf, y=math.inf, z=math.inf)

    # calculate intersection point and return it as a carla.Location
    ego_intersection = ego_velocity * ego_distance + ego_location
    ego_intersection = carla.Location(x=ego_intersection[0], y=ego_intersection[1], z=1)

    return ego_intersection


def get_time_until_intersection(path: [Polygon, ...], intersection_area: Polygon) -> Tuple[int, int]:
    """
    Method to get the first frame in which the actor enters and exits a given intersection area.
    :param path: list of rectangles given by a carla location and the bounding box of the actor
    :param intersection_area: Shapely Polygone which represents the area where both paths overlab
    :return:    1. Time entered
                2. Time exited

    If intersection area is empty this Method returns -1, -1
    """
    if intersection_area.is_empty or None:
        return -1, -1

    enter_time = -1
    exit_time = -1

    for i, rect in enumerate(path):
        if rect is None:
            continue
        try:
            if rect.intersects(intersection_area):
                enter_time = i
            if not rect.intersects(intersection_area) and enter_time != -1:
                exit_time = i
                break
        except Exception as e:
            logger.warning(e)
            continue

    return enter_time, exit_time


