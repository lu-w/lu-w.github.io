from typing import List

import numpy as np

from carlametrics.data.log import Log
from carlametrics.metrics.metric import Metric
from carlametrics.metrics.pret import PrET


class DPrET(Metric):
    """
    Implements the Duration-dependent Predictive Encroachment Time.
    """
    def __init__(self, log: Log, ego_name: str, other_name: str):
        """
        Computes the PET as defined by Allen.
        :param log:        log file on whose data to compute the metric on
        :param ego_name:   the name of the ego actor in the log file
        :param other_name: the name of the other actor in the log file
        """
        self.pret_instance = PrET(log, ego_name, other_name)
        super().__init__(log, ego_name, other_name)

    def calculate(self) -> List[float or int]:
        """
        Method to calculate the DPrET.

        Calculation
        -----------
        :list:
        if : :math:`|t_1-t_2|\geq 1 \lor \min(t_1,t_2) \geq 1`
            -> :math:`DPrET=\max\left(1s,|t_1-t_2|)\cdot \max(1s,\min(t_1,t_2))` \n
        if : :math:`|t_1-t_2|<1 \land \min(t_1,t_2)<1`
            -> :math:`DPrET=\max\left(|t_1-t_2|, \min(t_1,t_2))` \n
        if : path not exist
            -> :math:`DPrET=\infty`

        :returns: The PET values for each frame (in s), possibly infinity.
        """
        ego_time, act_time = self.ego.time_to_intersection_point_of_paths(self.other_actor)

        # before we used the more basic implementation of the PrET abs(time_ego - time_act)
        time_difference = np.array(self.pret_instance.calculate())
        time_minimum = np.minimum(ego_time, act_time)

        # initialize the condition for the np.where function
        condition = (time_difference < 1) & (time_minimum < 1)

        values_when_true = np.maximum(time_difference, time_minimum)
        values_when_false = np.maximum(1, time_difference) * np.maximum(1, time_minimum)

        result = np.where(condition, values_when_true, values_when_false)

        return list(result)
