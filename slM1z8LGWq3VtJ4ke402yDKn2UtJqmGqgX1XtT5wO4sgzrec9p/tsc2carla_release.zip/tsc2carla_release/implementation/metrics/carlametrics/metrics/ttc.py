from typing import List

from carlametrics.metrics.metric import Metric


class TTC(Metric):
    """
    Implements the Time To Collision.
    """
    def calculate(self) -> List[float or int]:
        """
        Calculates TTC using the planned trajectories of the agents, i.e., the time until 2 vehicles would collide if
        they drive straight from their current point with constant velocity.
        forward. Returns infinity if they would not collide.
        :return: the TTC of A to B, infinity if no collision will happen according to the prediction model.
        """
        return self.ego.time_to_intersection_point_of_trajectories(self.other_actor)
