from typing import List

import numpy as np

from carlametrics.metrics.metric import Metric


class SPrET(Metric):
    """
    Implements the Predictive Encroachment Time.
    """
    def calculate(self) -> List[float or int]:
        """
        Computes the PrET, i.e. the time at which 2 vehicles will miss each other if nothing changes.
        Definition: :math:`PrET = ||t_{actor} - t_{ego}||`
        :returns: The PrET value (in s, possibly infinity) as a list
        """
        # Initialization
        ego_time, act_time = self.ego.time_to_intersection_point_of_paths(self.other_actor)
        vector_projection = self.ego.compute_projection_of(self.other_actor)

        with np.errstate(invalid='ignore'):  # silences on inf subtraction (which is not bad - shall just be inf)
            absolut_time_difference = np.abs(np.sqrt(ego_time) - np.sqrt(act_time))
        absolut_time_difference[np.isnan(absolut_time_difference)] = np.inf
        result = [absolut_time_difference[i]
                  if vector_projection[i] is None  # if vector projection not None we are in a following scenario
                  else np.sqrt(np.sqrt(vector_projection[i][0]**2 + vector_projection[i][1]**2) /
                               self.ego.get_speed_list()[i])
                  for i in range(len(absolut_time_difference))]
        return result
