import math
import logging
from typing import List

from shapely.ops import unary_union

from carlametrics.metrics.metric import Metric
from carlametrics.metrics import utils

logger = logging.getLogger(__name__)


class PET(Metric):
    """
    Implements the Post Encroachment Time.
    """
    def calculate(self) -> List[float or int]:
        """
        Computes the PET as defined by Allen.
        :returns: The PET value (in s), possibly infinity.
        """
        # calculate the critical area or the intersection of both bounding box paths
        ego_path = self.ego.get_path_as_polygon()
        act_path = self.other_actor.get_path_as_polygon()
        ego_path_combined = unary_union(ego_path)
        act_path_combined = unary_union(act_path)
        intersection_area = act_path_combined.intersection(ego_path_combined)

        # do not need to go further if there is no intersection area the actors will never collide
        result = float(math.inf)
        if intersection_area is not None:
            # getting enter and exit times
            enter_frame_ego, exit_frame_ego = utils.get_time_until_intersection(ego_path, intersection_area)
            enter_frame_act, exit_frame_act = utils.get_time_until_intersection(act_path, intersection_area)

            # Saves trajectories for each step in time (required, otherwise no historical trajectory data is stored)
            if exit_frame_ego < exit_frame_act:
                t_enter = enter_frame_ego
                t_exit = exit_frame_act
            else:
                t_enter = enter_frame_act
                t_exit = exit_frame_ego

            result = (t_enter - t_exit) * self.ego.get_timedelta()
        return self._expand(result)
