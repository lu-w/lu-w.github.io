import os
import logging
import yaml

logger = logging.getLogger(__name__)


class Config:
    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'default_config.yml')
        try:
            with open(config_path) as file:
                self.config = yaml.safe_load(file)
        except FileNotFoundError:
            logger.warning("Configuration file not found at " + str(config_path))
            self.config = dict()

    def has_config_param(self, *params):
        cur_dict = self.config
        for param in params:
            if param in cur_dict:
                cur_dict = cur_dict[param]
            else:
                return False
        return True

    def get_config_param(self, *params, default=None):
        cur_dict = self.config
        for param in params:
            if param in cur_dict:
                cur_dict = cur_dict[param]
                if not isinstance(cur_dict, dict):
                    return cur_dict
            else:
                return default
        return default


global_config = Config()


def update_config(config_path: str = None):
    global global_config
    global_config = Config(config_path)
