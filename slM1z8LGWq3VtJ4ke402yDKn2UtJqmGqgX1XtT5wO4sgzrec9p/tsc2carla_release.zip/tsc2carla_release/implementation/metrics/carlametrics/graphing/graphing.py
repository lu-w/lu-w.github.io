import time
import logging
from typing import List, Type, Dict
import tkinter as tk

import carla
import numpy as np
from matplotlib import pyplot as plt

from carlametrics.config.config import global_config
from carlametrics.data.log import Log
from carlametrics.metrics.metric import Metric

logger = logging.getLogger(__name__)
logging.getLogger("matplotlib.font_manager").setLevel(logging.WARNING)


class MetricGrapher:
    """
    Implements functionality for graphing the results of a criticality metric based on a log file.
    Provides either a static display of all graphs (using show_graph()) or a live plot synchronized to a replay (using
    live_graph()).
    """
    def __init__(self, log: Log, metrics: List[Type[Metric]], actor_names: List[str], ego_name: str = "ego",
                 client: carla.Client = None, address: str = "localhost", port: int = 2000):
        """
        Initializes the grapher for the given log, metrics, and actors. These can not be changed later.
        :param metrics:     a list of metric classes
        :param actor_names: list with of all actor names except ego
        :param ego_name:    name of the actor to which all other actors shall be evaluated against
        :param log:         log of scenario on which the metrics shall be graphed
        :param client:      if there is already a client, the grapher will use this one
        :param address:     otherwise, the grapher connects to the server at the given address
        :param port:        and the given port
        """
        # setup CARLA connection
        if client is not None:
            self._client = client
        else:
            self._client = carla.Client(address, port)
            self._client.set_timeout(20)
        self._world = self._client.get_world()
        self._framerate = log.get_framerate()

        # set log and actors
        self._log = log
        self._actors = self._log.extract_actors(*(actor_names + [ego_name]))
        self._ego = next(actor for actor in self._actors if actor.get_name_actor() == ego_name)
        self._others = [actor for actor in self._actors if actor.get_name_actor() != ego_name]
        self._max_frames = min([actor.get_despawn_frame() for actor in self._actors])
        if self._ego is None:
            raise ValueError("No actor named " + str(ego_name) + " present in log")
        elif len(self._others) == 0:
            raise ValueError("No other actors to compute metrics against present in log")
        elif len(metrics) == 0:
            raise ValueError("No metrics given")
        elif self._max_frames <= 0:
            raise ValueError("No scenario data given")

        # initialize the colors used in the chart
        self._colors = dict()
        self._carla_colors = dict()
        for actor in self._actors:
            self._colors[actor] = global_config.get_config_param("actor hex colors", actor.get_name_actor(),
                                                                 default="#0000A0")
            col = global_config.get_config_param("actor carla colors", actor.get_name_actor(), default=[0, 0, 160, 200])
            self._carla_colors[actor] = carla.Color(a=col[3], b=col[2], g=col[1], r=col[0])

        self._replay_speed = 1      # speed of replay
        self._lower_bound = dict()  # maps from actors and metrics to their lower bound in the plot
        self._upper_bound = dict()  # maps from actors and metrics to their upper bound in the plot
        self._backgrounds = dict()  # maps from actors and metrics to their background for the drawing of the graph
        self._time_dots = dict()    # maps from actors and metrics to their dots which represent the time in the graph
        self._ax = dict()           # maps from actors and metrics to their axes of the plot
        self._fig = dict()          # maps from actors and metrics to their figures of the plot
        self._results_metrics_for_actors = dict()  # maps from actor to map of metric objects to their results
        self._compute_metrics_results_from_logfile(metrics)

    def _compute_metrics_results_from_logfile(self, metrics: List[Type[Metric]]):
        """
        Sets the metric results lists as well as the actor locations globally within the grapher
        """
        min_length = float("inf")
        # get locations to display values if the user wants it.
        for actor in self._get_plot_actors():
            self._results_metrics_for_actors[actor] = dict()
            for metric in metrics:
                cm = metric(self._log, self._ego.get_name_actor(), actor.get_name_actor())
                res = cm.calculate()
                self._results_metrics_for_actors[actor][cm] = res
                min_length = min(min_length, len(res))
        # trim: if one result list is shorter than the rest an error would occur
        for actor in self._results_metrics_for_actors:
            for metric in self._results_metrics_for_actors[actor]:
                self._results_metrics_for_actors[actor][metric] = np.array(
                    self._results_metrics_for_actors[actor][metric][:min_length])

    def show_graph(self):
        """
        Draws only the metric graph without any interactive replay of the logged scenario.
        """
        self._display_metrics_plots()
        self._plot_figure()
        plt.show()

    def live_graph(self, display_ui=True, debug=False):
        """
        Plots a graph alongside replaying the given log for this grapher. This method has its own game loop and replays
        the scenario from the log itself. Note that this feature works only for logs over a fixed framerate.
        :param display_ui: Whether the UI for adapting the replay speed shall be shown.
        :param debug: Whether debug information shall be printed in CARLA.
        """
        if self._framerate is None:
            raise ValueError("Live graphing feature can only operate on fixed framerate recordings")

        self._display_metrics_plots()
        self._plot_figure()
        self._create_time_dots_in_plot()

        root = None
        if display_ui:
            root = self._create_ui()

        # main loop for replay
        logger.info("Starting live plotting for " + str(self._log.get_filepath()))
        self._log.replay()
        delta_seconds = 1 / self._framerate
        carla_frame = None
        frame = 0
        while frame < self._max_frames:
            if root is not None:
                root.update_idletasks()
                root.update()

            if self._replay_speed != 0:  # display only chart
                new_carla_frame = self._world.tick()
                self._plotter(frame, debug)
                frame += new_carla_frame - carla_frame if carla_frame is not None else 1
                carla_frame = new_carla_frame
                if self._replay_speed != 0:
                    time.sleep(delta_seconds / self._replay_speed)
            else:
                time.sleep(delta_seconds)

        # close ui
        if root is not None:
            root.destroy()
        plt.close("all")
        logger.info("Live plotting for " + str(self._log.get_filepath()) + " ended")

    def _get_plot_actors(self):
        return self._others

    def _get_plot_metrics(self, actor):
        return self._results_metrics_for_actors[actor]

    def _display_metrics_plots(self):
        """
        Method to plot the graphs of all metrics.
        """
        for actor in self._get_plot_actors():
            self._ax[actor] = dict()
            self._fig[actor] = dict()
            for metric in self._get_plot_metrics(actor):
                logger.debug("Plotting graphs for actor " + str(actor) + " and metric " + str(metric))
                parameters = metric.get_metric_parameters()
                # set bounds
                self._lower_bound[metric] = parameters["lower bound printing"]
                self._upper_bound[metric] = parameters["upper bound printing"]
                # get the parameters for the plots graphic from the config
                line_width = global_config.get_config_param("chart line width", default=2)
                line_alpha = global_config.get_config_param("chart line alpha", default=0.3)
                fig_sizes = global_config.get_config_param("chart fig size", default=[12, 10.5])
                metric_results = self._results_metrics_for_actors[actor][metric]
                fig, axis = plt.subplots(figsize=(fig_sizes[0], fig_sizes[1]), layout="constrained")
                self._ax[actor][metric] = axis
                self._fig[actor][metric] = fig
                # set labels and limits
                self._ax[actor][metric].set_title("Actor: " + actor.get_name_actor() + " | Metric: " + str(metric))
                self._ax[actor][metric].set_xlim(0, len(metric_results) - 1)
                self._ax[actor][metric].set_ylim(self._lower_bound[metric], self._upper_bound[metric])
                # plot lines
                self._ax[actor][metric].plot(range(len(metric_results)), metric_results,
                                             color=self._colors[actor], alpha=line_alpha, linewidth=line_width)

    def _create_time_dots_in_plot(self):
        """
        Creates the dots which indicate the time in the chart
        """
        dot_size = global_config.get_config_param("chart dot size", default=10)
        for actor in self._get_plot_actors():
            self._time_dots[actor] = dict()
            for metric in self._get_plot_metrics(actor):
                y = min(max(self._results_metrics_for_actors[actor][metric][0], self._lower_bound[metric]),
                        self._upper_bound[metric])
                self._time_dots[actor][metric] = self._ax[actor][metric].plot(0, y, "o", color=self._colors[actor],
                                                                              markersize=dot_size)[0]

    def _plot_figure(self):
        """
        Creates the plots / windows for the metric graphs.
        """
        for actor in self._get_plot_actors():
            self._backgrounds[actor] = dict()
            for metric in self._get_plot_metrics(actor):
                logger.debug("Initializing plot figures for actor " + str(actor) + " and metric " + str(metric))
                fig = self._fig[actor][metric]
                fig.canvas.draw()
                plt.pause(0.5)  # if something does not work try to increase this time and pray to god that it helps
                fig.canvas.manager.window.wm_geometry("+0+0")
                plt.show(block=False)
                self._backgrounds[actor][metric] = fig.canvas.copy_from_bbox(self._ax[actor][metric].bbox)

    def _plotter(self, frame: int, debug=False):
        """
        This method prints the points which represents the current progress in chart for a given frame.
        if it is needed to change this you can find information under:
            - https://stackoverflow.com/questions/40126176/fast-live-plotting-in-matplotlib-pyplot
            - https://matplotlib.org/stable/tutorials/intermediate/artists.html
            - https://stackoverflow.com/questions/8955869/why-is-plotting-with-matplotlib-so-slow
        :param frame: frame for which the point should be drawn
        :param debug: Whether debug information shall be printed in CARLA.
        """
        assert 0 <= frame < self._max_frames
        for actor in self._get_plot_actors():
            for metric in self._get_plot_metrics(actor):
                y = min(max(self._results_metrics_for_actors[actor][metric][frame], self._lower_bound[metric]),
                        self._upper_bound[metric])

                # do not change the order or commands unless you know what you are doing
                self._fig[actor][metric].canvas.restore_region(self._backgrounds[actor][metric])
                self._time_dots[actor][metric].set_data(frame, y)
                self._ax[actor][metric].draw_artist(self._time_dots[actor][metric])
                self._fig[actor][metric].canvas.blit(self._ax[actor][metric].bbox)
                self._fig[actor][metric].canvas.flush_events()

                if debug:
                    loc = actor.get_location_list()[frame]
                    # print box above actors to know which actor maps to which graph
                    self._world.debug.draw_point(loc + carla.Location(z=5),
                                                 life_time=4 / global_config.get_config_param("frame rate", default=60),
                                                 size=global_config.get_config_param("default mid point size",
                                                                                     default=0.2),
                                                 color=self._carla_colors[actor])
                    # writes actor name
                    self._world.debug.draw_string(loc + carla.Location(z=3.5), actor.get_name_actor(), life_time=-1,
                                                  color=self._carla_colors[actor])
                    # writes name of metric and result for the actor
                    self._world.debug.draw_string(loc + carla.Location(z=2.5),
                                                  "{}: {:5.2f}".format(str(metric), y), life_time=-1,
                                                  color=self._carla_colors[actor])

    def _create_ui(self) -> tk.Tk:
        """
        Creates a simple ui where the user can change speed and pause
        """
        def set_speed(value):
            self._replay_speed = value
        # create super simple layout to change the replay speed or pause
        root = tk.Tk()
        root.geometry("400x300")
        root.geometry(f"+2000+0")
        button1 = tk.Button(root, text="Quarter Speed", command=lambda: set_speed(0.25))
        button2 = tk.Button(root, text="Normal Speed", command=lambda: set_speed(1))
        button3 = tk.Button(root, text="Max Speed", command=lambda: set_speed(5))
        button4 = tk.Button(root, text="Pause", command=lambda: set_speed(0))
        button1.pack(padx=20, pady=20)
        button2.pack(padx=20, pady=20)
        button3.pack(padx=20, pady=20)
        button4.pack(padx=20, pady=20)
        root.update_idletasks()
        root.update()
        return root
