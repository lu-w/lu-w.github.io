import json
import os
import tempfile
import logging

import carla

from carlametrics.data.log import Log

logger = logging.getLogger(__name__)


class Recorder:
    """
    Provides methods to for the recording of CARLA data.
    """
    def __init__(self, directory_path: str = None, record_name: str = None, address="localhost", port=2000,
                 client: carla.Client = None):
        if directory_path is None:
            self._directory_path = tempfile.mkdtemp()
        else:
            self._directory_path = directory_path

        if record_name is None:
            self._record_name = self._create_default_name()
        else:
            self._record_name = record_name
        if client is None:
            self._client = carla.Client(address, port)
            self._client.set_timeout(20.0)
        else:
            self._client = client
        self._settings = None

    def start(self):
        """
        Starts the recording feature. A file at the given directory path and recording name is created.
        """
        saving_path = self._get_log_path()
        self._settings = self._get_relevant_settings()
        self._client.start_recorder(saving_path, True)
        logger.info('Record with name ' + str(self._record_name) + ' started. Saving to ' + str(saving_path))

    def stop(self):
        """
        Stops the recording (if there was a started on previously). Writes the simulator settings to the settings file.
        """
        self._client.stop_recorder()
        with open(self._get_log_path() + Log._SETTINGS_SUFFIX, "w") as settings_file:
            settings_file.write(json.dumps(self._settings))
        logger.info('Stopped record')

    def get_log(self) -> Log:
        """
        Creates a Log object for this recording by reading the contents from the recording file path. Only works if
        the recording file has been created and filled before.
        """
        return Log(self._get_log_path(), client=self._client)

    def _get_log_path(self):
        return os.path.join(self._directory_path, self._record_name)

    def _get_relevant_settings(self):
        settings = self._client.get_world().get_settings()
        return {
            "fixed_delta_seconds": settings.fixed_delta_seconds,
            "synchronous_mode": settings.synchronous_mode,
            "substepping": settings.substepping,
            "max_substep_delta_time": settings.max_substep_delta_time,
            "max_substeps": settings.max_substeps
        }

    def _create_default_name(self) -> str:
        """
        Creates the default name for a log file
        :return: name
        """
        names = os.listdir(self._directory_path)
        files = [name for name in names if os.path.isfile(os.path.join(self._directory_path, name))]
        record_name = str(len(files))
        return record_name
