import sys
import json
import os
import pathlib
import logging
from typing import List

import carla
sys.path.append(os.path.join(pathlib.Path(__file__).parent.resolve(), 'scenario_runner'))
from srunner.metrics.tools.metrics_log import MetricsLog

from carlametrics.data.actor import Actor

logger = logging.getLogger(__name__)


class Log:
    """
    Functionality for logging a CARLA scenario. Basically a wrapper around CARLAs recording feature.
    Allows to extract data.Actor objects from the log for the use in computing criticality metrics on them.
    """
    _DEFAULT_MASS = 80  # kg
    _SETTINGS_SUFFIX = ".json"

    def __init__(self, file: str, settings_file: str = None, address="localhost", port: int = 2000,
                 client: carla.Client = None):
        """
        Initializes a new log which saves to the given file. These settings can not be changed later.
        :param file: File path to which the log is saved.
        :param settings_file: An optional settings file to which the simulator settings are stored. If None, uses a
            default of "file.settings"
        :param address: Address to connect to the CARLA simulator
        :param port: Port to connect to the CARLA simulator
        :param client: CARLA client (if given, the previous two parameters are ignored)
        """
        if not os.path.isfile(file):
            raise FileNotFoundError("Log can not be loaded from " + str(file))
        self._file = file
        if client is None:
            self._client = carla.Client(address, port)
            self._client.set_timeout(20.0)
        else:
            self._client = client
        if settings_file is None:
            if "." in self._file:
                self._settings_file = ".".join(self._file.split(".")[:-1]) + self._SETTINGS_SUFFIX
            else:
                self._settings_file = self._file + self._SETTINGS_SUFFIX
        else:
            self._settings_file = settings_file
        self._load_settings()

    def replay(self, time_start: int = 0, time_end: int = 0):
        """
        Starts a replay of this log
        :param time_start: time at which the scenario should start
        :param time_end: time at which the scenario should end Default: scenario length (0)
        """
        self._apply_settings()
        # set the times correctly (0 is the default carla implementation for complete replay)
        if time_start > time_end:
            logger.warning("Invalid start time " + str(time_start) + ". Reset to 0")
            time_start = 0
        if time_end > 0:
            replay_duration = time_end - time_start
        else:
            replay_duration = 0
        logger.info("Replaying file " + str(self._file))
        self._client.replay_file(self._file, time_start, replay_duration, 1)

    def get_framerate(self):
        if "fixed_delta_seconds" in self.settings:
            return 1 / self.settings["fixed_delta_seconds"]
        else:
            return None

    def get_filepath(self):
        """
        :returns: the path to which the log is or will be saved to.
        """
        return self._file

    def get_settingspath(self):
        """
        :returns: the path to which the simulator settings are or will be saved to.
        """
        return self._settings_file

    def _load_settings(self):
        self.settings = dict()
        if not os.path.isfile(self._settings_file):
            logger.warning("No settings found at " + str(self._settings_file) +
                           ". Live graphing feature is not available.")
        else:
            with open(self._settings_file, "r") as settings_file:
                self.settings = json.load(settings_file)
            logger.debug("Loaded settings " + self._settings_file)

    def _apply_settings(self):
        settings = self._client.get_world().get_settings()
        for setting in self.settings:
            logger.debug("Setting " + str(setting) + " to " + str(self.settings[setting]))
            setattr(settings, setting, self.settings[setting])

    def extract_actor(self, actor_name: str, remove_z_values: bool = True) -> Actor:
        info = self._client.show_recorder_file_info(self._file, True)
        if "not found on server" in info:
            raise ValueError("Log is empty! Check if path for log files is correct. "
                             "The used path is " + str(self._file))

        log = MetricsLog(info)
        actor_ids = log.get_actor_ids_with_role_name(actor_name)
        if len(actor_ids) > 0:
            actor_id = actor_ids[0]
        else:
            raise ValueError("\n Actor " + str(actor_name) + " not present in data. \n Actor ids = " + str(actor_ids))

        actor_alive_frames = log.get_actor_alive_frames(actor_id)
        physics_control = log.get_vehicle_physics_control(vehicle_id=actor_id,
                                                          frame=int((actor_alive_frames[0] + actor_alive_frames[1])/2))
        if physics_control is not None:
            mass = physics_control.mass
        else:
            mass = self._DEFAULT_MASS

        velocities = []
        transforms = []
        locations = []
        # loop to collect the data for each frame
        for i in range(log.get_total_frame_count()):
            # get velocity
            velocity = log.get_actor_velocity(actor_id, i)
            transform = log.get_actor_transform(actor_id, i)

            # dont add None existing values
            if velocity is None or transform is None:
                continue

            if velocity.length() == 0:
                continue

            velocity.z = 0 if remove_z_values else velocity.z

            # get transform
            if remove_z_values:
                location = transform.location
                location.z = 0
                transform.location = location

            velocities.append(velocity)
            transforms.append(transform)
            locations.append(transform.location)

        bounding_box = log.get_actor_bounding_box(actor_id)
        time_delta = log.get_delta_time(actor_alive_frames[0])
        spawn_frame = actor_alive_frames[0]
        despawn_frame = actor_alive_frames[1]

        return Actor(locations, velocities, mass, bounding_box, time_delta, actor_name, transforms, spawn_frame,
                     despawn_frame)

    def extract_actors(self, *actor_names: str) -> List[Actor]:
        actors = [self.extract_actor(name) for name in actor_names]

        # get the frame at which all actors are spawned and the minimal time of existance
        max_spawn_frame = max([a.get_spawn_frame() for a in actors])
        min_length = min([len(actor.get_speed_list()) for actor in actors])

        # due to the offset in spawn frames the actor trim start needs to be set per actor
        for actor in actors:
            trim_start = max_spawn_frame - actor.get_spawn_frame()
            actor.trim_to_frames(trim_start, min_length + trim_start)

        return actors
