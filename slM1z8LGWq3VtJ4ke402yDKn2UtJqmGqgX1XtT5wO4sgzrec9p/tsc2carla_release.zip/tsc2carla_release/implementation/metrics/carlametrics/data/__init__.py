import sys
import os

# Required for loading the scenario runner library. This is hacky, it would be best of scenario_runner would be a
# Python package. Till then...
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "scenario_runner"))
