import math
from typing import Tuple, List
from shapely.geometry import Polygon

import carla
import numpy as np

from carlametrics.config import config
from carlametrics.metrics import utils
from carlametrics.config.config import global_config


class Actor:
    """
    Provides easy access to actors' information and convenience method for computation on their properties.
    It's important to point out than nearly all calculations are done with numpy arrays or lists for efficiency.
    To make it easier to implement new metrics, this class provides some calculation methods for actors:
        - intersection of paths
        - time to intersection of trajectories
        - actor before and parallel, which returns something if the ego follows the actor
        - ...
    """

    def __init__(self, locations: List[carla.Location], velocities: List[carla.Vector3D], mass: float,
                 bounding_box: carla.BoundingBox, time_delta: float, name: str, transforms: List[carla.Transform],
                 spawn_frame: int, despawn_frame: int):
        self.locations = locations
        self.velocities = velocities
        self.mass = mass
        self.bounding_box = bounding_box
        self.time_delta = time_delta
        self.name = name
        self.transforms = transforms
        self.spawn_frame = spawn_frame
        self.despawn_frame = despawn_frame

    def __str__(self):
        return self.name

    def describe(self) -> str:
        """
        :returns: a string describing this actor in detail. Can be used for debugging.
        """
        return ("Actor " + str(self.name) + ":\n"
                "Locations:\t" + str([str(x) for x in self.get_location_list()]) + "\n"
                "Velocities:\t" + str([str(x) for x in self.get_velocity_list()]) + "\n"
                "Transforms:\t" + str([str(x) for x in self.get_transform_list()]) + "\n"
                "Bounding box:\t" + str(self.get_bounding_box()) + "\n"
                "Time delta:\t" + str(self.get_timedelta()) + "\n"
                "Spawn frame:\t" + str(self.get_spawn_frame()) + "\n"
                "Despawn frame:\t" + str(self.get_despawn_frame()))

    def get_location_list(self) -> List[carla.Location]:
        """
        :return: list of locations for each frame
        """
        return self.locations

    def get_velocity_list(self) -> List[carla.Vector3D]:
        """
        :return: list of velocities in as a three-dimensional vector in m/s
        """
        return self.velocities

    def get_speed_list(self) -> np.array:
        """
        :return: numpy array of speeds of the actor in m/s
        """
        velocities = self.get_velocity_list()
        velocities = np.array([[velocity.x, velocity.y] for velocity in velocities])
        speed_values = np.linalg.norm(velocities, axis=1)
        return speed_values

    def get_bounding_box(self) -> carla.BoundingBox:
        """
        :return: bounding box from the first frame of this actor
        """
        return self.bounding_box

    def get_mass(self) -> float or int:
        """
        :return: mass of the actor
        """
        return self.mass

    def get_timedelta(self) -> float:
        """
        :return: timedelta of the simulation so the time between 2 frames or in a formula 1/(frames per second)
        """
        return self.time_delta

    def get_transform_list(self) -> List[carla.Transform]:
        """
        :return: tuple of transforms
        """
        return self.transforms

    def get_name_actor(self) -> str:
        """
        :return: name of the actor for which all values in this class are calculated
        """
        return self.name

    def get_max_frame(self, other=None) -> int:
        """
        :return: the number of frames this actor has
        """
        length_loc = len(self.get_location_list())
        length_vel = len(self.get_velocity_list())
        length_tra = len(self.get_transform_list())
        min_actor = min(length_loc, length_tra, length_vel)

        if other is None:
            return min_actor

        other_len_loc = len(other.get_location_list())
        other_len_vel = len(other.get_velocity_list())
        other_len_tra = len(other.get_transform_list())

        return min(min_actor, other_len_loc, other_len_tra, other_len_vel)

    def get_spawn_frame(self) -> int:
        return self.spawn_frame

    def get_despawn_frame(self) -> int:
        return self.despawn_frame

    def get_maximal_deceleration(self) -> float:
        # TODO make blueprint-dependent
        return config.global_config.get_config_param("btn", "maximal deceleration", default=9.81)

    def trim_to_frames(self, start_frame: int, end_frame: int):
        self.velocities = self.velocities[start_frame + 1:end_frame]
        self.transforms = self.transforms[start_frame + 1:end_frame]
        self.locations = self.locations[start_frame + 1:end_frame]

    def get_path_as_polygon(self) -> [Polygon]:
        """
        Method to get the area of the bounding box from the vehicle over time
        :return: list of rectangles which are given by the bounding boxes and the locations of the actor
        """
        transforms = self.get_transform_list()
        bounding_box = self.get_bounding_box()
        func = utils.get_bounding_box_function_over_transforms(bounding_box)
        rectangle_corners = [func(transform) for transform in transforms]
        return rectangle_corners

    def get_intersection_point_of_paths_for_frame(self, other: "Actor", frame: int,
                                                  allow_locations_behind: bool = False,
                                                  epsilon_speed: float = 0) -> carla.Location:
        """
        Does the same as get_intersection_point_of_paths but needs only one input.

        :param frame:                       frame at which the value should be calculated
        :param other:                       other actor for which to compute the intersection with
        :param allow_locations_behind:      if False the return for an intersection point where at least one have to
                                            drive backwards is also carla.Location(math.inf, math.inf, math.inf)
        :param epsilon_speed:               lower bound for the usage af velocities.
                                            any speed lower than this is assumed as standing still.
                                            if eps is lower or equal to 0 it takes the default from config (=0.1)

        :return:                            carla.Location for the intersection of paths for a given frame
        """
        try:
            location = self.get_location_list()[frame]
            velocity = self.get_velocity_list()[frame]
            act_location = other.get_location_list()[frame]
            act_velocity = other.get_velocity_list()[frame]
            return utils.get_intersection_point_of_paths(location, velocity, act_location, act_velocity,
                                                         allow_locations_behind, epsilon_speed)
        except IndexError:
            return carla.Location()

    def get_bounding_box_as_matrix(self, transform: carla.Transform, delta: float = 0) -> List[List[float]]:
        """
        Method to get the bounding boxes as a list of 2-dimensional tuples for a given location

        :param transform:   The transform of the actor for a given frame
        :param delta:       parameter to scale the size of the bounding boxes.
                            if (delta <= 0) the 'delta bounding box scale parameter' in config is used
                            Example: delta = 2 makes every bounding box twice as long and twice as wide

        :return: List of tuples which represent the 4 corners of the bounding box in the x, y plane
        """
        if delta <= 0:
            delta = global_config.get_config_param('delta bounding box scale', default=1)
        bounding_box = self.get_bounding_box()
        extent = bounding_box.extent
        corners = [carla.Vector3D(x, y, 0)
                   for x in [-extent.x * delta, extent.x * delta]
                   for y in [-extent.y * delta, extent.y * delta]]
        corners = [transform.transform(corner) for corner in corners]
        bounding_box_rotated = [[corner.x, corner.y] for corner in corners]
        return bounding_box_rotated

    def get_predicted_path_under_constant_velocity(self, time_in_future: int = 0) \
            -> Tuple[List[carla.Vector3D], List[carla.Vector3D], List[carla.Vector3D]]:
        r"""
        Method to get the vectors which limit the area before a vehicle

        Parameters
        ----------
        "time_in_future":
            - represents an upper bound for the area to be calculated
            - Example:  if this value is 10 (sec) the area before the combined set of all points where the ego will be
                        in the next 10 seconds :math:`\cup_{t_0 \to t} \left(\bar B_{ego}\right)`

        Return
        ------
        All return values are lists of carla 3D vectors where the index of an item is the frame at which this
        value is calculated
            1. direction vector for the actor given by :math:`v_{direction} = v_{velocity} \cdot t_{in \ future}`
                - note: instead of the velocity, forward vector times speed is used (because more intuitive results)
            2. left point of the vehicle bounding box
            3. right point of the vehicle bounding box

        Usage
        -----
        You get those points from this method
        calculate the bounding vectors with of the area with:  :math:`P_{Location} + L \lor R + D`
            - |---L----|>
            - |=Actor=|-----------> D
            - |---R----|>

        :param time_in_future:  length of the area before the ego vehicle.

        :return: Tuple of 3 lists of carla 3DVectors directions, left points, right points
        """
        if time_in_future <= 0:
            time_in_future = global_config.get_config_param('cutoff time counted as in front', default=120)
        bounding_box = self.get_bounding_box()
        locations = self.get_location_list()
        velocities = self.get_velocity_list()
        transforms = self.get_transform_list()
        forward_vectors = [transform.get_forward_vector() for transform in transforms]
        ego_extent = min(bounding_box.extent.x, bounding_box.extent.y)

        right_orthogonal_vector = [
            locations[i] + ego_extent * carla.Location(
                - forward_vectors[i].y,
                forward_vectors[i].x)
            for i in range(len(locations))
        ]
        left_orthogonal_vector = [
            locations[i] + ego_extent * carla.Location(
                forward_vectors[i].y,
                - forward_vectors[i].x)
            for i in range(len(locations))
        ]

        direction_vectors = [time_in_future * forward_vectors[i] * velocities[i].length()
                             for i in range(len(locations))]

        return direction_vectors, left_orthogonal_vector, right_orthogonal_vector

    def compute_projection_of(self, other: "Actor", epsilon_angle: float or int = None):
        """
        Gets the projection point of the given actor on this actor if there is a projection

        Usage
        -----
            - To get the distance you would calculate the length of the :math:`projection - location_{actor}` location
            - To get the time until intersection you would calculate:
              :math:`\|projection - location_{actor}\| \  / \ v_{ego}`

        :param other:           the other actor to compute the projection for
        :param epsilon_angle:   the maximal angle at which 2 vectors are considered as same direction (in °)
                                if None: the epsilon angle default from config is used
        :return:                point where the actor gets orthogonal projected on
        """
        if epsilon_angle is None:
            epsilon_angle = global_config.get_config_param('epsilon angle default', default=10)

        # initialize
        ego_location = self.get_location_list()

        # use forward vector because velocity is not always straight forward (for example if vehicle steers)
        ego_transform = self.get_transform_list()
        ego_forward_vector = [transform.get_forward_vector() for transform in ego_transform]

        # calculate vectors orthogonal to the driving direction with the length of the vehicle
        forward_vector, left_lim_start, right_lim_start = self.get_predicted_path_under_constant_velocity()

        # initialize Actor
        act_location = other.get_location_list()
        act_transforms = other.get_transform_list()
        act_forward_vectors = [transform.get_forward_vector() for transform in act_transforms]
        results = []

        # iterate over all frames to check if actor is in box before ego
        for i in range(self.get_max_frame()):
            is_in_area = False

            # filters out all values where at least one of the vectors is for some reason 0
            if ego_forward_vector[i].length() * act_forward_vectors[i].length() != 0:
                results.append(None)
                continue

            angle_between = np.rad2deg(math.acos(ego_forward_vector[i].dot_2d(act_forward_vectors[i])))
            if epsilon_angle < abs(angle_between):
                results.append(None)
                continue

            act_box_np = other.get_bounding_box_as_matrix(transform=act_transforms[i])
            forward_normalized = forward_vector[i] / np.linalg.norm(np.array([forward_vector[i].x,
                                                                              forward_vector[i].y]))
            distance_actor_ego = ego_location[i].distance_2d(act_location[i])

            # check if corner is inside the area before the ego for a given frame i
            right_forward_vector = right_lim_start[i] + forward_normalized * distance_actor_ego
            left_forward_vector = left_lim_start[i] + forward_normalized * distance_actor_ego
            for corners in act_box_np:  # goes throw each corner of the bounding box
                if utils.point_between(right_forward_vector, left_forward_vector, corners):
                    is_in_area = True
                    break

            # if actor not in the area before the ego return None for this frame
            if not is_in_area:
                results.append(None)
                continue

            orthogonal_vector = right_lim_start[i] - left_lim_start[i]
            projection = utils.orthogonal_projection(point=act_location[i],
                                                     direction_of_line=orthogonal_vector,
                                                     location_on_line=left_lim_start[i])

            results.append(projection)

        return results

    def time_to_intersection_point_of_paths(self, other: "Actor") -> Tuple[np.array, np.array]:
        """
        Method to get the times the actors need to go to the intersection point \n
        :return: tuple of lists containing the times of ego and actor

        Returns
        -------
           - time of the ego to the intersection of paths
           - time of the actor to the intersection of paths \n
                times are returned as a numpy array of float or int where the index represents the frame number for
                which the times are calculated

        Getting Values
        --------------
        to get both write: \n
        ego_time, actor_time = time_to_intersection_point()
        """
        # clean up speed values so that alle 0 values are set to minus 1 so that it is easy to filter them out
        # afterward
        # Warning: if driving back is allowed this is not going to work
        ego_speed = self.get_speed_list()
        act_speed = other.get_speed_list()

        # if they stand still the result will be something negative and this is filtered out before returning
        ego_speed[ego_speed == 0] = -1
        act_speed[act_speed == 0] = -1

        # Initialize the locations
        ego_locations = self.get_location_list()
        act_locations = other.get_location_list()

        max_frame = self.get_max_frame(other)
        intersection_points = [self.get_intersection_point_of_paths_for_frame(other, i) for i in range(max_frame)]

        # Calculate the distances to the intersection point
        ego_distance = np.array([intersection_points[i].distance(ego_locations[i]) for i in range(max_frame)])
        act_distance = np.array([intersection_points[i].distance(act_locations[i]) for i in range(max_frame)])

        ego_time = np.array(ego_distance / ego_speed)
        act_time = np.array(act_distance / act_speed)

        # final cleanup negative values, which can exist if both actors drive away from each other or backwards
        ego_time[ego_time < 0] = math.inf
        act_time[act_time < 0] = math.inf

        return ego_time, act_time

    def time_to_intersection_point_of_trajectories(self, other: "Actor") -> List[float]:
        """
        Does the same as the method time_to_intersection_of_trajectories_for_values but with no inputs.

        Returns
        -------
            - this method returns a list of values which represent the time it takes until both actors collide
            - the assumption is that both actors do nothing until they collide starting at the frame (given by index)
            - this method returns np.inf if there is no intersection of trajectories

        :return: time it will take until both actors collide assuming constant velocity
        """
        # get parameter lists
        ego_velocity = self.get_velocity_list()
        act_velocity = other.get_velocity_list()
        ego_transform = self.get_transform_list()
        act_transform = other.get_transform_list()
        result_list = []
        for i in range(self.get_max_frame()):
            result_list.append(
                self._time_to_intersection_point_of_trajectories_for_values(other,
                                                                            ego_velocity=ego_velocity[i],
                                                                            ego_transform=ego_transform[i],
                                                                            act_velocity=act_velocity[i],
                                                                            act_transform=act_transform[i])
            )
        return result_list

    def _time_to_intersection_point_of_trajectories_for_values(self, other: "Actor",
                                                               ego_velocity: carla.Vector3D,
                                                               ego_transform: carla.Transform,
                                                               act_velocity: carla.Vector3D,
                                                               act_transform: carla.Transform) -> float:
        """
        Method to get the point of the time dependent intersection of both actors. In other words, the point where both
        actors collide if they drive with constant velocity and do not change their heading.

        :param other:           other actor to compute intersection with
        :param ego_velocity:    velocity of ego
        :param ego_transform:   transform of ego
        :param act_velocity:    velocity of other actor
        :param act_transform:   transform of other actor

        :returns:           time until both would collide assuming constant velocity

        Explanation
        -----------

        -  1. We can assume that there is one point in time, when the distance between the two actors is minimized,
           because of constant velocity
        -  2. We can assume the first derivative of the distance between the actors is constant for values of t which
           are not near to the global minimum (there is no derivative)

        ==> Because both assumptions are plausible we can do a binary search

        -  We can also say that the decrease of the distance between them (before global min) and the increase after
           the global min is approximately equal for values with enough distance to global min
        -  that is why we can say that if the distance at the upper bound is grater than the one at the lower bound, the
           minimum is in the first half of the values (same for lower bound)
        -  So if the difference of the distances at the bounds is big we can split the interval more than one half but
           only in the first iteration to prevent us from getting to close to the global min

        If one of both values is 0 and the other is not than we know that either the we already have the right
        point or it is before it. because our actors have some speed in nearly every case there are at max 10 values
        which are 0 so this does not reduce efficiency

        you can print out a graph with the plot_metrics class and the distance
        plot_distance_bounding_boxes_per_frame method.
        """
        ego_location = ego_transform.location
        act_location = act_transform.location
        time_delta = self.get_timedelta()

        # create functions for the calculation of the locations and the distance between the bounding boxes
        location_over_time_ego = lambda time: carla.Transform(location=ego_location + ego_velocity * time_delta * time,
                                                              rotation=ego_transform.rotation)
        location_over_time_act = lambda time: carla.Transform(location=act_location + act_velocity * time_delta * time,
                                                              rotation=act_transform.rotation)
        distance_at_time = lambda time: self._min_distance_boxes_fixed_location(location_over_time_ego(time),
                                                                                other,
                                                                                location_over_time_act(time))

        # if the distance at the first timestamp is already intersecting than both vehicles drive away from each other
        # we do not need to do any calculations and can say that those vehicles never collide
        if distance_at_time(0) < distance_at_time(1):
            return np.inf

        # because of the symmetry we know for any 2 points that f(t_1) < f(t_2) the minimum is in the interval
        lower_bound = 0
        upper_bound = self.get_max_frame()
        time_until_minimum = - 1

        # Because we always take away half of the interval we can only need k iterations (at max) to get the first
        # global min for 2 ^ k integers
        maximum_iterations = math.ceil(math.log(self.get_max_frame(), 2))

        for i in range(maximum_iterations):
            # calculating the midpoint and the distances for the first and last frame in the interval
            midpoint = int((lower_bound + upper_bound) / 2)
            distance_lower_bound = distance_at_time(lower_bound)
            distance_upper_bound = distance_at_time(upper_bound)

            if i == 0 and distance_lower_bound < distance_upper_bound:
                upper_bound *= distance_lower_bound / distance_upper_bound

            if i == 0 and distance_lower_bound > distance_upper_bound:
                lower_bound *= distance_upper_bound / distance_lower_bound

            if distance_lower_bound == 0 or distance_upper_bound == 0:  # check if we already found a 0
                zero_index = lower_bound if distance_lower_bound <= distance_upper_bound else upper_bound
                # we iterate throw all times before until we found the first which is not 0 than we return the last
                while distance_at_time(zero_index - 1) == 0:
                    zero_index -= 1
                    if zero_index < 0:  # to prevent infinite loops
                        break
                time_until_minimum = zero_index  # first index with 0 distance
                break

            # make the splits
            if distance_lower_bound < distance_upper_bound and upper_bound != midpoint:
                upper_bound = midpoint
            elif distance_lower_bound > distance_upper_bound and lower_bound != midpoint:
                lower_bound = midpoint
            else:
                time_until_minimum = lower_bound if distance_lower_bound < distance_upper_bound else upper_bound
                break

        # if the minimal distance between the 2 vehicles is larger than 0 than they do not collide
        if distance_at_time(time_until_minimum) > 0:
            return np.inf

        return time_until_minimum * time_delta

    def _min_distance_boxes_fixed_location(self, self_transform: carla.Transform, other,
                                           other_transform: carla.Transform) -> float:
        """
        Calculates the minimal distance between 2 bounding box object for 2 given locations
        """
        ego_bounding_box = np.array(self.get_bounding_box_as_matrix(transform=self_transform))
        min_values_ego = np.min(ego_bounding_box, axis=0)
        max_values_ego = np.max(ego_bounding_box, axis=0)

        act_bounding_box = np.array(other.get_bounding_box_as_matrix(transform=other_transform))
        min_values_act = np.min(act_bounding_box, axis=0)
        max_values_act = np.max(act_bounding_box, axis=0)
        dx = utils.interval_distance(min_values_ego[0],
                                     max_values_ego[0],
                                     min_values_act[0],
                                     max_values_act[0])
        dy = utils.interval_distance(min_values_ego[1],
                                     max_values_ego[1],
                                     min_values_act[1],
                                     max_values_act[1])

        return math.sqrt(dx ** 2 + dy ** 2)
