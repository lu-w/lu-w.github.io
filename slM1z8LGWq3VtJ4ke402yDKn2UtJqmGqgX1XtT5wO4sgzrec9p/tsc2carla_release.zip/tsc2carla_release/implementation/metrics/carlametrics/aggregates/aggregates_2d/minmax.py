from carlametrics.aggregates.aggregation import TimeAndActorAggregation
from carlametrics.aggregates.aggregates_1d.min import Minimum
from carlametrics.aggregates.aggregates_1d.max import Maximum


class MinMax(TimeAndActorAggregation):
    _OVER_TIME = Minimum()
    _OVER_ACTORS = Maximum()
    _TIME_FIRST = True
