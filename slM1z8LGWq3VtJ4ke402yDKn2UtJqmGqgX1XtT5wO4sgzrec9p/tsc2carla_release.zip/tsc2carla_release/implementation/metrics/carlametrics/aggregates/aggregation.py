import math
import logging
from typing import List

import pandas as pd

from carlametrics.config.config import global_config

logger = logging.getLogger(__name__)


class Aggregation:
    def aggregate(self, values: list) -> float or int:
        pass


class TimeAndActorAggregation(Aggregation):
    _OVER_TIME = None
    _OVER_ACTORS = None
    _TIME_FIRST = True

    def aggregate(self, values: List[list], replace_nan_with: float or int = None, results_can_be_nan: bool = True) \
            -> float or int:
        """
        Method to aggregate Metric Results for n Actors given specific aggregation Methods and order of aggregating
        :param values:              metric results for all actors as tuple of lists
        :param replace_nan_with:    if set all nan values in the inputted metric results get replaces with this value
        :param results_can_be_nan:  if True the result can be nan
                                    if False the result is the first value which is not nan
        """
        if not (isinstance(self._OVER_TIME, Aggregation) and isinstance(self._OVER_ACTORS, Aggregation)):
            raise ValueError("Invalid configuration of actor and time aggregation with actor aggregation function" +
                             str(self._OVER_ACTORS) + " and time aggregation function " + str(self._OVER_TIME))
        debug = global_config.get_config_param('print aggregation results in console', default=False)
        value_dict = {}
        for i, _ in enumerate(values):
            value_dict[i] = values[i]

        df = pd.DataFrame().from_dict(value_dict, orient='index')

        if replace_nan_with is not None:
            df = df.fillna(value=replace_nan_with)
        if debug:
            logger.debug(df)

        # apply functions
        if self._TIME_FIRST:
            first_method = self._OVER_TIME.aggregate
            second_method = self._OVER_ACTORS.aggregate
        else:
            first_method = self._OVER_ACTORS.aggregate
            second_method = self._OVER_TIME.aggregate

        result = df.apply(first_method, axis=0 if self._TIME_FIRST else 1)
        if debug:
            if self._TIME_FIRST:
                logger.debug(result)
            else:
                df["--------"] = ['-->'] * len(values[0])
                df['Aggregated'] = result
                logger.debug(df)
        result = second_method(result)
        if not results_can_be_nan and math.isnan(result):
            result = 0
        return result
