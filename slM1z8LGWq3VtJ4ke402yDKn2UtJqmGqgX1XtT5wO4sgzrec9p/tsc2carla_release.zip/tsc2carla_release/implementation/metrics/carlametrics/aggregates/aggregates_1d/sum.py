import numpy as np
from carlametrics.aggregates.aggregation import Aggregation


class Sum(Aggregation):
    def aggregate(self, value_list: list) -> float or int:
        """
        :return: - sum of a list of metric results
                 - None if there is no data for the calculation
        """
        if len(value_list) == 0:
            return np.NaN
        return np.sum(value_list)
