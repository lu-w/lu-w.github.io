import numpy as np
from carlametrics.aggregates.aggregation import Aggregation


class Minimum(Aggregation):
    def aggregate(self, value_list: list) -> float or int:
        """
        :return: minimum value of a list of metric results over time
        """
        if len(value_list) == 0:
            return np.NaN
        return min(value_list)

