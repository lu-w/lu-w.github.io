import numpy as np
from carlametrics.aggregates.aggregation import Aggregation


class Quantile(Aggregation):
    def __init__(self, quantile: float = 0.5):
        super().__init__()
        self.quantile = quantile

    def aggregate(self, value_list: list) -> float or int:
        """
        :return: quantile of a list of metric results
        """
        if len(value_list) == 0:
            return np.NaN
        return np.percentile(value_list, self.quantile)
