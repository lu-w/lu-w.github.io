# `carlametrics`: Calculating criticality metrics in CARLA

This Python package provides an implementation of some criticality metrics for the CARLA simulator.
It allows easy computation using CARLAs recording feature and live plotting during replay.

## Installation

First, run `git submodule update --init --recursive`.
You can then install this package by running `pip install .` from this directory.

All dependencies are automatically installed.
Note that you also require an instance of the CARLA simulator whose version matches your installed `carla` Python package.

## Usage

The most basic feature is to compute a criticality metric on a CARLA simulation.
Moreover, this package also supports (live) graphing.
Both features work on **recorded** data and do not compute the criticality metrics during the live simulation.
This is due to determinism.

### Examples

For working example code, refer to the examples for [metric calculation](examples/example_calculation.py) and 
[graphing](examples/example_graphing.py).

### Tutorial

This tutorial assumes a running CARLA server on `localhost:2000`.

#### Prerequisite: Recording your scenario

First, when setting up your scenario, we require designated names for the actors on which the metrics shall be computed 
later on.
This is done by setting the attribute `role_name` to the blueprint of the actor, e.g. "one" for the first actor:
```python
import random
import carla

client = carla.Client("localhost", 2000)
client.set_timeout(20.0)
bp1 = random.choice(client.get_world().get_blueprint_library().filter("vehicle.*"))
bp1.set_attribute("role_name", "one")
bp2 = random.choice(client.get_world().get_blueprint_library().filter("vehicle.*"))
bp2.set_attribute("role_name", "two")
# ... scenario setup (spawn actors, etc.)
```
If you use CARLA's [`scenario_runner` module](https://github.com/carla-simulator/scenario_runner/) with an OpenSCENARIO XML input, the attribute is automatically set according to the `name` given to the `ScenarioObject` in the XML file.
Then, instantiate and start a recorder for the log using:
```python
from carlametrics.data.recording import Recorder

rec = Recorder()
rec.start()
# ... scenario execution
```
Afterwards, let CARLA perform your simulation.
If the simulation has ended, stop the recording and extract the log with
```python
rec.stop()
log = rec.get_log()
```
The log is the central object on which criticality metrics are computed and graphs are rendered.
Note that this module is also compatible with logs created by CARLA's `scenario_runner` or CARLA itself.

This log is represented as two files on your disk: one for storing the scenario data and one for the settings of the 
simulator during simulation.
You can get the file name of your scenario data resp. your settings by:
```python
file = log.get_filepath()
settings = log.get_settingspath()
```

Logs can also be reloaded from such files:
```python
log = Log(file)
```

#### 1) Computing criticality metrics

To compute a criticality metric on the log (in our example, a Required Longitudinal Acceleration), call
```python
from carlametrics.metrics.a_req import AReq

areq_list = AReq(log, "one", "two").calculate()
```
Here, we assume two actors of the name `one` and `two` being present in the log.
Note that the CARLA server shall still be running in the background (since the log is parsed on the server).
The calculation result is a list of values for each recorded time point.

The package also provides some basic aggregation functionality:
```python
from carlametrics.aggregates.aggregates_1d.min import Minimum

areq_min = Minimum().aggregate(areq_list)
```

#### 2) Using the graphing feature

If you want to visualize the calculated values, create a grapher by:
```python
from carlametrics.graphing.graphing import MetricGrapher
from carlametrics.metrics.a_req import AReq

grapher = MetricGrapher(log, metrics=[AReq], actor_names=["two"], ego_name="one")
```

The graphing feature can be used in two ways:
1. showing a static plot using `grapher.show_graph()`
2. showing a live plot alongside a replay of the logged scenario in CARLA using `grapher.live_graph()`

Note that a graph is shown for each combination of actor to ego and given metric in the metrics list.
