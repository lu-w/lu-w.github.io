import os
import re
from datetime import datetime
from typing import Type, Dict

import pandas as pd
from pathlib import Path

from carlametrics.aggregates.aggregates_1d.min import Minimum
from carlametrics.aggregates.aggregates_1d.max import Maximum
from carlametrics.aggregates.aggregates_1d.quantile import Quantile
from carlametrics.aggregates.aggregates_1d.sum import Sum
from carlametrics.aggregates.aggregation import TimeAndActorAggregation
from carlametrics.metrics.a_req import AReq
from carlametrics.metrics.btn import BTN
from carlametrics.metrics.dpret import DPrET
from carlametrics.metrics.metric import Metric
from carlametrics.metrics.pci import PCI
from carlametrics.metrics.pet import PET
from carlametrics.metrics.pret import PrET
from carlametrics.metrics.spret import SPrET
from carlametrics.metrics.ttc import TTC
from carlametrics.data.log import Log
from carlametrics.analysis import MetricAnalyzer, VerdictCriterion
import glob
from utils.carla_server import start_carla_server, stop_all_carla_servers, carla_server_available

# Relative path to scenario runner directory
_SRUNNER_DIR = "tools/carla/scenario_runner/"
# Maps config entries to callable metrics
_KNOWN_METRICS = {
    'areq': AReq,
    'btn': BTN,
    'dpret': DPrET,
    'pci': PCI,
    'pet': PET,
    'pret': PrET,
    'spret': SPrET,
    'ttc': TTC
}
# Maps config entries to callable 1D-aggregates
_KNOWN_AGGREGATES = {
    "max": Maximum,
    "min": Minimum,
    "sum": Sum,
    "quantile": Quantile
}


def _get_aggregate(time_ag: str, actor_ag: str, time_first: bool) -> Type[TimeAndActorAggregation]:
    if time_ag not in _KNOWN_AGGREGATES:
        raise ValueError("Time aggregation " + time_ag + " not known.")
    if actor_ag not in _KNOWN_AGGREGATES:
        raise ValueError("Actor aggregation " + actor_ag + " not known.")

    time = _KNOWN_AGGREGATES[time_ag]
    actor = _KNOWN_AGGREGATES[actor_ag]

    class Agg(TimeAndActorAggregation):
        _OVER_TIME = time()
        _OVER_ACTORS = actor()
        _TIME_FIRST = time_first

    return Agg


class MetricEvaluationController(object):
    def __init__(self, args):
        self.esmini = args.esmini
        self.esmini_log_dir = args.esmini_log_dir
        self.carla = args.carla
        self.carla_log_dir = args.carla_log_dir
        self.carla_root = args.carla_root
        self.carla_low_quality = args.carla_low_quality
        self.criticality_evaluation = args.criticality_evaluation

    def postprocess_esmini(self):
        for logfile in (Path(x) for x in glob.glob(str(self.esmini_log_dir) + '/*.csv')):
            def rearrange_numbering(dataframe: pd.DataFrame, x: str):
                actor_id = re.search("(?<=#)[0-9]+", x)
                x = f"{dataframe[f'#{actor_id[0]}entitity_name'].mode()[0]}_{x}" if actor_id is not None else x
                x = re.sub("#[1-9]+", "", x)
                return x

            df = pd.read_csv(logfile, header=6)
            df = df.applymap(lambda x: x.lower() if type(x) == str else x)
            df = df.applymap(lambda x: x.strip() if type(x) == str else x)
            df = df.rename(columns=lambda x: re.sub("(\\[(s|m|1/|-|/|deg|rad|2)+]| )", "", x.lower()))
            df = df.rename(columns=lambda x: rearrange_numbering(df, x))
            df = df.rename(columns=lambda x: x.replace('world_position_', ''))
            df = df.rename(columns=lambda x: x.replace('vel_', 'v'))
            df = df.rename(columns=lambda x: x.replace('acc_', 'a'))
            df = df.rename(columns=lambda x: x.replace('world_heading_angle', 'yaw'))
            check_array = ['_entitity_name', '_entitity_id', '_current_speed', '_wheel_rotation', '_wheel_angle',
                           '_distance_travelled_along_road_segment', '_lateral_distance_lanem', '_heading_angle_rate',
                           '_relative_heading_angle', '_world_pitch_angle', '_road_curvature', '_collision_ids']
            for column in df.columns:
                for check in check_array:
                    if check in column:
                        df.drop(column, inplace=True, axis=1)
            df.drop('index', inplace=True, axis=1)
            df.round(2).to_csv(logfile.parent / '..' / logfile.name, index=False)
            os.remove(logfile)

    def postprocess_carla(self):
        started_carla = False
        if not carla_server_available():
            start_carla_server(carla_root=self.carla_root, low_quality=self.carla_low_quality)
            started_carla = True
        logs = []
        for l in glob.glob(_SRUNNER_DIR + str(self.carla_log_dir) + "/*.log"):
            try:
                logs.append(Log(str(os.path.abspath(l))))
            except Exception as e:
                print(f'Exception when creating log for {l}: {e}')
        metrics = [_KNOWN_METRICS[m] for m in self.criticality_evaluation["metrics"].keys()]
        actors = [tuple((a[0], a[1])) for a in self.criticality_evaluation["between"]]
        aggregates: Dict[Type[Metric], Type[TimeAndActorAggregation]] = {}
        criteria: Dict[Type[Metric], VerdictCriterion] = {}
        for m in self.criticality_evaluation["metrics"].keys():
            aggregates[_KNOWN_METRICS[m]] = _get_aggregate(self.criticality_evaluation["metrics"][m]["aggregate_time"],
                                                           self.criticality_evaluation["metrics"][m]["aggregate_actors"],
                                                           self.criticality_evaluation["metrics"][m]["time_first"])
            criteria[_KNOWN_METRICS[m]] = VerdictCriterion(self.criticality_evaluation["metrics"][m]["target_value"],
                                                           self.criticality_evaluation["metrics"][m]["fail_direction"]
                                                           == "negative")
        analyzer = MetricAnalyzer(logs, metrics, actors, aggregates)
        print("Evaluating criticality metrics...")
        metric_values = analyzer.batch_evaluation()
        passed, stats = analyzer.verdict(criteria)
        if started_carla:
            stop_all_carla_servers()
        tag = datetime.now().strftime("%Y%m%d_%H%M%S")
        metrics_file = (self.criticality_evaluation["output"] + "/" + tag + "_metrics.csv")
        verdicts_file = (self.criticality_evaluation["output"] + "/" + tag + "_verdicts.csv")
        metric_values.to_csv(metrics_file, index=False)
        stats.to_csv(verdicts_file, index=False)
        print("Metric values (aggregated) are available at " + metrics_file)
        print("Individual verdicts are available at " + verdicts_file)
        print("Overall verdict is: " + ("PASSED" if passed else "FAILED"))

    def run(self):
        if self.esmini:
            self.postprocess_esmini()
        if self.carla:
            self.postprocess_carla()
