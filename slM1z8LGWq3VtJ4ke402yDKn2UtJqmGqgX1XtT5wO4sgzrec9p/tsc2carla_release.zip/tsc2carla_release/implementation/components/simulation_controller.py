import json
import os
import sys
import glob
from pathlib import Path
import subprocess

from metrics.carlametrics.data.recording import Recorder
from utils.namespace import Namespace
from utils.carla_server import start_carla_server, stop_all_carla_servers
import importlib.util as il
if il.find_spec('carla'):
    from tools.carla.scenario_runner.scenario_runner import ScenarioRunner


class SimulationController(object):
    def __init__(self, args):
        self.args = args
        self.scenario_list = args.scenario_list
        self.carla_root = args.carla_root
        self.carla_low_quality = args.carla_low_quality
        if args.esmini:
            if sys.platform == "linux" or sys.platform == "linux2":
                self.esmini_path = Path(glob.glob('tools/esmini_lnx/bin/esmini')[0])
            elif sys.platform == "win32":
                self.esmini_path = Path(glob.glob('tools/esmini_win/bin/esmini')[0])
            else:
                print("Unsupported platform: {}".format(sys.platform))
                sys.exit()
            self.esmini_log_dir = args.esmini_log_dir
        if args.carla:
            self.carla_log_dir = args.carla_log_dir

    def run_esmini_sim(self):
        for scenario in self.scenario_list:
            os.system(f'{self.esmini_path} '
                      f'--headless '
                      f'--osc {scenario} '
                      f'--fixed_timestep 0.01 '
                      f'--csv_logger data_storage/traces/esmini/recording/{scenario.stem}.csv '
                      )

    def run_carla_sim(self, run_external_model=False, missing_only=False):
        start_carla_server(carla_root=self.carla_root, low_quality=self.carla_low_quality)
        for scenario in (Path(x).absolute() for x in self.scenario_list):
            # TODO: Do not hardcode path to scenario_runner here
            log_path = Path('tools', 'carla', 'scenario_runner', self.carla_log_dir, scenario.stem + '.log')
            print(log_path)
            if missing_only and log_path.exists():
                continue
            simulation_finished = False
            max_tries = 3
            while not simulation_finished and max_tries > 0:
                max_tries -= 1
                try:
                    simulation_finished = self.run_one_simulation_as_subprocess(scenario, run_external_model)
                except Exception as e:
                    print(e)
                if not simulation_finished:
                    print("Something went wrong. Restarting CARLA")
                    stop_all_carla_servers()
                    start_carla_server(carla_root=self.carla_root, low_quality=self.carla_low_quality)
            if not simulation_finished:
                print("Max number of simulation tries exceeded. Proceeding with next scenario.")

    def run_one_simulation_as_subprocess(self, scenario, run_external_model):
        args = [sys.executable, '-m', __name__,
                str(self.carla_root),
                str(int(self.carla_low_quality)),
                str(self.carla_log_dir),
                str(scenario),
                str(int(run_external_model))]
        try:
            code = subprocess.run(args).returncode
            return code == 0
        except Exception as e:
            print(e)
            return False

    def run_one_simulation(self, scenario, run_external_model):
        model_process = None
        if run_external_model:
            scenario_name = scenario.stem
            model_path = scenario.parent.parent.absolute().joinpath("model_data", f'{scenario_name}.json')

            runner_path = Path(glob.glob('models/runner.py')[0])

            cmd = ["python", "-u", str(runner_path), "--data", str(model_path)]
            print(f"Running external controller {cmd}..")
            model_process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        arguments = Namespace(
            name=scenario.name,
            openscenario=str(scenario),
            openscenarioparams=None,
            timeout=10.0,
            host="127.0.0.1",
            port=2000,
            agent=None,
            agentConfig=None,
            egoVehicles=None,
            debug=False,
            sync=True,
            reloadWorld=False,
            waitForEgo=True,
            trafficManagerPort=2001,
            trafficManagerSeed=0,
            record=self.carla_log_dir,
            outputDir='',
            output=False,
            junit=False,
            json=False,
            file=False
        )
        try:
            runner = ScenarioRunner(arguments)
            result = runner.run()
        except Exception as e:
            print(e)
            result = False
        finally:
            del runner

            if run_external_model:
                model_process.terminate()
                output, error = model_process.communicate()
                print("[Runner]", output)
                print("[Runner]", error)
        return result

    def run(self, carla=False, esmini=False, run_external_model=False, missing_only=False):
        if esmini:
            self.run_esmini_sim()
        if carla:
            self.run_carla_sim(run_external_model, missing_only)


def main():
    sc_args = Namespace(
        scenario_list=[],
        esmini=False,
        esmini_log_dir=None,
        carla=True,
        carla_root=sys.argv[1],
        carla_low_quality=bool(int(sys.argv[2])),
        carla_log_dir=Path(sys.argv[3])
    )
    sc = SimulationController(sc_args)
    try:
        result = sc.run_one_simulation(Path(sys.argv[4]).absolute(), bool(int(sys.argv[5])))
        exit(0 if result else 1)
    except Exception as e:
        print(e)
        exit(2)


if __name__ == '__main__':
    main()

