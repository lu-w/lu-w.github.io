import yaml
from pathlib import Path
import os
import sys

with open('data_storage/config/static_config.yaml') as dependency_config_file:
    config = yaml.safe_load(dependency_config_file)
config = {key: Path(config[key]) if isinstance(config[key], str) else config[key] for key in config.keys()}
sys.path.append(str(config['scenario_runner'].resolve()))
sys.path.append(str(config['carla_root'] / config['egg']))
sys.path.append(str(config['carla_root'] / config['agents']))
sys.path.append(str(config['carla_root'] / config['carla']))
os.environ['SCENARIO_RUNNER_ROOT'] = str(config['scenario_runner'].absolute())
