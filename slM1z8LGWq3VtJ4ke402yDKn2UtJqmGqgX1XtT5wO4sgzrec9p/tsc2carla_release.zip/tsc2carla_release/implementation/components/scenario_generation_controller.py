import glob
import os
import yaml as yl
from pathlib import Path
from utils.preprocessing import Preprocessor
from utils.namespace import Namespace


class SafeLoader(yl.SafeLoader):
    def handle_tag(self, node):
        return self.construct_mapping(node)


class ScenarioGenerationController(object):
    def __init__(self, args):
        self.scenario_list = []
        self.tsc_file = None
        self.tsc2smt_root = args.tsc2smt_root
        self.tsc2smt_conf_dir = args.tsc2smt_conf_dir
        self.smt2instance_root = args.smt2instance_root
        self.smt2instance_conf_dir = args.smt2instance_conf_dir
        self.instance2openx_root = args.instance2openx_root
        self.instance2openx_conf_dir = args.instance2openx_conf_dir
        self.smt_dir = args.smt_dir
        self.instance_dir = args.instance_dir
        self.scenario_dir = args.scenario_dir

        SafeLoader.add_constructor(u'tag:yaml.org,2002:de.offis.vvm.tsc2osc.configuration.DefaultConfiguration',
                                   SafeLoader.handle_tag)

    def _update_scenario_list(self):
        self.scenario_list = [Path(x) for x in glob.glob(str(Path(self.scenario_dir) / Path('scenario_*.xosc')))]

    def get_scenario_list(self):
        self._update_scenario_list()
        return self.scenario_list

    def generate_smt(self):
        tsc2smt_path = Path(glob.glob(str(self.tsc2smt_root / Path('*.jar')))[0])
        tsc2smt_conf_path = Path(glob.glob(str(self.tsc2smt_conf_dir / Path('*.yaml')))[0])
        print(f'TSC2SMT Configuration Path: {tsc2smt_conf_path}')
        os.system(f'java -jar {tsc2smt_path} --config {tsc2smt_conf_path}')

    def solve_smt(self):
        smt2instance_path = str(self.smt2instance_root / Path('runner.py'))
        for smt2instance_config_path in glob.glob(str(self.smt2instance_conf_dir / Path('*.yaml'))):
            with open(smt2instance_config_path) as instance_conf_file:
                instance_conf = yl.safe_load(instance_conf_file)
            num_models = instance_conf['instances']
            smt_location = str(self.smt_dir / ('_'.join(Path(smt2instance_config_path).name.split('_')[1:-1]) + '.smt'))

            os.system(
                f'python -u {smt2instance_path} --num_models {num_models} -i {smt_location} -o {self.instance_dir} --searching_methods recursive_blocking_invs --compare_variation --z3_solver_seed 1333')

    def instances_to_scenarios(self):
        instance2openx_path = Path(glob.glob(str(self.instance2openx_root / Path('*.jar')))[0])
        instance2openx_conf_path = Path(glob.glob(str(self.instance2openx_conf_dir / Path('*.yaml')))[0])
        os.system(f'java -jar {instance2openx_path} --config {instance2openx_conf_path}')

    def generate_scenarios(self):
        self.generate_smt()
        self.solve_smt()
        self.instances_to_scenarios()

    def preprocess(self):
        for scenario in self.get_scenario_list():
            args = Namespace(
                source=Path(scenario),
                target=None,
                stop_trigger=True,
                start_trigger=True,
                priority=True,
                header_description=True,
                clean_up=True,
                remove_ego_trajectory=True,
                extract_scenario_information=True,
                ego="VehicleA"
            )
            preprocessor = Preprocessor(args)
            preprocessor.run()

    def run(self, generation=False, preprocessing=False):
        if generation:
            self.generate_scenarios()
        if preprocessing:
            self.preprocess()
