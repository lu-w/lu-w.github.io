import pandas as pd
from pathlib import Path

metrics = pd.read_csv(list(Path('data_storage', 'reports').glob('*_metrics.csv'))[-1])
# print(metrics)

verdicts = pd.read_csv(list(Path('data_storage', 'reports').glob('*_verdicts.csv'))[-1])
# print(metrics)

df = pd.read_csv(Path('data_storage', 'reports', 'collisions.csv'))
merged = pd.merge(metrics, df, on=['Scenario'])
# merged = pd.merge(merged, verdicts, on=['Scenario'], suffixes=(None, '.Verdict'))
print(merged)
print('Over all:')
print(merged.describe())
# print(merged.sum())
for metric in verdicts.columns[1:]:
    print(f'{metric} <= target: {metrics[verdicts[metric]].describe()}')
print('Vehicle collisions: ')
print(merged[merged['vehicles']].describe())
print('No vehicle collisions: ')
print(merged[~merged['vehicles']].describe())
for metric in metrics.columns[1:]:
    max_collision = merged[merged["vehicles"]][metric].max()
    no_collision = merged[~merged["vehicles"]][metric]

    print(f'{metric}: {no_collision[no_collision <= max_collision].describe()}')
