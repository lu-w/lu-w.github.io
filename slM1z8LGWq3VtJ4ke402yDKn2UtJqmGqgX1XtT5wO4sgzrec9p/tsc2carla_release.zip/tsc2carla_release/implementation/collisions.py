import sys
from pathlib import Path
from pandas import DataFrame, read_csv, merge

import carla

host = "127.0.0.1"
port = 2000
client_timeout = 2000

client = carla.Client(host, int(port))
client.set_timeout(client_timeout)

log_base_path = Path('data_storage', 'traces', 'carla', 'recording').absolute()

results = []
for log_path in log_base_path.glob(f'*.log'):
    print(log_path)
    info = client.show_recorder_collisions(str(log_path), 'a', 'a')
    print(info)
    results.append([log_path.stem, ' v v ' in info, ' v o ' in info])


df = DataFrame(results, columns=['Scenario', 'vehicles', 'other'])
df.to_csv(Path('data_storage', 'reports', 'collisions.csv'))



